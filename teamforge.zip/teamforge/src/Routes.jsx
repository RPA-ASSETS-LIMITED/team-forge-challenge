import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "components/ScrollToTop";
import ErrorBoundary from "components/ErrorBoundary";
import ContextualHeader from "components/ui/ContextualHeader";
import BottomTabNavigation from "components/ui/BottomTabNavigation";
import { NotificationProvider } from "components/ui/NotificationBadgeSystem";

// Page imports
import DashboardHome from "pages/dashboard-home";
import ProjectCreation from "pages/project-creation";
import ProjectDiscovery from "pages/project-discovery";
import TeamWorkspace from "pages/team-workspace";
import UserProfile from "pages/user-profile";
import ProjectPortfolioGallery from "pages/project-portfolio-gallery";
import NotFound from "pages/NotFound";

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
        <NotificationProvider>
          <ScrollToTop />
          <div className="min-h-screen bg-background">
            <ContextualHeader />
            <main className="pb-20 tablet:pb-0">
              <RouterRoutes>
                <Route path="/" element={<DashboardHome />} />
                <Route path="/dashboard-home" element={<DashboardHome />} />
                <Route path="/project-creation" element={<ProjectCreation />} />
                <Route path="/project-discovery" element={<ProjectDiscovery />} />
                <Route path="/team-workspace" element={<TeamWorkspace />} />
                <Route path="/user-profile" element={<UserProfile />} />
                <Route path="/project-portfolio-gallery" element={<ProjectPortfolioGallery />} />
                <Route path="*" element={<NotFound />} />
              </RouterRoutes>
            </main>
            <BottomTabNavigation />
          </div>
        </NotificationProvider>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;