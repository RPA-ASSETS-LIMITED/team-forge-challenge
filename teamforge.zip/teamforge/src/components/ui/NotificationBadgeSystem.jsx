import React, { useState, useEffect, createContext, useContext } from 'react';

const NotificationContext = createContext();

export const useNotifications = () => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
};

export const NotificationProvider = ({ children }) => {
  const [notifications, setNotifications] = useState({
    dashboard: 0,
    projects: 0,
    teams: 3,
    profile: 0,
    general: 5
  });

  const [realtimeUpdates, setRealtimeUpdates] = useState([]);

  // Simulate WebSocket connection for real-time updates
  useEffect(() => {
    const simulateRealtimeUpdates = () => {
      const updateTypes = ['team_message', 'project_update', 'mention', 'deadline'];
      const randomUpdate = updateTypes[Math.floor(Math.random() * updateTypes.length)];
      
      const newUpdate = {
        id: Date.now(),
        type: randomUpdate,
        timestamp: new Date(),
        read: false
      };

      setRealtimeUpdates(prev => [newUpdate, ...prev.slice(0, 9)]);

      // Update notification counts based on update type
      setNotifications(prev => {
        const updated = { ...prev };
        switch (randomUpdate) {
          case 'team_message':
            updated.teams += 1;
            break;
          case 'project_update':
            updated.projects += 1;
            break;
          case 'mention':
            updated.general += 1;
            break;
          case 'deadline':
            updated.dashboard += 1;
            break;
          default:
            break;
        }
        return updated;
      });
    };

    // Simulate updates every 30 seconds
    const interval = setInterval(simulateRealtimeUpdates, 30000);
    return () => clearInterval(interval);
  }, []);

  const markAsRead = (section) => {
    setNotifications(prev => ({
      ...prev,
      [section]: 0
    }));
  };

  const markAllAsRead = () => {
    setNotifications({
      dashboard: 0,
      projects: 0,
      teams: 0,
      profile: 0,
      general: 0
    });
    setRealtimeUpdates(prev => prev.map(update => ({ ...update, read: true })));
  };

  const getTotalCount = () => {
    return Object.values(notifications).reduce((sum, count) => sum + count, 0);
  };

  const getNotificationCount = (section) => {
    return notifications[section] || 0;
  };

  const addNotification = (section, count = 1) => {
    setNotifications(prev => ({
      ...prev,
      [section]: prev[section] + count
    }));
  };

  const value = {
    notifications,
    realtimeUpdates,
    markAsRead,
    markAllAsRead,
    getTotalCount,
    getNotificationCount,
    addNotification
  };

  return (
    <NotificationContext.Provider value={value}>
      {children}
    </NotificationContext.Provider>
  );
};

export const NotificationBadge = ({ 
  count, 
  maxCount = 99, 
  size = 'default',
  position = 'top-right',
  className = '' 
}) => {
  if (!count || count <= 0) return null;

  const sizeClasses = {
    small: 'min-w-[14px] h-[14px] text-[10px]',
    default: 'min-w-[18px] h-[18px] text-xs',
    large: 'min-w-[22px] h-[22px] text-sm'
  };

  const positionClasses = {
    'top-right': '-top-1 -right-1',
    'top-left': '-top-1 -left-1',
    'bottom-right': '-bottom-1 -right-1',
    'bottom-left': '-bottom-1 -left-1'
  };

  const displayCount = count > maxCount ? `${maxCount}+` : count;

  return (
    <span 
      className={`
        absolute ${positionClasses[position]} 
        bg-red-500 text-white font-medium leading-none
        rounded-full flex items-center justify-center
        ${sizeClasses[size]} ${className}
        z-50
        animate-pulse
      `}
      aria-label={`${count} notifications`}
      role="status"
    >
      {displayCount}
    </span>
  );
};

export const NotificationIndicator = ({ 
  section, 
  children, 
  showZero = false,
  size = 'default',
  position = 'top-right',
  className = ''
}) => {
  const { getNotificationCount } = useNotifications();
  const count = getNotificationCount(section);

  return (
    <div className="relative inline-block">
      {children}
      {(count > 0 || showZero) && (
        <NotificationBadge 
          count={count}
          size={size}
          position={position}
          className={className}
        />
      )}
    </div>
  );
};

export const NotificationList = ({ 
  maxItems = 10, 
  showTimestamp = true,
  className = '' 
}) => {
  const { realtimeUpdates, markAllAsRead } = useNotifications();

  const getUpdateIcon = (type) => {
    switch (type) {
      case 'team_message': return 'MessageCircle';
      case 'project_update': return 'GitBranch';
      case 'mention': return 'AtSign';
      case 'deadline': return 'Clock';
      default: return 'Bell';
    }
  };

  const getUpdateText = (type) => {
    switch (type) {
      case 'team_message': return 'New team message';
      case 'project_update': return 'Project updated';
      case 'mention': return 'You were mentioned';
      case 'deadline': return 'Deadline approaching';
      default: return 'New notification';
    }
  };

  const formatTimestamp = (timestamp) => {
    const now = new Date();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    return `${days}d ago`;
  };

  const visibleUpdates = realtimeUpdates.slice(0, maxItems);

  return (
    <div className={`bg-white rounded-lg border border-gray-200 shadow-lg ${className}`}>
      <div className="p-4 border-b border-gray-200 flex items-center justify-between">
        <h3 className="font-semibold text-gray-900">
          Notifications
        </h3>
        {realtimeUpdates.some(update => !update.read) && (
          <button
            onClick={markAllAsRead}
            className="text-sm text-blue-600 hover:text-blue-700 transition-colors duration-150"
          >
            Mark all read
          </button>
        )}
      </div>
      
      <div className="max-h-80 overflow-y-auto">
        {visibleUpdates.length === 0 ? (
          <div className="p-6 text-center text-gray-500">
            <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-3">
              <span className="text-gray-400 text-xl">🔔</span>
            </div>
            <p className="text-sm">No new notifications</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-200">
            {visibleUpdates.map((update) => (
              <div 
                key={update.id}
                className={`
                  p-4 hover:bg-gray-50 transition-colors duration-150 cursor-pointer
                  ${!update.read ? 'bg-blue-50 border-l-2 border-l-blue-500' : ''}
                `}
              >
                <div className="flex items-start space-x-3">
                  <div className={`
                    w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0
                    ${!update.read ? 'bg-blue-500 text-white' : 'bg-gray-100 text-gray-600'}
                  `}>
                    <span className="text-sm">
                      {getUpdateIcon(update.type) === 'MessageCircle' && '💬'}
                      {getUpdateIcon(update.type) === 'GitBranch' && '🔄'}
                      {getUpdateIcon(update.type) === 'AtSign' && '@'}
                      {getUpdateIcon(update.type) === 'Clock' && '⏰'}
                      {getUpdateIcon(update.type) === 'Bell' && '🔔'}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`
                      text-sm ${!update.read ? 'font-medium text-gray-900' : 'text-gray-600'}
                    `}>
                      {getUpdateText(update.type)}
                    </p>
                    {showTimestamp && (
                      <p className="text-xs text-gray-500 mt-1">
                        {formatTimestamp(update.timestamp)}
                      </p>
                    )}
                  </div>
                  {!update.read && (
                    <div className="w-2 h-2 bg-blue-500 rounded-full flex-shrink-0 mt-2" />
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

// Default export as a comprehensive notification system object
const NotificationBadgeSystem = {
  Provider: NotificationProvider,
  Badge: NotificationBadge,
  Indicator: NotificationIndicator,
  List: NotificationList,
  useNotifications
};

export default NotificationBadgeSystem;