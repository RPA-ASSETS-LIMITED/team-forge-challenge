import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Icon from '../AppIcon';

const BottomTabNavigation = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const navigationItems = [
    {
      label: 'Dashboard',
      path: '/dashboard-home',
      icon: 'Home',
      badge: 0,
      tooltip: 'Your project dashboard and activity center'
    },
    {
      label: 'Projects',
      path: '/project-discovery',
      icon: 'Search',
      badge: 0,
      tooltip: 'Discover and create new projects',
      subPaths: ['/project-creation', '/project-portfolio-gallery']
    },
    {
      label: 'Teams',
      path: '/team-workspace',
      icon: 'Users',
      badge: 3,
      tooltip: 'Active team collaboration workspace'
    },
    {
      label: 'Profile',
      path: '/user-profile',
      icon: 'User',
      badge: 0,
      tooltip: 'Your profile and portfolio settings'
    }
  ];

  const isActiveTab = (item) => {
    if (location.pathname === item.path) return true;
    if (item.subPaths) {
      return item.subPaths.some(subPath => location.pathname === subPath);
    }
    return false;
  };

  const handleTabClick = (item) => {
    navigate(item.path);
  };

  const handleKeyDown = (event, item) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      handleTabClick(item);
    }
  };

  return (
    <nav 
      className="fixed bottom-0 left-0 right-0 z-bottom-nav bg-surface border-t border-border"
      role="navigation"
      aria-label="Main navigation"
    >
      <div className="safe-area-inset-bottom">
        <div className="flex items-center justify-around px-safe-inset py-2">
          {navigationItems.map((item) => {
            const isActive = isActiveTab(item);
            
            return (
              <button
                key={item.path}
                onClick={() => handleTabClick(item)}
                onKeyDown={(e) => handleKeyDown(e, item)}
                className={`
                  nav-item relative flex-1 max-w-[80px] transition-all duration-150 ease-in-out
                  ${isActive 
                    ? 'nav-item-active text-primary-700' :'text-secondary hover:text-text-primary focus:text-text-primary'
                  }
                `}
                aria-label={item.tooltip}
                aria-current={isActive ? 'page' : undefined}
                title={item.tooltip}
              >
                <div className="flex flex-col items-center space-y-1">
                  <div className="relative">
                    <Icon 
                      name={item.icon} 
                      size={24} 
                      strokeWidth={isActive ? 2.5 : 2}
                      className="transition-all duration-150 ease-in-out"
                    />
                    {item.badge > 0 && (
                      <span 
                        className="notification-badge"
                        aria-label={`${item.badge} notifications`}
                      >
                        {item.badge > 99 ? '99+' : item.badge}
                      </span>
                    )}
                  </div>
                  <span className={`
                    text-xs font-medium leading-none transition-all duration-150 ease-in-out
                    hidden sm:block tablet:block
                    ${isActive ? 'text-primary-700' : 'text-secondary'}
                  `}>
                    {item.label}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
};

export default BottomTabNavigation;