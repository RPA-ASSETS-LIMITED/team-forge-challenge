import React, { useState } from 'react';
import Icon from '../AppIcon';

const ProjectFilterPanel = ({ isOpen, onClose, onApplyFilters }) => {
  const [filters, setFilters] = useState({
    skills: [],
    difficulty: '',
    duration: '',
    teamSize: '',
    status: '',
    category: ''
  });

  const skillOptions = [
    'JavaScript', 'React', 'Node.js', 'Python', 'Java', 'TypeScript',
    'Vue.js', 'Angular', 'PHP', 'Ruby', 'Go', 'Rust', 'Swift', 'Kotlin',
    'HTML/CSS', 'MongoDB', 'PostgreSQL', 'MySQL', 'Redis', 'Docker',
    'Kubernetes', 'AWS', 'Azure', 'GCP', 'Git', 'GraphQL', 'REST API'
  ];

  const difficultyOptions = [
    { value: 'beginner', label: 'Beginner Friendly' },
    { value: 'intermediate', label: 'Intermediate' },
    { value: 'advanced', label: 'Advanced' },
    { value: 'expert', label: 'Expert Level' }
  ];

  const durationOptions = [
    { value: '1-2weeks', label: '1-2 weeks' },
    { value: '3-4weeks', label: '3-4 weeks' },
    { value: '1-2months', label: '1-2 months' },
    { value: '3-6months', label: '3-6 months' },
    { value: '6months+', label: '6+ months' }
  ];

  const teamSizeOptions = [
    { value: '2-3', label: '2-3 members' },
    { value: '4-6', label: '4-6 members' },
    { value: '7-10', label: '7-10 members' },
    { value: '10+', label: '10+ members' }
  ];

  const statusOptions = [
    { value: 'recruiting', label: 'Recruiting' },
    { value: 'in-progress', label: 'In Progress' },
    { value: 'completed', label: 'Completed' },
    { value: 'on-hold', label: 'On Hold' }
  ];

  const categoryOptions = [
    { value: 'web-app', label: 'Web Application' },
    { value: 'mobile-app', label: 'Mobile App' },
    { value: 'api', label: 'API/Backend' },
    { value: 'data-science', label: 'Data Science' },
    { value: 'ai-ml', label: 'AI/Machine Learning' },
    { value: 'game', label: 'Game Development' },
    { value: 'devtools', label: 'Developer Tools' },
    { value: 'open-source', label: 'Open Source' }
  ];

  const handleSkillToggle = (skill) => {
    setFilters(prev => ({
      ...prev,
      skills: prev.skills.includes(skill)
        ? prev.skills.filter(s => s !== skill)
        : [...prev.skills, skill]
    }));
  };

  const handleFilterChange = (filterType, value) => {
    setFilters(prev => ({
      ...prev,
      [filterType]: prev[filterType] === value ? '' : value
    }));
  };

  const handleClearAll = () => {
    setFilters({
      skills: [],
      difficulty: '',
      duration: '',
      teamSize: '',
      status: '',
      category: ''
    });
  };

  const handleApplyFilters = () => {
    onApplyFilters(filters);
    onClose();
  };

  const getActiveFilterCount = () => {
    let count = 0;
    if (filters.skills.length > 0) count++;
    if (filters.difficulty) count++;
    if (filters.duration) count++;
    if (filters.teamSize) count++;
    if (filters.status) count++;
    if (filters.category) count++;
    return count;
  };

  const FilterSection = ({ title, children }) => (
    <div className="space-y-3">
      <h3 className="font-heading font-medium text-text-primary">{title}</h3>
      {children}
    </div>
  );

  const SkillTag = ({ skill, isSelected, onClick }) => (
    <button
      onClick={onClick}
      className={`
        px-3 py-1.5 rounded-md text-sm font-medium transition-all duration-150 ease-in-out
        ${isSelected 
          ? 'bg-primary text-white' :'bg-secondary-100 text-secondary-700 hover:bg-secondary-200'
        }
      `}
    >
      {skill}
    </button>
  );

  const RadioOption = ({ name, value, currentValue, label, onChange }) => (
    <label className="flex items-center space-x-3 cursor-pointer group">
      <input
        type="radio"
        name={name}
        value={value}
        checked={currentValue === value}
        onChange={() => onChange(value)}
        className="w-4 h-4 text-primary focus:ring-primary-500 focus:ring-2"
      />
      <span className="text-sm text-text-secondary group-hover:text-text-primary transition-colors duration-150">
        {label}
      </span>
    </label>
  );

  if (!isOpen) return null;

  return (
    <>
      {/* Mobile Overlay */}
      <div 
        className="tablet:hidden fixed inset-0 bg-black bg-opacity-50 z-filter-panel"
        onClick={onClose}
        aria-hidden="true"
      />
      
      {/* Filter Panel */}
      <div className={`
        fixed tablet:sticky tablet:top-header-simple
        inset-x-0 bottom-0 tablet:inset-x-auto tablet:bottom-auto
        tablet:w-80 tablet:h-[calc(100vh-theme(spacing.header-simple))]
        bg-surface border-t tablet:border-l tablet:border-t-0 border-border
        z-filter-panel tablet:z-auto
        animation-slide-up tablet:animation-fade-in
        overflow-y-auto
      `}>
        <div className="p-6 space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <h2 className="font-heading font-semibold text-lg text-text-primary">
                Filter Projects
              </h2>
              {getActiveFilterCount() > 0 && (
                <span className="bg-primary text-white text-xs px-2 py-1 rounded-full">
                  {getActiveFilterCount()}
                </span>
              )}
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-secondary-100 transition-colors duration-150"
              aria-label="Close filters"
            >
              <Icon name="X" size={20} className="text-secondary-600" />
            </button>
          </div>

          {/* Skills Filter */}
          <FilterSection title="Skills & Technologies">
            <div className="flex flex-wrap gap-2">
              {skillOptions.map(skill => (
                <SkillTag
                  key={skill}
                  skill={skill}
                  isSelected={filters.skills.includes(skill)}
                  onClick={() => handleSkillToggle(skill)}
                />
              ))}
            </div>
          </FilterSection>

          {/* Difficulty Filter */}
          <FilterSection title="Difficulty Level">
            <div className="space-y-2">
              {difficultyOptions.map(option => (
                <RadioOption
                  key={option.value}
                  name="difficulty"
                  value={option.value}
                  currentValue={filters.difficulty}
                  label={option.label}
                  onChange={(value) => handleFilterChange('difficulty', value)}
                />
              ))}
            </div>
          </FilterSection>

          {/* Duration Filter */}
          <FilterSection title="Project Duration">
            <div className="space-y-2">
              {durationOptions.map(option => (
                <RadioOption
                  key={option.value}
                  name="duration"
                  value={option.value}
                  currentValue={filters.duration}
                  label={option.label}
                  onChange={(value) => handleFilterChange('duration', value)}
                />
              ))}
            </div>
          </FilterSection>

          {/* Team Size Filter */}
          <FilterSection title="Team Size">
            <div className="space-y-2">
              {teamSizeOptions.map(option => (
                <RadioOption
                  key={option.value}
                  name="teamSize"
                  value={option.value}
                  currentValue={filters.teamSize}
                  label={option.label}
                  onChange={(value) => handleFilterChange('teamSize', value)}
                />
              ))}
            </div>
          </FilterSection>

          {/* Status Filter */}
          <FilterSection title="Project Status">
            <div className="space-y-2">
              {statusOptions.map(option => (
                <RadioOption
                  key={option.value}
                  name="status"
                  value={option.value}
                  currentValue={filters.status}
                  label={option.label}
                  onChange={(value) => handleFilterChange('status', value)}
                />
              ))}
            </div>
          </FilterSection>

          {/* Category Filter */}
          <FilterSection title="Project Category">
            <div className="space-y-2">
              {categoryOptions.map(option => (
                <RadioOption
                  key={option.value}
                  name="category"
                  value={option.value}
                  currentValue={filters.category}
                  label={option.label}
                  onChange={(value) => handleFilterChange('category', value)}
                />
              ))}
            </div>
          </FilterSection>

          {/* Action Buttons */}
          <div className="flex space-x-3 pt-4 border-t border-border">
            <button
              onClick={handleClearAll}
              className="flex-1 px-4 py-2 border border-border rounded-lg text-secondary-700 hover:bg-secondary-100 transition-all duration-150 ease-out"
            >
              Clear All
            </button>
            <button
              onClick={handleApplyFilters}
              className="flex-1 btn-primary"
            >
              Apply Filters
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default ProjectFilterPanel;