import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Icon from '../AppIcon';

const ContextualHeader = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearch, setShowSearch] = useState(false);

  const getHeaderConfig = () => {
    const path = location.pathname;
    
    switch (path) {
      case '/dashboard-home':
        return {
          title: 'Dashboard',
          showLogo: true,
          showSearch: false,
          showNotifications: true,
          actions: [
            { icon: 'Plus', label: 'New Project', onClick: () => navigate('/project-creation') },
            { icon: 'Bell', label: 'Notifications', badge: 5, onClick: () => {} }
          ]
        };
      
      case '/project-discovery':
        return {
          title: 'Discover Projects',
          showLogo: true,
          showSearch: true,
          showFilter: true,
          actions: [
            { icon: 'Filter', label: 'Filter Projects', onClick: () => {} },
            { icon: 'Plus', label: 'Create Project', onClick: () => navigate('/project-creation') }
          ]
        };
      
      case '/project-creation':
        return {
          title: 'Create New Project',
          showLogo: true,
          showBack: true,
          showProgress: true,
          progress: 60,
          actions: [
            { icon: 'Save', label: 'Save Draft', onClick: () => {} },
            { icon: 'X', label: 'Cancel', onClick: () => navigate('/project-discovery') }
          ]
        };
      
      case '/team-workspace':
        return {
          title: 'Team Workspace',
          showLogo: true,
          showMembers: true,
          showSearch: true,
          actions: [
            { icon: 'Users', label: 'Team Members', badge: 4, onClick: () => {} },
            { icon: 'Settings', label: 'Workspace Settings', onClick: () => {} }
          ]
        };
      
      case '/user-profile':
        return {
          title: 'Profile',
          showLogo: true,
          showEdit: true,
          actions: [
            { icon: 'Edit', label: 'Edit Profile', onClick: () => {} },
            { icon: 'Settings', label: 'Account Settings', onClick: () => {} }
          ]
        };
      
      case '/project-portfolio-gallery':
        return {
          title: 'Project Gallery',
          showLogo: true,
          showSearch: true,
          minimal: true,
          actions: [
            { icon: 'Grid', label: 'Grid View', onClick: () => {} },
            { icon: 'List', label: 'List View', onClick: () => {} }
          ]
        };
      
      default:
        return {
          title: 'DevCollab',
          showLogo: true,
          actions: []
        };
    }
  };

  const config = getHeaderConfig();

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      console.log('Search query:', searchQuery);
    }
  };

  const handleBackClick = () => {
    navigate(-1);
  };

  const Logo = () => (
    <div className="flex items-center space-x-2">
      <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
        <Icon name="Code" size={20} color="white" strokeWidth={2.5} />
      </div>
      <span className="font-heading font-semibold text-lg text-text-primary hidden sm:block">
        DevCollab
      </span>
    </div>
  );

  const SearchBar = () => (
    <div className="flex-1 max-w-md mx-4">
      <form onSubmit={handleSearchSubmit} className="relative">
        <Icon 
          name="Search" 
          size={20} 
          className="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary"
        />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search projects, teams, or skills..."
          className="w-full pl-10 pr-4 py-2 bg-secondary-100 border-0 rounded-lg focus:bg-surface focus:ring-2 focus:ring-primary-500 transition-all duration-200 ease-out"
          aria-label="Search"
        />
      </form>
    </div>
  );

  const ProgressBar = () => (
    config.showProgress && (
      <div className="w-full bg-secondary-200 rounded-full h-1 mt-2">
        <div 
          className="bg-primary h-1 rounded-full transition-all duration-300 ease-out"
          style={{ width: `${config.progress}%` }}
          role="progressbar"
          aria-valuenow={config.progress}
          aria-valuemin={0}
          aria-valuemax={100}
          aria-label={`Project creation progress: ${config.progress}%`}
        />
      </div>
    )
  );

  const ActionButton = ({ action }) => (
    <button
      onClick={action.onClick}
      className="relative p-2 rounded-lg hover:bg-secondary-100 focus:bg-secondary-100 transition-all duration-150 ease-in-out min-h-touch-target flex items-center justify-center"
      aria-label={action.label}
      title={action.label}
    >
      <Icon name={action.icon} size={20} className="text-secondary-600" />
      {action.badge && action.badge > 0 && (
        <span 
          className="notification-badge"
          aria-label={`${action.badge} ${action.label.toLowerCase()}`}
        >
          {action.badge > 99 ? '99+' : action.badge}
        </span>
      )}
    </button>
  );

  return (
    <header 
      className={`
        sticky top-0 z-header bg-surface border-b border-border
        ${config.minimal ? 'h-header-simple' : 'min-h-header-simple'}
      `}
      role="banner"
    >
      <div className="px-safe-inset py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            {config.showBack && (
              <button
                onClick={handleBackClick}
                className="p-2 rounded-lg hover:bg-secondary-100 focus:bg-secondary-100 transition-all duration-150 ease-in-out"
                aria-label="Go back"
              >
                <Icon name="ArrowLeft" size={20} className="text-secondary-600" />
              </button>
            )}
            
            {config.showLogo && <Logo />}
            
            {!config.showLogo && (
              <h1 className="font-heading font-semibold text-lg text-text-primary">
                {config.title}
              </h1>
            )}
          </div>

          {config.showSearch && !showSearch && (
            <div className="hidden tablet:block flex-1">
              <SearchBar />
            </div>
          )}

          <div className="flex items-center space-x-1">
            {config.showSearch && (
              <button
                onClick={() => setShowSearch(!showSearch)}
                className="tablet:hidden p-2 rounded-lg hover:bg-secondary-100 focus:bg-secondary-100 transition-all duration-150 ease-in-out"
                aria-label="Toggle search"
              >
                <Icon name="Search" size={20} className="text-secondary-600" />
              </button>
            )}
            
            {config.actions.map((action, index) => (
              <ActionButton key={index} action={action} />
            ))}
          </div>
        </div>

        {showSearch && (
          <div className="tablet:hidden mt-3 animation-slide-up">
            <SearchBar />
          </div>
        )}

        <ProgressBar />
      </div>
    </header>
  );
};

export default ContextualHeader;