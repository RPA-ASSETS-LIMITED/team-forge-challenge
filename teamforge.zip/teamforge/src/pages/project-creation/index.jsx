import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from 'components/AppIcon';
import Image from 'components/AppImage';

const ProjectCreation = () => {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [isAutoSaving, setIsAutoSaving] = useState(false);
  const [lastSaved, setLastSaved] = useState(null);

  const [projectData, setProjectData] = useState({
    title: '',
    description: '',
    category: '',
    difficulty: '',
    template: '',
    teamSize: '',
    requiredSkills: [],
    roles: [],
    timeline: '',
    milestones: [],
    deliverables: []
  });

  const projectCategories = [
    {
      id: 'web-app',
      name: 'Web Application',
      description: 'Full-stack web applications using modern frameworks',
      icon: 'Globe',
      color: 'bg-blue-50 border-blue-200 text-blue-700',
      frameworks: ['React', 'Vue.js', 'Angular', 'Node.js']
    },
    {
      id: 'mobile-app',
      name: 'Mobile App',
      description: 'Native or cross-platform mobile applications',
      icon: 'Smartphone',
      color: 'bg-green-50 border-green-200 text-green-700',
      frameworks: ['React Native', 'Flutter', 'Swift', 'Kotlin']
    },
    {
      id: 'api-backend',
      name: 'API/Backend',
      description: 'Server-side applications and RESTful APIs',
      icon: 'Server',
      color: 'bg-purple-50 border-purple-200 text-purple-700',
      frameworks: ['Express.js', 'Django', 'Spring Boot', 'FastAPI']
    },
    {
      id: 'data-science',
      name: 'Data Science',
      description: 'Data analysis, visualization, and machine learning',
      icon: 'BarChart3',
      color: 'bg-orange-50 border-orange-200 text-orange-700',
      frameworks: ['Python', 'R', 'Jupyter', 'TensorFlow']
    },
    {
      id: 'ai-ml',
      name: 'AI/Machine Learning',
      description: 'Artificial intelligence and ML model development',
      icon: 'Brain',
      color: 'bg-pink-50 border-pink-200 text-pink-700',
      frameworks: ['PyTorch', 'TensorFlow', 'Scikit-learn', 'OpenAI']
    },
    {
      id: 'game-dev',
      name: 'Game Development',
      description: 'Interactive games and entertainment applications',
      icon: 'Gamepad2',
      color: 'bg-red-50 border-red-200 text-red-700',
      frameworks: ['Unity', 'Unreal Engine', 'Godot', 'Phaser']
    }
  ];

  const difficultyLevels = [
    {
      id: 'beginner',
      name: 'Beginner Friendly',
      description: 'Perfect for first-time collaborators',
      duration: '2-4 weeks',
      complexity: 'Low',
      color: 'bg-green-50 border-green-200 text-green-700'
    },
    {
      id: 'intermediate',
      name: 'Intermediate',
      description: 'Some experience required',
      duration: '1-2 months',
      complexity: 'Medium',
      color: 'bg-yellow-50 border-yellow-200 text-yellow-700'
    },
    {
      id: 'advanced',
      name: 'Advanced',
      description: 'For experienced developers',
      duration: '2-4 months',
      complexity: 'High',
      color: 'bg-orange-50 border-orange-200 text-orange-700'
    },
    {
      id: 'expert',
      name: 'Expert Level',
      description: 'Cutting-edge technologies',
      duration: '3-6 months',
      complexity: 'Very High',
      color: 'bg-red-50 border-red-200 text-red-700'
    }
  ];

  const projectTemplates = [
    {
      id: 'ecommerce',
      name: 'E-commerce Platform',
      category: 'web-app',
      description: 'Complete online store with payment integration',
      image: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=400&h=200&fit=crop',
      features: ['Product catalog', 'Shopping cart', 'Payment gateway', 'User accounts']
    },
    {
      id: 'social-media',
      name: 'Social Media App',
      category: 'mobile-app',
      description: 'Connect people through posts and messaging',
      image: 'https://images.pexels.com/photos/267350/pexels-photo-267350.jpeg?w=400&h=200&fit=crop',
      features: ['User profiles', 'Posts & feeds', 'Real-time chat', 'Media sharing']
    },
    {
      id: 'task-manager',
      name: 'Team Task Manager',
      category: 'web-app',
      description: 'Collaborative project management tool',
      image: 'https://images.pixabay.com/photo/2016/04/04/14/12/monitor-1307227_960_720.jpg?w=400&h=200&fit=crop',
      features: ['Task boards', 'Team collaboration', 'Progress tracking', 'Notifications']
    },
    {
      id: 'weather-app',
      name: 'Weather Dashboard',
      category: 'data-science',
      description: 'Weather data visualization and forecasting',
      image: 'https://images.unsplash.com/photo-1504608524841-42fe6f032b4b?w=400&h=200&fit=crop',
      features: ['Weather API', 'Data visualization', 'Location services', 'Forecasting']
    }
  ];

  const availableSkills = [
    'JavaScript', 'React', 'Node.js', 'Python', 'Java', 'TypeScript',
    'Vue.js', 'Angular', 'PHP', 'Ruby', 'Go', 'Rust', 'Swift', 'Kotlin',
    'HTML/CSS', 'MongoDB', 'PostgreSQL', 'MySQL', 'Redis', 'Docker',
    'Kubernetes', 'AWS', 'Azure', 'GCP', 'Git', 'GraphQL', 'REST API',
    'UI/UX Design', 'Figma', 'Adobe XD', 'Photoshop', 'Project Management'
  ];

  const teamRoles = [
    {
      id: 'frontend-dev',
      name: 'Frontend Developer',
      description: 'User interface and experience development',
      skills: ['JavaScript', 'React', 'HTML/CSS', 'TypeScript']
    },
    {
      id: 'backend-dev',
      name: 'Backend Developer',
      description: 'Server-side logic and database management',
      skills: ['Node.js', 'Python', 'MongoDB', 'REST API']
    },
    {
      id: 'fullstack-dev',
      name: 'Full Stack Developer',
      description: 'Both frontend and backend development',
      skills: ['JavaScript', 'React', 'Node.js', 'MongoDB']
    },
    {
      id: 'ui-designer',
      name: 'UI/UX Designer',
      description: 'User interface and experience design',
      skills: ['Figma', 'Adobe XD', 'UI/UX Design', 'Photoshop']
    },
    {
      id: 'project-manager',
      name: 'Project Manager',
      description: 'Project coordination and team management',
      skills: ['Project Management', 'Communication', 'Planning']
    },
    {
      id: 'data-scientist',
      name: 'Data Scientist',
      description: 'Data analysis and machine learning',
      skills: ['Python', 'Machine Learning', 'Data Analysis', 'Statistics']
    }
  ];

  // Auto-save functionality
  useEffect(() => {
    const autoSave = () => {
      if (projectData.title || projectData.description) {
        setIsAutoSaving(true);
        setTimeout(() => {
          localStorage.setItem('project-draft', JSON.stringify(projectData));
          setLastSaved(new Date());
          setIsAutoSaving(false);
        }, 1000);
      }
    };

    const timer = setTimeout(autoSave, 3000);
    return () => clearTimeout(timer);
  }, [projectData]);

  // Load draft on component mount
  useEffect(() => {
    const savedDraft = localStorage.getItem('project-draft');
    if (savedDraft) {
      setProjectData(JSON.parse(savedDraft));
    }
  }, []);

  const handleInputChange = (field, value) => {
    setProjectData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSkillToggle = (skill) => {
    setProjectData(prev => ({
      ...prev,
      requiredSkills: prev.requiredSkills.includes(skill)
        ? prev.requiredSkills.filter(s => s !== skill)
        : [...prev.requiredSkills, skill]
    }));
  };

  const handleRoleToggle = (role) => {
    setProjectData(prev => ({
      ...prev,
      roles: prev.roles.includes(role)
        ? prev.roles.filter(r => r !== role)
        : [...prev.roles, role]
    }));
  };

  const addMilestone = () => {
    const newMilestone = {
      id: Date.now(),
      title: '',
      description: '',
      dueDate: '',
      completed: false
    };
    setProjectData(prev => ({
      ...prev,
      milestones: [...prev.milestones, newMilestone]
    }));
  };

  const updateMilestone = (id, field, value) => {
    setProjectData(prev => ({
      ...prev,
      milestones: prev.milestones.map(milestone =>
        milestone.id === id ? { ...milestone, [field]: value } : milestone
      )
    }));
  };

  const removeMilestone = (id) => {
    setProjectData(prev => ({
      ...prev,
      milestones: prev.milestones.filter(milestone => milestone.id !== id)
    }));
  };

  const handleSaveDraft = () => {
    localStorage.setItem('project-draft', JSON.stringify(projectData));
    setLastSaved(new Date());
    // Show success message
    alert('Draft saved successfully!');
  };

  const handlePublishProject = () => {
    if (!validateCurrentStep()) return;
    
    // Simulate project publication
    localStorage.removeItem('project-draft');
    alert('Project published successfully! Redirecting to project discovery...');
    navigate('/project-discovery');
  };

  const validateCurrentStep = () => {
    switch (currentStep) {
      case 1:
        return projectData.title && projectData.description && projectData.category && projectData.difficulty;
      case 2:
        return projectData.teamSize && projectData.requiredSkills.length > 0 && projectData.roles.length > 0;
      case 3:
        return projectData.timeline && projectData.milestones.length > 0;
      default:
        return false;
    }
  };

  const nextStep = () => {
    if (validateCurrentStep() && currentStep < 3) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const getStepStatus = (step) => {
    if (step < currentStep) return 'completed';
    if (step === currentStep) return 'current';
    return 'upcoming';
  };

  const StepIndicator = () => (
    <div className="bg-surface border-b border-border p-4 lg:p-6">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between">
          {[1, 2, 3].map((step) => {
            const status = getStepStatus(step);
            const stepTitles = ['Project Basics', 'Team Requirements', 'Planning & Timeline'];
            
            return (
              <div key={step} className="flex items-center flex-1">
                <div className="flex items-center">
                  <div className={`
                    w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium
                    ${status === 'completed' ? 'bg-accent text-white' : ''}
                    ${status === 'current' ? 'bg-primary text-white' : ''}
                    ${status === 'upcoming' ? 'bg-secondary-200 text-secondary-600' : ''}
                  `}>
                    {status === 'completed' ? (
                      <Icon name="Check" size={16} />
                    ) : (
                      step
                    )}
                  </div>
                  <div className="ml-3 hidden sm:block">
                    <p className={`text-sm font-medium ${
                      status === 'current' ? 'text-primary' : 
                      status === 'completed' ? 'text-accent' : 'text-secondary'
                    }`}>
                      Step {step}
                    </p>
                    <p className="text-xs text-secondary">
                      {stepTitles[step - 1]}
                    </p>
                  </div>
                </div>
                {step < 3 && (
                  <div className={`flex-1 h-0.5 mx-4 ${
                    step < currentStep ? 'bg-accent' : 'bg-secondary-200'
                  }`} />
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );

  const ProjectBasicsStep = () => (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-heading font-semibold text-text-primary mb-2">
          Project Basics
        </h2>
        <p className="text-secondary">
          Let's start with the fundamentals of your project
        </p>
      </div>

      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-text-primary mb-2">
            Project Title *
          </label>
          <input
            type="text"
            value={projectData.title}
            onChange={(e) => handleInputChange('title', e.target.value)}
            placeholder="Enter a compelling project title"
            className="input-field"
            maxLength={100}
          />
          <p className="text-xs text-secondary mt-1">
            {projectData.title.length}/100 characters
          </p>
        </div>

        <div>
          <label className="block text-sm font-medium text-text-primary mb-2">
            Project Description *
          </label>
          <textarea
            value={projectData.description}
            onChange={(e) => handleInputChange('description', e.target.value)}
            placeholder="Describe your project vision, goals, and what you hope to achieve..."
            className="input-field min-h-[120px] resize-none"
            maxLength={500}
          />
          <p className="text-xs text-secondary mt-1">
            {projectData.description.length}/500 characters
          </p>
        </div>

        <div>
          <label className="block text-sm font-medium text-text-primary mb-4">
            Project Category *
          </label>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {projectCategories.map((category) => (
              <button
                key={category.id}
                onClick={() => handleInputChange('category', category.id)}
                className={`
                  p-4 rounded-lg border-2 text-left transition-all duration-200 ease-out
                  ${projectData.category === category.id 
                    ? `${category.color} border-current` 
                    : 'bg-surface border-border hover:border-secondary-300'
                  }
                `}
              >
                <div className="flex items-start space-x-3">
                  <Icon name={category.icon} size={24} className="flex-shrink-0 mt-1" />
                  <div className="flex-1">
                    <h3 className="font-medium text-text-primary mb-1">
                      {category.name}
                    </h3>
                    <p className="text-sm text-secondary mb-2">
                      {category.description}
                    </p>
                    <div className="flex flex-wrap gap-1">
                      {category.frameworks.slice(0, 2).map((framework) => (
                        <span key={framework} className="text-xs bg-secondary-100 text-secondary-700 px-2 py-1 rounded">
                          {framework}
                        </span>
                      ))}
                      {category.frameworks.length > 2 && (
                        <span className="text-xs text-secondary">
                          +{category.frameworks.length - 2} more
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-text-primary mb-4">
            Difficulty Level *
          </label>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {difficultyLevels.map((level) => (
              <button
                key={level.id}
                onClick={() => handleInputChange('difficulty', level.id)}
                className={`
                  p-4 rounded-lg border-2 text-left transition-all duration-200 ease-out
                  ${projectData.difficulty === level.id 
                    ? `${level.color} border-current` 
                    : 'bg-surface border-border hover:border-secondary-300'
                  }
                `}
              >
                <h3 className="font-medium text-text-primary mb-1">
                  {level.name}
                </h3>
                <p className="text-sm text-secondary mb-2">
                  {level.description}
                </p>
                <div className="flex justify-between text-xs text-secondary">
                  <span>Duration: {level.duration}</span>
                  <span>Complexity: {level.complexity}</span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {projectData.category && (
          <div>
            <label className="block text-sm font-medium text-text-primary mb-4">
              Choose a Template (Optional)
            </label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {projectTemplates
                .filter(template => template.category === projectData.category)
                .map((template) => (
                <button
                  key={template.id}
                  onClick={() => handleInputChange('template', template.id)}
                  className={`
                    rounded-lg border-2 text-left transition-all duration-200 ease-out overflow-hidden
                    ${projectData.template === template.id 
                      ? 'border-primary bg-primary-50' :'border-border hover:border-secondary-300 bg-surface'
                    }
                  `}
                >
                  <div className="aspect-video overflow-hidden">
                    <Image
                      src={template.image}
                      alt={template.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-4">
                    <h3 className="font-medium text-text-primary mb-1">
                      {template.name}
                    </h3>
                    <p className="text-sm text-secondary mb-3">
                      {template.description}
                    </p>
                    <div className="flex flex-wrap gap-1">
                      {template.features.map((feature) => (
                        <span key={feature} className="text-xs bg-secondary-100 text-secondary-700 px-2 py-1 rounded">
                          {feature}
                        </span>
                      ))}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );

  const TeamRequirementsStep = () => (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-heading font-semibold text-text-primary mb-2">
          Team Requirements
        </h2>
        <p className="text-secondary">
          Define your ideal team composition and required skills
        </p>
      </div>

      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-text-primary mb-4">
            Desired Team Size *
          </label>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            {[2, 3, 4, 5, 6].map((size) => (
              <button
                key={size}
                onClick={() => handleInputChange('teamSize', size)}
                className={`
                  p-4 rounded-lg border-2 text-center transition-all duration-200 ease-out
                  ${projectData.teamSize === size 
                    ? 'border-primary bg-primary-50 text-primary' :'border-border hover:border-secondary-300 bg-surface'
                  }
                `}
              >
                <div className="text-2xl font-bold mb-1">{size}</div>
                <div className="text-xs text-secondary">
                  {size === 2 ? 'Pair' : size === 3 ? 'Small' : size <= 4 ? 'Medium' : 'Large'} Team
                </div>
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-text-primary mb-4">
            Required Skills & Technologies *
          </label>
          <div className="flex flex-wrap gap-2 mb-4">
            {availableSkills.map((skill) => (
              <button
                key={skill}
                onClick={() => handleSkillToggle(skill)}
                className={`
                  px-3 py-2 rounded-md text-sm font-medium transition-all duration-150 ease-out
                  ${projectData.requiredSkills.includes(skill)
                    ? 'bg-primary text-white' :'bg-secondary-100 text-secondary-700 hover:bg-secondary-200'
                  }
                `}
              >
                {skill}
              </button>
            ))}
          </div>
          <p className="text-sm text-secondary">
            Selected: {projectData.requiredSkills.length} skills
          </p>
        </div>

        <div>
          <label className="block text-sm font-medium text-text-primary mb-4">
            Team Roles Needed *
          </label>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {teamRoles.map((role) => (
              <button
                key={role.id}
                onClick={() => handleRoleToggle(role.id)}
                className={`
                  p-4 rounded-lg border-2 text-left transition-all duration-200 ease-out
                  ${projectData.roles.includes(role.id)
                    ? 'border-primary bg-primary-50' :'border-border hover:border-secondary-300 bg-surface'
                  }
                `}
              >
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-medium text-text-primary">
                    {role.name}
                  </h3>
                  {projectData.roles.includes(role.id) && (
                    <Icon name="Check" size={16} className="text-primary" />
                  )}
                </div>
                <p className="text-sm text-secondary mb-3">
                  {role.description}
                </p>
                <div className="flex flex-wrap gap-1">
                  {role.skills.slice(0, 3).map((skill) => (
                    <span key={skill} className="text-xs bg-secondary-100 text-secondary-700 px-2 py-1 rounded">
                      {skill}
                    </span>
                  ))}
                  {role.skills.length > 3 && (
                    <span className="text-xs text-secondary">
                      +{role.skills.length - 3} more
                    </span>
                  )}
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  const PlanningTimelineStep = () => (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-heading font-semibold text-text-primary mb-2">
          Planning & Timeline
        </h2>
        <p className="text-secondary">
          Set up your project timeline and key milestones
        </p>
      </div>

      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-text-primary mb-4">
            Project Timeline *
          </label>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
            {[
              { value: '2-weeks', label: '2 Weeks', desc: 'Quick sprint' },
              { value: '1-month', label: '1 Month', desc: 'Standard project' },
              { value: '2-months', label: '2 Months', desc: 'Extended project' },
              { value: '3-months', label: '3+ Months', desc: 'Long-term project' }
            ].map((timeline) => (
              <button
                key={timeline.value}
                onClick={() => handleInputChange('timeline', timeline.value)}
                className={`
                  p-4 rounded-lg border-2 text-center transition-all duration-200 ease-out
                  ${projectData.timeline === timeline.value 
                    ? 'border-primary bg-primary-50 text-primary' :'border-border hover:border-secondary-300 bg-surface'
                  }
                `}
              >
                <div className="font-medium mb-1">{timeline.label}</div>
                <div className="text-xs text-secondary">{timeline.desc}</div>
              </button>
            ))}
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-4">
            <label className="text-sm font-medium text-text-primary">
              Project Milestones *
            </label>
            <button
              onClick={addMilestone}
              className="btn-secondary text-sm"
            >
              <Icon name="Plus" size={16} className="mr-1" />
              Add Milestone
            </button>
          </div>
          
          {projectData.milestones.length === 0 ? (
            <div className="text-center py-8 bg-secondary-50 rounded-lg border-2 border-dashed border-secondary-200">
              <Icon name="Target" size={48} className="text-secondary mx-auto mb-3" />
              <p className="text-secondary mb-4">No milestones added yet</p>
              <button
                onClick={addMilestone}
                className="btn-primary"
              >
                Add Your First Milestone
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {projectData.milestones.map((milestone, index) => (
                <div key={milestone.id} className="card p-4">
                  <div className="flex items-start space-x-4">
                    <div className="w-8 h-8 bg-primary-100 text-primary rounded-full flex items-center justify-center text-sm font-medium flex-shrink-0">
                      {index + 1}
                    </div>
                    <div className="flex-1 space-y-3">
                      <input
                        type="text"
                        value={milestone.title}
                        onChange={(e) => updateMilestone(milestone.id, 'title', e.target.value)}
                        placeholder="Milestone title"
                        className="input-field"
                      />
                      <textarea
                        value={milestone.description}
                        onChange={(e) => updateMilestone(milestone.id, 'description', e.target.value)}
                        placeholder="Describe what needs to be accomplished"
                        className="input-field min-h-[80px] resize-none"
                      />
                      <input
                        type="date"
                        value={milestone.dueDate}
                        onChange={(e) => updateMilestone(milestone.id, 'dueDate', e.target.value)}
                        className="input-field"
                      />
                    </div>
                    <button
                      onClick={() => removeMilestone(milestone.id)}
                      className="p-2 text-error hover:bg-error-50 rounded-lg transition-colors duration-150"
                    >
                      <Icon name="Trash2" size={16} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-text-primary mb-2">
            Key Deliverables
          </label>
          <textarea
            value={projectData.deliverables.join('\n')}
            onChange={(e) => handleInputChange('deliverables', e.target.value.split('\n').filter(d => d.trim()))}
            placeholder="List the main deliverables (one per line)&#10;Example:&#10;- Working web application&#10;- Source code repository&#10;- Documentation&#10;- Deployment guide"
            className="input-field min-h-[120px] resize-none"
          />
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      <StepIndicator />
      
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Auto-save indicator */}
        {(isAutoSaving || lastSaved) && (
          <div className="mb-6 p-3 bg-secondary-50 rounded-lg flex items-center space-x-2 text-sm text-secondary">
            {isAutoSaving ? (
              <>
                <Icon name="Loader2" size={16} className="animate-spin" />
                <span>Auto-saving...</span>
              </>
            ) : (
              <>
                <Icon name="Check" size={16} className="text-accent" />
                <span>Last saved: {lastSaved?.toLocaleTimeString()}</span>
              </>
            )}
          </div>
        )}

        {/* Step Content */}
        <div className="mb-8">
          {currentStep === 1 && <ProjectBasicsStep />}
          {currentStep === 2 && <TeamRequirementsStep />}
          {currentStep === 3 && <PlanningTimelineStep />}
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-between pt-6 border-t border-border">
          <div className="flex space-x-3">
            <button
              onClick={handleSaveDraft}
              className="btn-secondary"
            >
              <Icon name="Save" size={16} className="mr-2" />
              Save Draft
            </button>
          </div>

          <div className="flex space-x-3">
            {currentStep > 1 && (
              <button
                onClick={prevStep}
                className="btn-secondary"
              >
                <Icon name="ArrowLeft" size={16} className="mr-2" />
                Previous
              </button>
            )}
            
            {currentStep < 3 ? (
              <button
                onClick={nextStep}
                disabled={!validateCurrentStep()}
                className={`btn-primary ${!validateCurrentStep() ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                Next
                <Icon name="ArrowRight" size={16} className="ml-2" />
              </button>
            ) : (
              <button
                onClick={handlePublishProject}
                disabled={!validateCurrentStep()}
                className={`btn-primary ${!validateCurrentStep() ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                <Icon name="Rocket" size={16} className="mr-2" />
                Publish Project
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectCreation;