import React from 'react';
import Icon from 'components/AppIcon';

const QuickStats = ({ user }) => {
  const stats = [
    {
      label: 'Active Projects',
      value: user.activeProjects,
      icon: 'FolderOpen',
      color: 'text-primary',
      bgColor: 'bg-primary-50',
      change: '+2 this month'
    },
    {
      label: 'Completed',
      value: user.completedProjects,
      icon: 'CheckCircle',
      color: 'text-accent',
      bgColor: 'bg-accent-50',
      change: '+3 this month'
    },
    {
      label: 'Skills',
      value: user.skillsCount,
      icon: 'Award',
      color: 'text-warning',
      bgColor: 'bg-warning-50',
      change: '+1 this week'
    },
    {
      label: 'Team Rating',
      value: user.teamRating,
      icon: 'Star',
      color: 'text-error',
      bgColor: 'bg-error-50',
      change: '+0.2 this month',
      suffix: '/5.0'
    }
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat, index) => (
        <div key={index} className="bg-surface rounded-xl p-4 card">
          <div className="flex items-center justify-between mb-3">
            <div className={`w-10 h-10 ${stat.bgColor} rounded-lg flex items-center justify-center`}>
              <Icon name={stat.icon} size={20} className={stat.color} />
            </div>
          </div>
          
          <div className="space-y-1">
            <div className="flex items-baseline space-x-1">
              <span className="text-2xl font-bold text-text-primary">
                {stat.value}
              </span>
              {stat.suffix && (
                <span className="text-sm text-text-secondary">
                  {stat.suffix}
                </span>
              )}
            </div>
            <p className="text-xs text-text-secondary font-medium">
              {stat.label}
            </p>
            <p className="text-xs text-accent font-medium">
              {stat.change}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default QuickStats;