import React from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from 'components/AppIcon';
import Image from 'components/AppImage';

const RecentActivity = () => {
  const navigate = useNavigate();

  // Mock recent activity data
  const recentActivities = [
    {
      id: 1,
      type: 'project_update',
      user: {
        name: "Sarah Kim",
        avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=40&h=40&fit=crop&crop=face"
      },
      action: "completed the UI mockups for",
      target: "EcoTracker Mobile App",
      timestamp: new Date(Date.now() - 1800000), // 30 minutes ago
      projectId: 1
    },
    {
      id: 2,
      type: 'team_join',
      user: {
        name: "Mike Chen",
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&crop=face"
      },
      action: "joined the team for",
      target: "StudyBuddy Platform",
      timestamp: new Date(Date.now() - 3600000), // 1 hour ago
      projectId: 2
    },
    {
      id: 3,
      type: 'milestone_completed',
      user: {
        name: "Lisa Park",
        avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop&crop=face"
      },
      action: "completed milestone \'Backend API\' for",
      target: "TaskFlow Dashboard",
      timestamp: new Date(Date.now() - 7200000), // 2 hours ago
      projectId: 3
    },
    {
      id: 4,
      type: 'comment',
      user: {
        name: "John Doe",
        avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face"
      },
      action: "commented on task \'Database Schema\' in",
      target: "StudyBuddy Platform",
      timestamp: new Date(Date.now() - 10800000), // 3 hours ago
      projectId: 2
    },
    {
      id: 5,
      type: 'file_upload',
      user: {
        name: "Emma Wilson",
        avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=40&h=40&fit=crop&crop=face"
      },
      action: "uploaded design files to",
      target: "EcoTracker Mobile App",
      timestamp: new Date(Date.now() - 14400000), // 4 hours ago
      projectId: 1
    },
    {
      id: 6,
      type: 'task_assigned',
      user: {
        name: "David Lee",
        avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop&crop=face"
      },
      action: "assigned you a task in",
      target: "TaskFlow Dashboard",
      timestamp: new Date(Date.now() - 18000000), // 5 hours ago
      projectId: 3
    }
  ];

  const getActivityIcon = (type) => {
    switch (type) {
      case 'project_update': return 'GitCommit';
      case 'team_join': return 'UserPlus';
      case 'milestone_completed': return 'CheckCircle';
      case 'comment': return 'MessageCircle';
      case 'file_upload': return 'Upload';
      case 'task_assigned': return 'UserCheck';
      default: return 'Activity';
    }
  };

  const getActivityColor = (type) => {
    switch (type) {
      case 'project_update': return 'text-primary bg-primary-50';
      case 'team_join': return 'text-accent bg-accent-50';
      case 'milestone_completed': return 'text-accent bg-accent-50';
      case 'comment': return 'text-warning bg-warning-50';
      case 'file_upload': return 'text-secondary bg-secondary-100';
      case 'task_assigned': return 'text-error bg-error-50';
      default: return 'text-secondary bg-secondary-100';
    }
  };

  const formatTimestamp = (timestamp) => {
    const now = new Date();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    return `${days}d ago`;
  };

  const handleActivityClick = (activity) => {
    if (activity.projectId) {
      navigate(`/project-details/${activity.projectId}`);
    }
  };

  const handleViewAllActivity = () => {
    navigate('/team-workspace');
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold text-text-primary">
          Team Updates
        </h2>
        <button
          onClick={handleViewAllActivity}
          className="text-primary hover:text-primary-700 text-sm font-medium transition-colors duration-150"
        >
          View All
        </button>
      </div>

      <div className="bg-surface rounded-xl card">
        <div className="divide-y divide-border">
          {recentActivities.map((activity, index) => (
            <div
              key={activity.id}
              className={`p-4 hover:bg-secondary-50 transition-colors duration-150 cursor-pointer ${
                index === 0 ? 'rounded-t-xl' : ''
              } ${index === recentActivities.length - 1 ? 'rounded-b-xl' : ''}`}
              onClick={() => handleActivityClick(activity)}
            >
              <div className="flex items-start space-x-3">
                <div className="relative flex-shrink-0">
                  <Image
                    src={activity.user.avatar}
                    alt={activity.user.name}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                  <div className={`absolute -bottom-1 -right-1 w-6 h-6 rounded-full flex items-center justify-center ${getActivityColor(activity.type)}`}>
                    <Icon name={getActivityIcon(activity.type)} size={12} />
                  </div>
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <p className="text-sm text-text-primary">
                        <span className="font-medium">{activity.user.name}</span>
                        {' '}
                        <span className="text-text-secondary">{activity.action}</span>
                        {' '}
                        <span className="font-medium text-primary">{activity.target}</span>
                      </p>
                      <p className="text-xs text-text-secondary mt-1">
                        {formatTimestamp(activity.timestamp)}
                      </p>
                    </div>
                    
                    <button className="p-1 rounded-md hover:bg-secondary-100 transition-colors duration-150 ml-2">
                      <Icon name="ChevronRight" size={16} className="text-secondary-600" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {recentActivities.length === 0 && (
          <div className="p-8 text-center">
            <div className="w-16 h-16 bg-secondary-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Icon name="Activity" size={32} className="text-secondary-600" />
            </div>
            <h3 className="font-semibold text-text-primary mb-2">
              No Recent Activity
            </h3>
            <p className="text-text-secondary text-sm">
              Team updates and project activities will appear here.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default RecentActivity;