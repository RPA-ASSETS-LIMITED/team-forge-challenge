import React from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from 'components/AppIcon';
import Image from 'components/AppImage';

const ActiveProjects = ({ onRefresh }) => {
  const navigate = useNavigate();

  // Mock active projects data
  const activeProjects = [
    {
      id: 1,
      title: "EcoTracker Mobile App",
      description: "A React Native app for tracking personal carbon footprint with gamification elements.",
      progress: 75,
      dueDate: "2024-02-15",
      priority: "high",
      team: {
        size: 4,
        members: [
          { id: 1, name: "Sarah Kim", avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=40&h=40&fit=crop&crop=face" },
          { id: 2, name: "Mike Chen", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&crop=face" },
          { id: 3, name: "Lisa Park", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop&crop=face" }
        ]
      },
      nextMilestone: "UI/UX Design Review",
      technologies: ["React Native", "Node.js", "MongoDB"],
      status: "in-progress"
    },
    {
      id: 2,
      title: "StudyBuddy Platform",
      description: "Web platform connecting students for collaborative learning and study groups.",
      progress: 45,
      dueDate: "2024-03-01",
      priority: "medium",
      team: {
        size: 5,
        members: [
          { id: 4, name: "John Doe", avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face" },
          { id: 5, name: "Emma Wilson", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=40&h=40&fit=crop&crop=face" }
        ]
      },
      nextMilestone: "Backend API Development",
      technologies: ["React", "Express.js", "PostgreSQL"],
      status: "planning"
    },
    {
      id: 3,
      title: "TaskFlow Dashboard",
      description: "Project management dashboard with real-time collaboration features.",
      progress: 90,
      dueDate: "2024-01-30",
      priority: "high",
      team: {
        size: 3,
        members: [
          { id: 6, name: "David Lee", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop&crop=face" },
          { id: 7, name: "Anna Smith", avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=40&h=40&fit=crop&crop=face" }
        ]
      },
      nextMilestone: "Final Testing & Deployment",
      technologies: ["Vue.js", "Firebase", "Tailwind CSS"],
      status: "testing"
    }
  ];

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return 'text-error bg-error-50 border-error-200';
      case 'medium': return 'text-warning bg-warning-50 border-warning-200';
      case 'low': return 'text-accent bg-accent-50 border-accent-200';
      default: return 'text-secondary bg-secondary-100 border-secondary-200';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'in-progress': return 'text-primary bg-primary-50';
      case 'planning': return 'text-warning bg-warning-50';
      case 'testing': return 'text-accent bg-accent-50';
      case 'completed': return 'text-accent bg-accent-50';
      default: return 'text-secondary bg-secondary-100';
    }
  };

  const getDaysUntilDue = (dueDate) => {
    const today = new Date();
    const due = new Date(dueDate);
    const diffTime = due - today;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const handleProjectClick = (projectId) => {
    navigate(`/project-details/${projectId}`);
  };

  const handleViewAllProjects = () => {
    navigate('/project-portfolio-gallery');
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold text-text-primary">
          My Active Projects
        </h2>
        <button
          onClick={handleViewAllProjects}
          className="text-primary hover:text-primary-700 text-sm font-medium transition-colors duration-150"
        >
          View All
        </button>
      </div>

      {/* Mobile: Horizontal Scroll */}
      <div className="lg:hidden">
        <div className="flex space-x-4 overflow-x-auto pb-4 -mx-4 px-4">
          {activeProjects.map((project) => (
            <div
              key={project.id}
              className="flex-shrink-0 w-80 bg-surface rounded-xl p-6 card cursor-pointer hover:shadow-prominent transition-all duration-200"
              onClick={() => handleProjectClick(project.id)}
            >
              <ProjectCard project={project} getDaysUntilDue={getDaysUntilDue} getPriorityColor={getPriorityColor} getStatusColor={getStatusColor} />
            </div>
          ))}
        </div>
      </div>

      {/* Desktop: Grid Layout */}
      <div className="hidden lg:grid lg:grid-cols-1 lg:gap-4">
        {activeProjects.map((project) => (
          <div
            key={project.id}
            className="bg-surface rounded-xl p-6 card cursor-pointer hover:shadow-prominent transition-all duration-200"
            onClick={() => handleProjectClick(project.id)}
          >
            <ProjectCard project={project} getDaysUntilDue={getDaysUntilDue} getPriorityColor={getPriorityColor} getStatusColor={getStatusColor} />
          </div>
        ))}
      </div>

      {activeProjects.length === 0 && (
        <div className="bg-surface rounded-xl p-8 card text-center">
          <div className="w-16 h-16 bg-secondary-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Icon name="FolderOpen" size={32} className="text-secondary-600" />
          </div>
          <h3 className="font-semibold text-text-primary mb-2">
            No Active Projects
          </h3>
          <p className="text-text-secondary text-sm mb-4">
            Start your journey by creating a new project or joining an existing team.
          </p>
          <button
            onClick={() => navigate('/project-creation')}
            className="btn-primary"
          >
            Create Your First Project
          </button>
        </div>
      )}
    </div>
  );
};

const ProjectCard = ({ project, getDaysUntilDue, getPriorityColor, getStatusColor }) => {
  const daysUntilDue = getDaysUntilDue(project.dueDate);
  
  return (
    <>
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <div className="flex items-center space-x-2 mb-2">
            <h3 className="font-semibold text-text-primary line-clamp-1">
              {project.title}
            </h3>
            <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getPriorityColor(project.priority)}`}>
              {project.priority}
            </span>
          </div>
          <p className="text-text-secondary text-sm line-clamp-2 mb-3">
            {project.description}
          </p>
        </div>
      </div>

      <div className="space-y-4">
        {/* Progress Bar */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-text-secondary">Progress</span>
            <span className="text-sm font-semibold text-text-primary">{project.progress}%</span>
          </div>
          <div className="w-full bg-secondary-200 rounded-full h-2">
            <div
              className="bg-primary h-2 rounded-full transition-all duration-300"
              style={{ width: `${project.progress}%` }}
            />
          </div>
        </div>

        {/* Team Members */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="flex -space-x-2">
              {project.team.members.slice(0, 3).map((member) => (
                <Image
                  key={member.id}
                  src={member.avatar}
                  alt={member.name}
                  className="w-8 h-8 rounded-full border-2 border-surface object-cover"
                />
              ))}
              {project.team.size > 3 && (
                <div className="w-8 h-8 bg-secondary-200 rounded-full border-2 border-surface flex items-center justify-center">
                  <span className="text-xs font-medium text-secondary-700">
                    +{project.team.size - 3}
                  </span>
                </div>
              )}
            </div>
            <span className="text-sm text-text-secondary">
              {project.team.size} members
            </span>
          </div>
          
          <div className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(project.status)}`}>
            {project.status.replace('-', ' ')}
          </div>
        </div>

        {/* Next Milestone & Due Date */}
        <div className="flex items-center justify-between pt-2 border-t border-border">
          <div className="flex items-center space-x-2">
            <Icon name="Target" size={16} className="text-secondary-600" />
            <span className="text-sm text-text-secondary">
              {project.nextMilestone}
            </span>
          </div>
          
          <div className="flex items-center space-x-1">
            <Icon name="Calendar" size={16} className="text-secondary-600" />
            <span className={`text-sm font-medium ${daysUntilDue <= 3 ? 'text-error' : 'text-text-secondary'}`}>
              {daysUntilDue > 0 ? `${daysUntilDue} days left` : 'Overdue'}
            </span>
          </div>
        </div>

        {/* Technologies */}
        <div className="flex flex-wrap gap-1">
          {project.technologies.slice(0, 3).map((tech) => (
            <span
              key={tech}
              className="px-2 py-1 bg-secondary-100 text-secondary-700 rounded text-xs font-medium"
            >
              {tech}
            </span>
          ))}
          {project.technologies.length > 3 && (
            <span className="px-2 py-1 bg-secondary-100 text-secondary-700 rounded text-xs font-medium">
              +{project.technologies.length - 3}
            </span>
          )}
        </div>
      </div>
    </>
  );
};

export default ActiveProjects;