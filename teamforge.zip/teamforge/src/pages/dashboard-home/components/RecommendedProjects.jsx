import React from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from 'components/AppIcon';
import Image from 'components/AppImage';

const RecommendedProjects = () => {
  const navigate = useNavigate();

  // Mock recommended projects data
  const recommendedProjects = [
    {
      id: 101,
      title: "AI-Powered Recipe Generator",
      description: "Build a smart recipe recommendation system using machine learning to suggest meals based on dietary preferences and available ingredients.",
      difficulty: "intermediate",
      duration: "6-8 weeks",
      teamSize: 4,
      openSpots: 2,
      skills: ["Python", "TensorFlow", "React", "API Design"],
      matchScore: 95,
      creator: {
        name: "Alex Rodriguez",
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&crop=face",
        rating: 4.9
      },
      category: "AI/ML",
      urgency: "high",
      applications: 12
    },
    {
      id: 102,
      title: "Sustainable Fashion Marketplace",
      description: "Create an e-commerce platform connecting eco-conscious consumers with sustainable fashion brands and second-hand clothing sellers.",
      difficulty: "beginner",
      duration: "4-6 weeks",
      teamSize: 5,
      openSpots: 3,
      skills: ["React", "Node.js", "MongoDB", "Stripe API"],
      matchScore: 88,
      creator: {
        name: "Maya Patel",
        avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=40&h=40&fit=crop&crop=face",
        rating: 4.7
      },
      category: "E-commerce",
      urgency: "medium",
      applications: 8
    },
    {
      id: 103,
      title: "Mental Health Support Bot",
      description: "Develop a compassionate chatbot that provides mental health resources, mood tracking, and connects users with professional help when needed.",
      difficulty: "advanced",
      duration: "8-10 weeks",
      teamSize: 6,
      openSpots: 1,
      skills: ["NLP", "Python", "React Native", "Psychology"],
      matchScore: 82,
      creator: {
        name: "Dr. Sarah Chen",
        avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop&crop=face",
        rating: 5.0
      },
      category: "Healthcare",
      urgency: "high",
      applications: 15
    }
  ];

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'beginner': return 'text-accent bg-accent-50 border-accent-200';
      case 'intermediate': return 'text-warning bg-warning-50 border-warning-200';
      case 'advanced': return 'text-error bg-error-50 border-error-200';
      default: return 'text-secondary bg-secondary-100 border-secondary-200';
    }
  };

  const getUrgencyColor = (urgency) => {
    switch (urgency) {
      case 'high': return 'text-error';
      case 'medium': return 'text-warning';
      case 'low': return 'text-accent';
      default: return 'text-secondary';
    }
  };

  const handleJoinProject = (projectId) => {
    // In a real app, this would send a join request
    console.log(`Joining project ${projectId}`);
    navigate(`/project-details/${projectId}`);
  };

  const handleViewAllRecommendations = () => {
    navigate('/project-discovery');
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold text-text-primary">
          Recommended for You
        </h2>
        <button
          onClick={handleViewAllRecommendations}
          className="text-primary hover:text-primary-700 text-sm font-medium transition-colors duration-150"
        >
          View All
        </button>
      </div>

      <div className="space-y-4">
        {recommendedProjects.map((project) => (
          <div key={project.id} className="bg-surface rounded-xl p-6 card hover:shadow-prominent transition-all duration-200">
            {/* Header */}
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-2">
                  <h3 className="font-semibold text-text-primary line-clamp-1">
                    {project.title}
                  </h3>
                  <div className="flex items-center space-x-1">
                    <Icon name="Zap" size={14} className="text-warning" />
                    <span className="text-xs font-bold text-warning">
                      {project.matchScore}% match
                    </span>
                  </div>
                </div>
                <p className="text-text-secondary text-sm line-clamp-2 mb-3">
                  {project.description}
                </p>
              </div>
            </div>

            {/* Project Details */}
            <div className="space-y-3 mb-4">
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center space-x-4">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getDifficultyColor(project.difficulty)}`}>
                    {project.difficulty}
                  </span>
                  <div className="flex items-center space-x-1 text-text-secondary">
                    <Icon name="Clock" size={14} />
                    <span>{project.duration}</span>
                  </div>
                  <div className="flex items-center space-x-1 text-text-secondary">
                    <Icon name="Users" size={14} />
                    <span>{project.openSpots}/{project.teamSize} spots</span>
                  </div>
                </div>
                <div className={`flex items-center space-x-1 ${getUrgencyColor(project.urgency)}`}>
                  <Icon name="AlertCircle" size={14} />
                  <span className="text-xs font-medium">{project.urgency} priority</span>
                </div>
              </div>

              {/* Skills */}
              <div className="flex flex-wrap gap-1">
                {project.skills.slice(0, 3).map((skill) => (
                  <span
                    key={skill}
                    className="px-2 py-1 bg-primary-50 text-primary-700 rounded text-xs font-medium"
                  >
                    {skill}
                  </span>
                ))}
                {project.skills.length > 3 && (
                  <span className="px-2 py-1 bg-secondary-100 text-secondary-700 rounded text-xs font-medium">
                    +{project.skills.length - 3}
                  </span>
                )}
              </div>

              {/* Creator Info */}
              <div className="flex items-center justify-between pt-3 border-t border-border">
                <div className="flex items-center space-x-2">
                  <Image
                    src={project.creator.avatar}
                    alt={project.creator.name}
                    className="w-6 h-6 rounded-full object-cover"
                  />
                  <span className="text-sm text-text-secondary">
                    by {project.creator.name}
                  </span>
                  <div className="flex items-center space-x-1">
                    <Icon name="Star" size={12} className="text-warning" />
                    <span className="text-xs text-text-secondary">
                      {project.creator.rating}
                    </span>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2 text-xs text-text-secondary">
                  <Icon name="Users" size={12} />
                  <span>{project.applications} applied</span>
                </div>
              </div>
            </div>

            {/* Action Button */}
            <button
              onClick={() => handleJoinProject(project.id)}
              className="w-full btn-primary text-sm"
            >
              <Icon name="UserPlus" size={16} className="mr-2" />
              Request to Join
            </button>
          </div>
        ))}
      </div>

      {recommendedProjects.length === 0 && (
        <div className="bg-surface rounded-xl p-8 card text-center">
          <div className="w-16 h-16 bg-secondary-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Icon name="Search" size={32} className="text-secondary-600" />
          </div>
          <h3 className="font-semibold text-text-primary mb-2">
            No Recommendations Yet
          </h3>
          <p className="text-text-secondary text-sm mb-4">
            Complete your profile and add skills to get personalized project recommendations.
          </p>
          <button
            onClick={() => navigate('/user-profile')}
            className="btn-primary"
          >
            Complete Profile
          </button>
        </div>
      )}
    </div>
  );
};

export default RecommendedProjects;