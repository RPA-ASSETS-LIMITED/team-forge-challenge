import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from 'components/AppIcon';
import Image from 'components/AppImage';
import { useNotifications } from 'components/ui/NotificationBadgeSystem';
import RecentActivity from './components/RecentActivity';
import QuickStats from './components/QuickStats';
import ActiveProjects from './components/ActiveProjects';
import RecommendedProjects from './components/RecommendedProjects';

const DashboardHome = () => {
  const navigate = useNavigate();
  const { markAsRead } = useNotifications();
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [greeting, setGreeting] = useState('');

  // Mock user data
  const currentUser = {
    id: 1,
    name: "Alex Chen",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
    role: "Full Stack Developer",
    joinedDate: "2024-01-15",
    completedProjects: 8,
    activeProjects: 3,
    skillsCount: 12,
    teamRating: 4.8
  };

  // Set greeting based on time of day
  useEffect(() => {
    const hour = new Date().getHours();
    if (hour < 12) setGreeting('Good morning');
    else if (hour < 18) setGreeting('Good afternoon');
    else setGreeting('Good evening');
    
    // Mark dashboard notifications as read when component mounts
    markAsRead('dashboard');
  }, [markAsRead]);

  const handlePullToRefresh = async () => {
    setIsRefreshing(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsRefreshing(false);
  };

  const handleCreateProject = () => {
    navigate('/project-creation');
  };

  const handleDiscoverProjects = () => {
    navigate('/project-discovery');
  };

  const handleViewTeams = () => {
    navigate('/team-workspace');
  };

  const handleViewProfile = () => {
    navigate('/user-profile');
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Pull to refresh indicator */}
      {isRefreshing && (
        <div className="fixed top-16 left-1/2 transform -translate-x-1/2 z-50 bg-primary text-white px-4 py-2 rounded-full shadow-lg animation-slide-up">
          <div className="flex items-center space-x-2">
            <div className="animate-spin">
              <Icon name="RefreshCw" size={16} />
            </div>
            <span className="text-sm font-medium">Refreshing...</span>
          </div>
        </div>
      )}

      <div className="px-4 py-6 space-y-6">
        {/* Welcome Section */}
        <div className="bg-surface rounded-xl p-6 card-prominent">
          <div className="flex items-center space-x-4">
            <div className="relative">
              <Image
                src={currentUser.avatar}
                alt={currentUser.name}
                className="w-16 h-16 rounded-full object-cover"
              />
              <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-accent rounded-full border-2 border-surface flex items-center justify-center">
                <Icon name="CheckCircle" size={14} color="white" />
              </div>
            </div>
            <div className="flex-1">
              <h1 className="text-xl font-semibold text-text-primary">
                {greeting}, {currentUser.name}!
              </h1>
              <p className="text-text-secondary text-sm">
                Ready to collaborate on amazing projects today?
              </p>
            </div>
            <button
              onClick={handleViewProfile}
              className="p-2 rounded-lg hover:bg-secondary-100 transition-colors duration-150"
              aria-label="View profile"
            >
              <Icon name="Settings" size={20} className="text-secondary-600" />
            </button>
          </div>
        </div>

        {/* Quick Stats */}
        <QuickStats user={currentUser} />

        {/* Quick Actions */}
        <div className="grid grid-cols-2 gap-4">
          <button
            onClick={handleCreateProject}
            className="bg-primary text-white p-4 rounded-xl flex flex-col items-center space-y-2 hover:bg-primary-700 transition-all duration-150 transform hover:scale-[0.98]"
          >
            <Icon name="Plus" size={24} />
            <span className="font-medium text-sm">Create Project</span>
          </button>
          <button
            onClick={handleDiscoverProjects}
            className="bg-accent text-white p-4 rounded-xl flex flex-col items-center space-y-2 hover:bg-accent-600 transition-all duration-150 transform hover:scale-[0.98]"
          >
            <Icon name="Search" size={24} />
            <span className="font-medium text-sm">Discover</span>
          </button>
        </div>

        {/* Desktop Layout */}
        <div className="hidden lg:grid lg:grid-cols-12 lg:gap-6">
          {/* Left Column - Active Projects */}
          <div className="lg:col-span-8 space-y-6">
            <ActiveProjects onRefresh={handlePullToRefresh} />
            <RecentActivity />
          </div>
          
          {/* Right Column - Recommendations & Stats */}
          <div className="lg:col-span-4 space-y-6">
            <RecommendedProjects />
          </div>
        </div>

        {/* Mobile Layout */}
        <div className="lg:hidden space-y-6">
          <ActiveProjects onRefresh={handlePullToRefresh} />
          <RecentActivity />
          <RecommendedProjects />
        </div>

        {/* Team Invitation Banner */}
        <div className="bg-gradient-to-r from-primary-50 to-accent-50 rounded-xl p-6 border border-primary-200">
          <div className="flex items-start space-x-4">
            <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
              <Icon name="Users" size={24} color="white" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-text-primary mb-2">
                Join a Team Today
              </h3>
              <p className="text-text-secondary text-sm mb-4">
                Connect with like-minded developers and start building amazing projects together.
              </p>
              <button
                onClick={handleViewTeams}
                className="btn-primary text-sm"
              >
                Explore Teams
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Spacing for Mobile Navigation */}
        <div className="h-4 lg:hidden" />
      </div>
    </div>
  );
};

export default DashboardHome;