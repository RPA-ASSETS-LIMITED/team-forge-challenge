import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from 'components/AppIcon';

import ProjectCard from './components/ProjectCard';
import ProjectDetailModal from './components/ProjectDetailModal';
import FilterPanel from './components/FilterPanel';
import FeaturedProjectsSection from './components/FeaturedProjectsSection';

const ProjectPortfolioGallery = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilters, setSelectedFilters] = useState({
    category: '',
    technology: '',
    teamSize: '',
    completionDate: ''
  });
  const [viewMode, setViewMode] = useState('grid'); // grid or list
  const [selectedProject, setSelectedProject] = useState(null);
  const [showFilters, setShowFilters] = useState(false);

  // Mock data for completed projects
  const projects = [
    {
      id: 1,
      title: "EcoTracker - Sustainability Dashboard",
      description: "A comprehensive web application that helps users track their carbon footprint and environmental impact through daily activities.",
      category: "web-app",
      technologies: ["React", "Node.js", "MongoDB", "Chart.js"],
      teamSize: 4,
      completionDate: "2024-01-15",
      thumbnail: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=400&h=250&fit=crop",
      liveDemo: "https://ecotracker-demo.com",
      featured: true,
      complexity: "intermediate",
      viewCount: 1247,
      rating: 4.8,
      team: [
        { name: "Sarah Chen", role: "Frontend Lead", avatar: "https://randomuser.me/api/portraits/women/32.jpg" },
        { name: "Marcus Johnson", role: "Backend Developer", avatar: "https://randomuser.me/api/portraits/men/45.jpg" },
        { name: "Elena Rodriguez", role: "UI/UX Designer", avatar: "https://randomuser.me/api/portraits/women/68.jpg" },
        { name: "David Kim", role: "Data Analyst", avatar: "https://randomuser.me/api/portraits/men/22.jpg" }
      ],
      timeline: "3 months",
      challenges: `The main challenge was integrating multiple data sources for carbon footprint calculations while maintaining real-time performance. We solved this by implementing a caching layer and optimizing our database queries.

Our team also faced difficulties in creating an intuitive data visualization that could handle complex environmental metrics without overwhelming users.`,
      userFeedback: [
        { user: "GreenTech Enthusiast", rating: 5, comment: "Amazing tool! Finally something that makes tracking environmental impact simple and engaging." },
        { user: "Sustainability Consultant", rating: 4, comment: "Great concept and execution. Would love to see more detailed reporting features." }
      ],
      metrics: {
        activeUsers: "2.3K",
        dataPoints: "45K+",
        co2Saved: "12.5 tons"
      }
    },
    {
      id: 2,
      title: "StudyBuddy - Collaborative Learning Platform",
      description: "Mobile-first platform connecting students for group study sessions, note sharing, and peer-to-peer learning.",
      category: "mobile-app",
      technologies: ["React Native", "Firebase", "Redux", "WebRTC"],
      teamSize: 5,
      completionDate: "2023-12-20",
      thumbnail: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=400&h=250&fit=crop",
      liveDemo: "https://studybuddy-app.com",
      featured: true,
      complexity: "advanced",
      viewCount: 892,
      rating: 4.6,
      team: [
        { name: "Alex Thompson", role: "Mobile Lead", avatar: "https://randomuser.me/api/portraits/men/33.jpg" },
        { name: "Priya Patel", role: "Backend Engineer", avatar: "https://randomuser.me/api/portraits/women/44.jpg" },
        { name: "Jordan Lee", role: "Product Designer", avatar: "https://randomuser.me/api/portraits/men/55.jpg" },
        { name: "Maya Singh", role: "QA Engineer", avatar: "https://randomuser.me/api/portraits/women/29.jpg" },
        { name: "Carlos Rivera", role: "DevOps", avatar: "https://randomuser.me/api/portraits/men/41.jpg" }
      ],
      timeline: "4 months",
      challenges: `Real-time video calling integration posed significant technical challenges, especially ensuring low latency across different network conditions. We implemented adaptive bitrate streaming and fallback mechanisms.

Cross-platform consistency between iOS and Android required extensive testing and platform-specific optimizations.`,
      userFeedback: [
        { user: "College Student", rating: 5, comment: "This app transformed how I study with my classmates. The video quality is excellent!" },
        { user: "Graduate Student", rating: 4, comment: "Love the note-sharing feature. Could use more organizational tools." }
      ],
      metrics: {
        downloads: "15K+",
        studySessions: "8.2K",
        avgSessionTime: "45 min"
      }
    },
    {
      id: 3,
      title: "DataViz Pro - Analytics Dashboard",
      description: "Advanced data visualization tool for business analytics with interactive charts and real-time data processing.",
      category: "data-project",
      technologies: ["Python", "D3.js", "PostgreSQL", "Docker"],
      teamSize: 3,
      completionDate: "2024-02-10",
      thumbnail: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=250&fit=crop",
      liveDemo: "https://dataviz-pro.com",
      featured: false,
      complexity: "expert",
      viewCount: 634,
      rating: 4.9,
      team: [
        { name: "Dr. Lisa Wang", role: "Data Scientist", avatar: "https://randomuser.me/api/portraits/women/51.jpg" },
        { name: "Robert Chen", role: "Full Stack Developer", avatar: "https://randomuser.me/api/portraits/men/38.jpg" },
        { name: "Amanda Foster", role: "Frontend Specialist", avatar: "https://randomuser.me/api/portraits/women/42.jpg" }
      ],
      timeline: "2.5 months",
      challenges: `Processing large datasets in real-time while maintaining smooth user interactions required careful optimization of both backend algorithms and frontend rendering.

Creating intuitive interfaces for complex statistical operations was a significant UX challenge that required multiple iterations based on user testing.`,
      userFeedback: [
        { user: "Business Analyst", rating: 5, comment: "The most intuitive data visualization tool I\'ve used. Powerful yet accessible." },
        { user: "Data Manager", rating: 5, comment: "Excellent performance even with large datasets. Great work!" }
      ],
      metrics: {
        dataProcessed: "2.1TB",
        visualizations: "500+",
        avgLoadTime: "1.2s"
      }
    },
    {
      id: 4,
      title: "TaskFlow - Project Management Suite",
      description: "Comprehensive project management application with team collaboration, time tracking, and resource allocation features.",
      category: "web-app",
      technologies: ["Vue.js", "Express.js", "MySQL", "Socket.io"],
      teamSize: 6,
      completionDate: "2023-11-30",
      thumbnail: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=400&h=250&fit=crop",
      liveDemo: "https://taskflow-pm.com",
      featured: false,
      complexity: "intermediate",
      viewCount: 1156,
      rating: 4.7,
      team: [
        { name: "Michael Brown", role: "Project Lead", avatar: "https://randomuser.me/api/portraits/men/28.jpg" },
        { name: "Sophie Turner", role: "Frontend Developer", avatar: "https://randomuser.me/api/portraits/women/35.jpg" },
        { name: "James Wilson", role: "Backend Developer", avatar: "https://randomuser.me/api/portraits/men/47.jpg" },
        { name: "Isabella Garcia", role: "UI Designer", avatar: "https://randomuser.me/api/portraits/women/26.jpg" },
        { name: "Ryan O\'Connor", role: "DevOps Engineer", avatar: "https://randomuser.me/api/portraits/men/39.jpg" },
        { name: "Zoe Adams", role: "QA Tester", avatar: "https://randomuser.me/api/portraits/women/48.jpg" }
      ],
      timeline: "5 months",
      challenges: `Implementing real-time collaboration features across multiple users required careful state management and conflict resolution strategies.

Balancing feature richness with user interface simplicity was an ongoing challenge throughout the development process.`,
      userFeedback: [
        { user: "Project Manager", rating: 5, comment: "Finally, a PM tool that doesn\'t overwhelm users with unnecessary complexity." },
        { user: "Team Lead", rating: 4, comment: "Great collaboration features. The time tracking is particularly useful." }
      ],
      metrics: {
        activeProjects: "1.8K",
        tasksCompleted: "25K+",
        teamMembers: "450+"
      }
    },
    {
      id: 5,
      title: "FitTracker - Health & Wellness App",
      description: "Personal fitness tracking application with workout planning, nutrition logging, and progress analytics.",
      category: "mobile-app",
      technologies: ["Flutter", "Firebase", "TensorFlow", "HealthKit"],
      teamSize: 4,
      completionDate: "2024-01-05",
      thumbnail: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400&h=250&fit=crop",
      liveDemo: "https://fittracker-app.com",
      featured: false,
      complexity: "intermediate",
      viewCount: 723,
      rating: 4.5,
      team: [
        { name: "Kevin Park", role: "Mobile Developer", avatar: "https://randomuser.me/api/portraits/men/31.jpg" },
        { name: "Rachel Green", role: "Health Data Specialist", avatar: "https://randomuser.me/api/portraits/women/37.jpg" },
        { name: "Tom Anderson", role: "ML Engineer", avatar: "https://randomuser.me/api/portraits/men/43.jpg" },
        { name: "Nina Patel", role: "UX Designer", avatar: "https://randomuser.me/api/portraits/women/52.jpg" }
      ],
      timeline: "3.5 months",
      challenges: `Integrating with various health APIs and ensuring data privacy compliance required extensive research and implementation of security measures.

Creating accurate fitness recommendations using machine learning while maintaining user privacy was a complex technical challenge.`,
      userFeedback: [
        { user: "Fitness Enthusiast", rating: 4, comment: "Love the personalized workout recommendations. Very motivating!" },
        { user: "Health Coach", rating: 5, comment: "Great tool for tracking client progress. The analytics are comprehensive." }
      ],
      metrics: {
        workoutsLogged: "12K+",
        caloriesTracked: "2.1M",
        avgWeeklyUse: "5.2 days"
      }
    },
    {
      id: 6,
      title: "CodeReview - Developer Collaboration Tool",
      description: "Platform for code review, pair programming, and knowledge sharing among development teams.",
      category: "web-app",
      technologies: ["React", "GraphQL", "PostgreSQL", "Redis"],
      teamSize: 5,
      completionDate: "2023-12-15",
      thumbnail: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=400&h=250&fit=crop",
      liveDemo: "https://codereview-platform.com",
      featured: false,
      complexity: "advanced",
      viewCount: 945,
      rating: 4.8,
      team: [
        { name: "Daniel Kim", role: "Senior Developer", avatar: "https://randomuser.me/api/portraits/men/34.jpg" },
        { name: "Emma Watson", role: "Frontend Engineer", avatar: "https://randomuser.me/api/portraits/women/41.jpg" },
        { name: "Lucas Miller", role: "Backend Engineer", avatar: "https://randomuser.me/api/portraits/men/46.jpg" },
        { name: "Aria Johnson", role: "DevOps Specialist", avatar: "https://randomuser.me/api/portraits/women/33.jpg" },
        { name: "Chris Taylor", role: "Product Designer", avatar: "https://randomuser.me/api/portraits/men/27.jpg" }
      ],
      timeline: "4.5 months",
      challenges: `Building a real-time collaborative code editor with syntax highlighting and multi-user support required extensive optimization and careful handling of concurrent edits.

Implementing intelligent code analysis and suggestion features while maintaining performance was technically demanding.`,
      userFeedback: [
        { user: "Senior Developer", rating: 5, comment: "Best code review tool I\'ve used. The collaboration features are outstanding." },
        { user: "Tech Lead", rating: 4, comment: "Great for team knowledge sharing. Could use more integration options." }
      ],
      metrics: {
        codeReviews: "8.5K",
        linesReviewed: "2.3M",
        avgReviewTime: "2.1 hours"
      }
    }
  ];

  // Filter and search logic
  const filteredProjects = useMemo(() => {
    return projects.filter(project => {
      const matchesSearch = searchQuery === '' || 
        project.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        project.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        project.technologies.some(tech => tech.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchesCategory = selectedFilters.category === '' || project.category === selectedFilters.category;
      const matchesTechnology = selectedFilters.technology === '' || 
        project.technologies.includes(selectedFilters.technology);
      const matchesTeamSize = selectedFilters.teamSize === '' || 
        project.teamSize.toString() === selectedFilters.teamSize;
      const matchesDate = selectedFilters.completionDate === '' || 
        project.completionDate.includes(selectedFilters.completionDate);

      return matchesSearch && matchesCategory && matchesTechnology && matchesTeamSize && matchesDate;
    });
  }, [projects, searchQuery, selectedFilters]);

  const featuredProjects = projects.filter(project => project.featured);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
  };

  const handleFilterChange = (filters) => {
    setSelectedFilters(filters);
  };

  const handleProjectClick = (project) => {
    setSelectedProject(project);
  };

  const handleCloseModal = () => {
    setSelectedProject(null);
  };

  const handleViewDemo = (demoUrl) => {
    window.open(demoUrl, '_blank', 'noopener,noreferrer');
  };

  const getActiveFilterCount = () => {
    return Object.values(selectedFilters).filter(value => value !== '').length;
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary-50 to-accent-50 py-12 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-heading font-bold text-text-primary mb-4">
            Project Portfolio Gallery
          </h1>
          <p className="text-lg text-text-secondary max-w-3xl mx-auto mb-8">
            Discover exceptional projects built by collaborative teams. Explore real-world applications, 
            interact with live demos, and get inspired by innovative solutions.
          </p>
          
          {/* Search Bar */}
          <form onSubmit={handleSearchSubmit} className="max-w-2xl mx-auto mb-6">
            <div className="relative">
              <Icon 
                name="Search" 
                size={20} 
                className="absolute left-4 top-1/2 transform -translate-y-1/2 text-secondary"
              />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search projects, technologies, or team names..."
                className="w-full pl-12 pr-4 py-4 bg-surface border border-border rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-all duration-200 text-lg"
              />
            </div>
          </form>

          {/* Quick Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-2xl mx-auto">
            <div className="bg-surface rounded-lg p-4 border border-border">
              <div className="text-2xl font-bold text-primary">{projects.length}</div>
              <div className="text-sm text-text-secondary">Total Projects</div>
            </div>
            <div className="bg-surface rounded-lg p-4 border border-border">
              <div className="text-2xl font-bold text-accent">{featuredProjects.length}</div>
              <div className="text-sm text-text-secondary">Featured</div>
            </div>
            <div className="bg-surface rounded-lg p-4 border border-border">
              <div className="text-2xl font-bold text-secondary-600">
                {projects.reduce((sum, p) => sum + p.teamSize, 0)}
              </div>
              <div className="text-sm text-text-secondary">Team Members</div>
            </div>
            <div className="bg-surface rounded-lg p-4 border border-border">
              <div className="text-2xl font-bold text-warning">
                {projects.reduce((sum, p) => sum + p.viewCount, 0).toLocaleString()}
              </div>
              <div className="text-sm text-text-secondary">Total Views</div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Projects Section */}
      {featuredProjects.length > 0 && (
        <FeaturedProjectsSection 
          projects={featuredProjects}
          onProjectClick={handleProjectClick}
          onViewDemo={handleViewDemo}
        />
      )}

      {/* Main Content */}
      <section className="py-8 px-4">
        <div className="max-w-7xl mx-auto">
          {/* Controls Bar */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
            <div className="flex items-center space-x-4">
              <h2 className="text-2xl font-heading font-semibold text-text-primary">
                All Projects ({filteredProjects.length})
              </h2>
              {getActiveFilterCount() > 0 && (
                <span className="bg-primary text-white text-sm px-3 py-1 rounded-full">
                  {getActiveFilterCount()} filter{getActiveFilterCount() > 1 ? 's' : ''} active
                </span>
              )}
            </div>
            
            <div className="flex items-center space-x-3">
              {/* Filter Toggle */}
              <button
                onClick={() => setShowFilters(!showFilters)}
                className="flex items-center space-x-2 px-4 py-2 bg-surface border border-border rounded-lg hover:bg-secondary-50 transition-colors duration-150"
              >
                <Icon name="Filter" size={18} />
                <span className="hidden sm:inline">Filters</span>
                {getActiveFilterCount() > 0 && (
                  <span className="bg-primary text-white text-xs px-2 py-1 rounded-full">
                    {getActiveFilterCount()}
                  </span>
                )}
              </button>

              {/* View Mode Toggle */}
              <div className="flex bg-secondary-100 rounded-lg p-1">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-2 rounded-md transition-colors duration-150 ${
                    viewMode === 'grid' ?'bg-surface text-primary shadow-sm' :'text-secondary-600 hover:text-text-primary'
                  }`}
                  aria-label="Grid view"
                >
                  <Icon name="Grid3X3" size={18} />
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-2 rounded-md transition-colors duration-150 ${
                    viewMode === 'list' ?'bg-surface text-primary shadow-sm' :'text-secondary-600 hover:text-text-primary'
                  }`}
                  aria-label="List view"
                >
                  <Icon name="List" size={18} />
                </button>
              </div>
            </div>
          </div>

          {/* Filter Panel */}
          {showFilters && (
            <FilterPanel
              projects={projects}
              selectedFilters={selectedFilters}
              onFilterChange={handleFilterChange}
              onClose={() => setShowFilters(false)}
            />
          )}

          {/* Projects Grid/List */}
          {filteredProjects.length === 0 ? (
            <div className="text-center py-16">
              <div className="w-24 h-24 bg-secondary-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Icon name="Search" size={48} className="text-secondary" />
              </div>
              <h3 className="text-xl font-semibold text-text-primary mb-2">No projects found</h3>
              <p className="text-text-secondary mb-6">
                Try adjusting your search terms or filters to find more projects.
              </p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedFilters({
                    category: '',
                    technology: '',
                    teamSize: '',
                    completionDate: ''
                  });
                }}
                className="btn-primary"
              >
                Clear all filters
              </button>
            </div>
          ) : (
            <div className={`
              ${viewMode === 'grid' ?'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6' :'space-y-4'
              }
            `}>
              {filteredProjects.map(project => (
                <ProjectCard
                  key={project.id}
                  project={project}
                  viewMode={viewMode}
                  onProjectClick={handleProjectClick}
                  onViewDemo={handleViewDemo}
                />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Project Detail Modal */}
      {selectedProject && (
        <ProjectDetailModal
          project={selectedProject}
          onClose={handleCloseModal}
          onViewDemo={handleViewDemo}
        />
      )}
    </div>
  );
};

export default ProjectPortfolioGallery;