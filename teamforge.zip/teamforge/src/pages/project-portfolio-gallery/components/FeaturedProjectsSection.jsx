import React from 'react';
import Icon from 'components/AppIcon';
import Image from 'components/AppImage';

const FeaturedProjectsSection = ({ projects, onProjectClick, onViewDemo }) => {
  const handleProjectClick = (project) => {
    onProjectClick(project);
  };

  const handleDemoClick = (e, demoUrl) => {
    e.stopPropagation();
    onViewDemo(demoUrl);
  };

  const getComplexityColor = (complexity) => {
    switch (complexity) {
      case 'beginner': return 'text-accent bg-accent-50';
      case 'intermediate': return 'text-warning bg-warning-50';
      case 'advanced': return 'text-error bg-error-50';
      case 'expert': return 'text-primary bg-primary-50';
      default: return 'text-secondary bg-secondary-100';
    }
  };

  const getCategoryIcon = (category) => {
    switch (category) {
      case 'web-app': return 'Globe';
      case 'mobile-app': return 'Smartphone';
      case 'data-project': return 'BarChart3';
      default: return 'Code';
    }
  };

  return (
    <section className="py-12 px-4 bg-gradient-to-br from-surface to-secondary-50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-heading font-bold text-text-primary mb-4">
            Featured Projects
          </h2>
          <p className="text-lg text-text-secondary max-w-2xl mx-auto">
            Exceptional projects that showcase innovation, technical excellence, and real-world impact.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <div
              key={project.id}
              className={`
                card-prominent overflow-hidden cursor-pointer group transition-all duration-300 hover:scale-[1.02]
                ${index === 0 ? 'lg:col-span-2' : ''}
              `}
              onClick={() => handleProjectClick(project)}
            >
              <div className={`
                ${index === 0 ? 'lg:flex lg:items-center' : ''}
              `}>
                {/* Project Image */}
                <div className={`
                  ${index === 0 ? 'lg:w-1/2' : ''} 
                  aspect-video bg-secondary-100 overflow-hidden relative
                `}>
                  <Image
                    src={project.thumbnail}
                    alt={project.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  
                  {/* Overlay with metrics */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                  <div className="absolute bottom-4 left-4 right-4">
                    <div className="flex items-center justify-between text-white">
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center space-x-1">
                          <Icon name="Eye" size={16} />
                          <span className="text-sm">{project.viewCount.toLocaleString()}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Icon name="Star" size={16} />
                          <span className="text-sm">{project.rating}</span>
                        </div>
                      </div>
                      <span className="bg-accent text-white text-xs px-2 py-1 rounded-full font-medium">
                        Featured
                      </span>
                    </div>
                  </div>
                </div>

                {/* Project Content */}
                <div className={`
                  p-6 ${index === 0 ? 'lg:w-1/2' : ''}
                `}>
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <Icon name={getCategoryIcon(project.category)} size={24} className="text-primary" />
                      <div>
                        <h3 className={`
                          font-heading font-bold text-text-primary group-hover:text-primary transition-colors duration-200
                          ${index === 0 ? 'text-2xl' : 'text-xl'}
                        `}>
                          {project.title}
                        </h3>
                        <div className="flex items-center space-x-2 mt-1">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getComplexityColor(project.complexity)}`}>
                            {project.complexity}
                          </span>
                          <span className="text-sm text-text-secondary">
                            {project.teamSize} members
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <p className={`
                    text-text-secondary mb-6 leading-relaxed
                    ${index === 0 ? 'text-base' : 'text-sm'}
                  `}>
                    {project.description}
                  </p>

                  {/* Technologies */}
                  <div className="mb-6">
                    <div className="flex flex-wrap gap-2">
                      {project.technologies.slice(0, index === 0 ? 6 : 4).map(tech => (
                        <span
                          key={tech}
                          className="bg-secondary-100 text-secondary-700 text-sm px-3 py-1 rounded-full font-medium"
                        >
                          {tech}
                        </span>
                      ))}
                      {project.technologies.length > (index === 0 ? 6 : 4) && (
                        <span className="text-sm text-text-secondary">
                          +{project.technologies.length - (index === 0 ? 6 : 4)} more
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Team Members */}
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center space-x-3">
                      <span className="text-sm font-medium text-text-primary">Team:</span>
                      <div className="flex -space-x-2">
                        {project.team.slice(0, 4).map((member, memberIndex) => (
                          <div 
                            key={memberIndex} 
                            className="w-8 h-8 rounded-full border-2 border-surface overflow-hidden"
                            title={member.name}
                          >
                            <Image
                              src={member.avatar}
                              alt={member.name}
                              className="w-full h-full object-cover"
                            />
                          </div>
                        ))}
                        {project.team.length > 4 && (
                          <div className="w-8 h-8 rounded-full bg-secondary-200 border-2 border-surface flex items-center justify-center">
                            <span className="text-xs text-secondary-600">+{project.team.length - 4}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Project Metrics */}
                  {project.metrics && (
                    <div className="grid grid-cols-3 gap-4 mb-6">
                      {Object.entries(project.metrics).map(([key, value]) => (
                        <div key={key} className="text-center">
                          <div className="text-lg font-bold text-primary">{value}</div>
                          <div className="text-xs text-text-secondary capitalize">
                            {key.replace(/([A-Z])/g, ' $1').trim()}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Actions */}
                  <div className="flex space-x-3">
                    <button
                      onClick={(e) => handleDemoClick(e, project.liveDemo)}
                      className="flex-1 btn-primary flex items-center justify-center space-x-2"
                    >
                      <Icon name="ExternalLink" size={18} />
                      <span>Live Demo</span>
                    </button>
                    <button
                      onClick={() => handleProjectClick(project)}
                      className="px-4 py-2 border border-border rounded-lg hover:bg-secondary-50 transition-colors duration-150 flex items-center space-x-2"
                    >
                      <Icon name="Info" size={18} className="text-secondary-600" />
                      <span className="hidden sm:inline">Details</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedProjectsSection;