import React from 'react';
import Icon from 'components/AppIcon';
import Image from 'components/AppImage';

const ProjectCard = ({ project, viewMode, onProjectClick, onViewDemo }) => {
  const handleCardClick = (e) => {
    e.preventDefault();
    onProjectClick(project);
  };

  const handleDemoClick = (e) => {
    e.stopPropagation();
    onViewDemo(project.liveDemo);
  };

  const getComplexityColor = (complexity) => {
    switch (complexity) {
      case 'beginner': return 'text-accent bg-accent-50';
      case 'intermediate': return 'text-warning bg-warning-50';
      case 'advanced': return 'text-error bg-error-50';
      case 'expert': return 'text-primary bg-primary-50';
      default: return 'text-secondary bg-secondary-100';
    }
  };

  const getCategoryIcon = (category) => {
    switch (category) {
      case 'web-app': return 'Globe';
      case 'mobile-app': return 'Smartphone';
      case 'data-project': return 'BarChart3';
      default: return 'Code';
    }
  };

  if (viewMode === 'list') {
    return (
      <div 
        className="card p-6 hover:shadow-prominent transition-all duration-200 cursor-pointer group"
        onClick={handleCardClick}
      >
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Thumbnail */}
          <div className="lg:w-48 lg:flex-shrink-0">
            <div className="aspect-video rounded-lg overflow-hidden bg-secondary-100">
              <Image
                src={project.thumbnail}
                alt={project.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
            </div>
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center space-x-3">
                <Icon name={getCategoryIcon(project.category)} size={20} className="text-primary" />
                <h3 className="text-xl font-heading font-semibold text-text-primary group-hover:text-primary transition-colors duration-150">
                  {project.title}
                </h3>
                {project.featured && (
                  <span className="bg-accent text-white text-xs px-2 py-1 rounded-full font-medium">
                    Featured
                  </span>
                )}
              </div>
              <div className="flex items-center space-x-2 text-sm text-text-secondary">
                <Icon name="Eye" size={16} />
                <span>{project.viewCount.toLocaleString()}</span>
              </div>
            </div>

            <p className="text-text-secondary mb-4 line-clamp-2">
              {project.description}
            </p>

            {/* Technologies */}
            <div className="flex flex-wrap gap-2 mb-4">
              {project.technologies.slice(0, 4).map(tech => (
                <span
                  key={tech}
                  className="bg-secondary-100 text-secondary-700 text-sm px-3 py-1 rounded-full"
                >
                  {tech}
                </span>
              ))}
              {project.technologies.length > 4 && (
                <span className="text-sm text-text-secondary">
                  +{project.technologies.length - 4} more
                </span>
              )}
            </div>

            {/* Metadata */}
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4 text-sm text-text-secondary">
                <div className="flex items-center space-x-1">
                  <Icon name="Users" size={16} />
                  <span>{project.teamSize} members</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Icon name="Star" size={16} />
                  <span>{project.rating}</span>
                </div>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getComplexityColor(project.complexity)}`}>
                  {project.complexity}
                </span>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={handleDemoClick}
                  className="flex items-center space-x-2 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-700 transition-colors duration-150"
                >
                  <Icon name="ExternalLink" size={16} />
                  <span>Live Demo</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div 
      className="card overflow-hidden hover:shadow-prominent transition-all duration-200 cursor-pointer group"
      onClick={handleCardClick}
    >
      {/* Thumbnail */}
      <div className="aspect-video bg-secondary-100 overflow-hidden relative">
        <Image
          src={project.thumbnail}
          alt={project.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        {project.featured && (
          <div className="absolute top-3 left-3">
            <span className="bg-accent text-white text-xs px-2 py-1 rounded-full font-medium">
              Featured
            </span>
          </div>
        )}
        <div className="absolute top-3 right-3 flex items-center space-x-1 bg-black bg-opacity-50 text-white text-xs px-2 py-1 rounded-full">
          <Icon name="Eye" size={12} />
          <span>{project.viewCount.toLocaleString()}</span>
        </div>
      </div>

      {/* Content */}
      <div className="p-6">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center space-x-2">
            <Icon name={getCategoryIcon(project.category)} size={18} className="text-primary" />
            <h3 className="text-lg font-heading font-semibold text-text-primary group-hover:text-primary transition-colors duration-150 line-clamp-1">
              {project.title}
            </h3>
          </div>
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getComplexityColor(project.complexity)}`}>
            {project.complexity}
          </span>
        </div>

        <p className="text-text-secondary text-sm mb-4 line-clamp-2">
          {project.description}
        </p>

        {/* Technologies */}
        <div className="flex flex-wrap gap-1 mb-4">
          {project.technologies.slice(0, 3).map(tech => (
            <span
              key={tech}
              className="bg-secondary-100 text-secondary-700 text-xs px-2 py-1 rounded-full"
            >
              {tech}
            </span>
          ))}
          {project.technologies.length > 3 && (
            <span className="text-xs text-text-secondary">
              +{project.technologies.length - 3}
            </span>
          )}
        </div>

        {/* Team Avatars */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <div className="flex -space-x-2">
              {project.team.slice(0, 3).map((member, index) => (
                <div key={index} className="w-6 h-6 rounded-full border-2 border-surface overflow-hidden">
                  <Image
                    src={member.avatar}
                    alt={member.name}
                    className="w-full h-full object-cover"
                  />
                </div>
              ))}
              {project.team.length > 3 && (
                <div className="w-6 h-6 rounded-full bg-secondary-200 border-2 border-surface flex items-center justify-center">
                  <span className="text-xs text-secondary-600">+{project.team.length - 3}</span>
                </div>
              )}
            </div>
            <span className="text-sm text-text-secondary">{project.teamSize} members</span>
          </div>
          <div className="flex items-center space-x-1 text-sm text-text-secondary">
            <Icon name="Star" size={14} />
            <span>{project.rating}</span>
          </div>
        </div>

        {/* Actions */}
        <div className="flex space-x-2">
          <button
            onClick={handleDemoClick}
            className="flex-1 flex items-center justify-center space-x-2 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-700 transition-colors duration-150"
          >
            <Icon name="ExternalLink" size={16} />
            <span>Live Demo</span>
          </button>
          <button
            onClick={handleCardClick}
            className="px-4 py-2 border border-border rounded-lg hover:bg-secondary-50 transition-colors duration-150"
          >
            <Icon name="Info" size={16} className="text-secondary-600" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProjectCard;