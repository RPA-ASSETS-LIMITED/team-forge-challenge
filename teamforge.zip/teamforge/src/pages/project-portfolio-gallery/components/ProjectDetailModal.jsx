import React, { useState } from 'react';
import Icon from 'components/AppIcon';
import Image from 'components/AppImage';

const ProjectDetailModal = ({ project, onClose, onViewDemo }) => {
  const [activeTab, setActiveTab] = useState('overview');

  const handleBackdropClick = (e) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  const handleDemoClick = () => {
    onViewDemo(project.liveDemo);
  };

  const handleShareProject = () => {
    if (navigator.share) {
      navigator.share({
        title: project.title,
        text: project.description,
        url: window.location.href
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      // You could add a toast notification here
    }
  };

  const getComplexityColor = (complexity) => {
    switch (complexity) {
      case 'beginner': return 'text-accent bg-accent-50';
      case 'intermediate': return 'text-warning bg-warning-50';
      case 'advanced': return 'text-error bg-error-50';
      case 'expert': return 'text-primary bg-primary-50';
      default: return 'text-secondary bg-secondary-100';
    }
  };

  const getCategoryIcon = (category) => {
    switch (category) {
      case 'web-app': return 'Globe';
      case 'mobile-app': return 'Smartphone';
      case 'data-project': return 'BarChart3';
      default: return 'Code';
    }
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: 'Info' },
    { id: 'team', label: 'Team', icon: 'Users' },
    { id: 'timeline', label: 'Development', icon: 'GitBranch' },
    { id: 'feedback', label: 'Feedback', icon: 'MessageSquare' }
  ];

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4"
      onClick={handleBackdropClick}
    >
      <div className="bg-surface rounded-xl max-w-4xl w-full max-h-[90vh] overflow-hidden shadow-prominent">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <div className="flex items-center space-x-3">
            <Icon name={getCategoryIcon(project.category)} size={24} className="text-primary" />
            <div>
              <h2 className="text-2xl font-heading font-bold text-text-primary">
                {project.title}
              </h2>
              <div className="flex items-center space-x-3 mt-1">
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getComplexityColor(project.complexity)}`}>
                  {project.complexity}
                </span>
                {project.featured && (
                  <span className="bg-accent text-white text-xs px-2 py-1 rounded-full font-medium">
                    Featured
                  </span>
                )}
                <div className="flex items-center space-x-1 text-sm text-text-secondary">
                  <Icon name="Eye" size={14} />
                  <span>{project.viewCount.toLocaleString()} views</span>
                </div>
                <div className="flex items-center space-x-1 text-sm text-text-secondary">
                  <Icon name="Star" size={14} />
                  <span>{project.rating}</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <button
              onClick={handleShareProject}
              className="p-2 rounded-lg hover:bg-secondary-100 transition-colors duration-150"
              title="Share project"
            >
              <Icon name="Share2" size={20} className="text-secondary-600" />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-secondary-100 transition-colors duration-150"
              title="Close"
            >
              <Icon name="X" size={20} className="text-secondary-600" />
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="border-b border-border">
          <div className="flex space-x-0 px-6">
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`
                  flex items-center space-x-2 px-4 py-3 border-b-2 transition-colors duration-150
                  ${activeTab === tab.id 
                    ? 'border-primary text-primary' :'border-transparent text-text-secondary hover:text-text-primary'
                  }
                `}
              >
                <Icon name={tab.icon} size={16} />
                <span className="font-medium">{tab.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[60vh]">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Project Image */}
              <div className="aspect-video rounded-lg overflow-hidden bg-secondary-100">
                <Image
                  src={project.thumbnail}
                  alt={project.title}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Description */}
              <div>
                <h3 className="text-lg font-heading font-semibold text-text-primary mb-3">
                  About This Project
                </h3>
                <p className="text-text-secondary leading-relaxed">
                  {project.description}
                </p>
              </div>

              {/* Technologies */}
              <div>
                <h3 className="text-lg font-heading font-semibold text-text-primary mb-3">
                  Technologies Used
                </h3>
                <div className="flex flex-wrap gap-2">
                  {project.technologies.map(tech => (
                    <span
                      key={tech}
                      className="bg-secondary-100 text-secondary-700 px-3 py-2 rounded-lg font-medium"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>

              {/* Metrics */}
              {project.metrics && (
                <div>
                  <h3 className="text-lg font-heading font-semibold text-text-primary mb-3">
                    Project Impact
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    {Object.entries(project.metrics).map(([key, value]) => (
                      <div key={key} className="bg-secondary-50 rounded-lg p-4 text-center">
                        <div className="text-2xl font-bold text-primary mb-1">{value}</div>
                        <div className="text-sm text-text-secondary capitalize">
                          {key.replace(/([A-Z])/g, ' $1').trim()}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Actions */}
              <div className="flex space-x-3 pt-4">
                <button
                  onClick={handleDemoClick}
                  className="btn-primary flex items-center space-x-2"
                >
                  <Icon name="ExternalLink" size={18} />
                  <span>View Live Demo</span>
                </button>
                <button className="btn-secondary flex items-center space-x-2">
                  <Icon name="Github" size={18} />
                  <span>View Code</span>
                </button>
              </div>
            </div>
          )}

          {activeTab === 'team' && (
            <div className="space-y-6">
              <h3 className="text-lg font-heading font-semibold text-text-primary">
                Team Members ({project.team.length})
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {project.team.map((member, index) => (
                  <div key={index} className="flex items-center space-x-4 p-4 bg-secondary-50 rounded-lg">
                    <div className="w-12 h-12 rounded-full overflow-hidden">
                      <Image
                        src={member.avatar}
                        alt={member.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div>
                      <h4 className="font-medium text-text-primary">{member.name}</h4>
                      <p className="text-sm text-text-secondary">{member.role}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'timeline' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-heading font-semibold text-text-primary mb-3">
                  Development Timeline
                </h3>
                <div className="flex items-center space-x-4 text-text-secondary mb-4">
                  <div className="flex items-center space-x-1">
                    <Icon name="Clock" size={16} />
                    <span>Duration: {project.timeline}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Icon name="Calendar" size={16} />
                    <span>Completed: {new Date(project.completionDate).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-medium text-text-primary mb-3">Challenges & Solutions</h4>
                <div className="bg-secondary-50 rounded-lg p-4">
                  <p className="text-text-secondary leading-relaxed whitespace-pre-line">
                    {project.challenges}
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'feedback' && (
            <div className="space-y-6">
              <h3 className="text-lg font-heading font-semibold text-text-primary">
                User Feedback
              </h3>
              <div className="space-y-4">
                {project.userFeedback.map((feedback, index) => (
                  <div key={index} className="border border-border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-text-primary">{feedback.user}</span>
                      <div className="flex items-center space-x-1">
                        {[...Array(5)].map((_, i) => (
                          <Icon
                            key={i}
                            name="Star"
                            size={14}
                            className={i < feedback.rating ? 'text-warning fill-current' : 'text-secondary-300'}
                          />
                        ))}
                      </div>
                    </div>
                    <p className="text-text-secondary">{feedback.comment}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProjectDetailModal;