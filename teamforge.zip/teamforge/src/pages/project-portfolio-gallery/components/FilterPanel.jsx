import React from 'react';
import Icon from 'components/AppIcon';

const FilterPanel = ({ projects, selectedFilters, onFilterChange, onClose }) => {
  // Extract unique values from projects for filter options
  const categories = [...new Set(projects.map(p => p.category))];
  const technologies = [...new Set(projects.flatMap(p => p.technologies))].sort();
  const teamSizes = [...new Set(projects.map(p => p.teamSize.toString()))].sort();
  const years = [...new Set(projects.map(p => new Date(p.completionDate).getFullYear().toString()))].sort().reverse();

  const categoryLabels = {
    'web-app': 'Web Applications',
    'mobile-app': 'Mobile Apps',
    'data-project': 'Data Projects'
  };

  const handleFilterChange = (filterType, value) => {
    const newFilters = {
      ...selectedFilters,
      [filterType]: selectedFilters[filterType] === value ? '' : value
    };
    onFilterChange(newFilters);
  };

  const clearAllFilters = () => {
    onFilterChange({
      category: '',
      technology: '',
      teamSize: '',
      completionDate: ''
    });
  };

  const getActiveFilterCount = () => {
    return Object.values(selectedFilters).filter(value => value !== '').length;
  };

  const FilterSection = ({ title, children }) => (
    <div className="space-y-3">
      <h4 className="font-medium text-text-primary">{title}</h4>
      {children}
    </div>
  );

  const FilterButton = ({ active, onClick, children }) => (
    <button
      onClick={onClick}
      className={`
        px-3 py-2 rounded-lg text-sm font-medium transition-all duration-150 ease-in-out
        ${active 
          ? 'bg-primary text-white' :'bg-secondary-100 text-secondary-700 hover:bg-secondary-200'
        }
      `}
    >
      {children}
    </button>
  );

  return (
    <div className="bg-surface border border-border rounded-lg p-6 mb-8 animation-slide-up">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-2">
          <h3 className="text-lg font-heading font-semibold text-text-primary">
            Filter Projects
          </h3>
          {getActiveFilterCount() > 0 && (
            <span className="bg-primary text-white text-xs px-2 py-1 rounded-full">
              {getActiveFilterCount()}
            </span>
          )}
        </div>
        <div className="flex items-center space-x-2">
          {getActiveFilterCount() > 0 && (
            <button
              onClick={clearAllFilters}
              className="text-sm text-secondary-600 hover:text-text-primary transition-colors duration-150"
            >
              Clear all
            </button>
          )}
          <button
            onClick={onClose}
            className="p-1 rounded-md hover:bg-secondary-100 transition-colors duration-150"
          >
            <Icon name="X" size={18} className="text-secondary-600" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Category Filter */}
        <FilterSection title="Category">
          <div className="flex flex-wrap gap-2">
            {categories.map(category => (
              <FilterButton
                key={category}
                active={selectedFilters.category === category}
                onClick={() => handleFilterChange('category', category)}
              >
                {categoryLabels[category] || category}
              </FilterButton>
            ))}
          </div>
        </FilterSection>

        {/* Technology Filter */}
        <FilterSection title="Technology">
          <div className="flex flex-wrap gap-2 max-h-32 overflow-y-auto">
            {technologies.slice(0, 8).map(tech => (
              <FilterButton
                key={tech}
                active={selectedFilters.technology === tech}
                onClick={() => handleFilterChange('technology', tech)}
              >
                {tech}
              </FilterButton>
            ))}
          </div>
          {technologies.length > 8 && (
            <p className="text-xs text-text-secondary mt-2">
              +{technologies.length - 8} more technologies available
            </p>
          )}
        </FilterSection>

        {/* Team Size Filter */}
        <FilterSection title="Team Size">
          <div className="flex flex-wrap gap-2">
            {teamSizes.map(size => (
              <FilterButton
                key={size}
                active={selectedFilters.teamSize === size}
                onClick={() => handleFilterChange('teamSize', size)}
              >
                {size} member{size !== '1' ? 's' : ''}
              </FilterButton>
            ))}
          </div>
        </FilterSection>

        {/* Completion Year Filter */}
        <FilterSection title="Completion Year">
          <div className="flex flex-wrap gap-2">
            {years.map(year => (
              <FilterButton
                key={year}
                active={selectedFilters.completionDate === year}
                onClick={() => handleFilterChange('completionDate', year)}
              >
                {year}
              </FilterButton>
            ))}
          </div>
        </FilterSection>
      </div>
    </div>
  );
};

export default FilterPanel;