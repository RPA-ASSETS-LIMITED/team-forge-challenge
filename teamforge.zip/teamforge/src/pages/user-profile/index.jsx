import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from 'components/AppIcon';

import ProfileHeader from './components/ProfileHeader';
import PortfolioSection from './components/PortfolioSection';
import SkillsSection from './components/SkillsSection';
import ExperienceTimeline from './components/ExperienceTimeline';
import EditProfileModal from './components/EditProfileModal';
import PrivacySettings from './components/PrivacySettings';

const UserProfile = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('portfolio');
  const [showEditModal, setShowEditModal] = useState(false);
  const [showPrivacySettings, setShowPrivacySettings] = useState(false);

  // Mock user data
  const userData = {
    id: 1,
    name: "Sarah Chen",
    role: "Full Stack Developer",
    avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=400&h=400&fit=crop&crop=face",
    location: "San Francisco, CA",
    joinDate: "March 2023",
    bio: `Passionate full-stack developer with a love for creating intuitive user experiences and robust backend systems. I thrive in collaborative environments and enjoy mentoring junior developers.

Currently focused on React, Node.js, and cloud technologies. Always eager to learn new technologies and tackle challenging problems.`,
    email: "sarah.chen@email.com",
    github: "https://github.com/sarahchen",
    linkedin: "https://linkedin.com/in/sarahchen",
    website: "https://sarahchen.dev",
    metrics: {
      projectsCompleted: 12,
      teamRating: 4.8,
      skillsMastered: 15,
      totalContributions: 847
    },
    privacy: {
      profileVisibility: 'public',
      contactInfo: 'team-members',
      projectHistory: 'public',
      skillEndorsements: 'public'
    }
  };

  const tabItems = [
    { id: 'portfolio', label: 'Portfolio', icon: 'Briefcase' },
    { id: 'skills', label: 'Skills', icon: 'Award' },
    { id: 'experience', label: 'Experience', icon: 'Clock' }
  ];

  const handleTabChange = (tabId) => {
    setActiveTab(tabId);
  };

  const handleEditProfile = () => {
    setShowEditModal(true);
  };

  const handlePrivacySettings = () => {
    setShowPrivacySettings(true);
  };

  const handleShareProfile = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${userData.name} - ${userData.role}`,
          text: userData.bio.split('\n')[0],
          url: window.location.href
        });
      } catch (error) {
        console.log('Error sharing:', error);
      }
    } else {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(window.location.href);
      // You could show a toast notification here
    }
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'portfolio':
        return <PortfolioSection userData={userData} />;
      case 'skills':
        return <SkillsSection userData={userData} />;
      case 'experience':
        return <ExperienceTimeline userData={userData} />;
      default:
        return <PortfolioSection userData={userData} />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Profile Header */}
        <ProfileHeader 
          userData={userData}
          onEdit={handleEditProfile}
          onPrivacySettings={handlePrivacySettings}
          onShare={handleShareProfile}
        />

        {/* Navigation Tabs */}
        <div className="mt-8 border-b border-border">
          <nav className="flex space-x-8 overflow-x-auto">
            {tabItems.map((tab) => (
              <button
                key={tab.id}
                onClick={() => handleTabChange(tab.id)}
                className={`
                  flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm whitespace-nowrap
                  transition-all duration-200 ease-out
                  ${activeTab === tab.id
                    ? 'border-primary text-primary' :'border-transparent text-secondary hover:text-text-primary hover:border-secondary-300'
                  }
                `}
              >
                <Icon name={tab.icon} size={20} />
                <span>{tab.label}</span>
              </button>
            ))}
          </nav>
        </div>

        {/* Tab Content */}
        <div className="mt-8">
          {renderTabContent()}
        </div>

        {/* Quick Actions - Mobile FAB */}
        <div className="fixed bottom-24 right-4 lg:hidden">
          <div className="flex flex-col space-y-3">
            <button
              onClick={handleEditProfile}
              className="w-12 h-12 bg-primary text-white rounded-full shadow-prominent flex items-center justify-center hover:bg-primary-700 transition-all duration-200 ease-out"
              aria-label="Edit profile"
            >
              <Icon name="Edit" size={20} />
            </button>
            <button
              onClick={handleShareProfile}
              className="w-12 h-12 bg-surface text-secondary-600 rounded-full shadow-prominent border border-border flex items-center justify-center hover:bg-secondary-100 transition-all duration-200 ease-out"
              aria-label="Share profile"
            >
              <Icon name="Share" size={20} />
            </button>
          </div>
        </div>
      </div>

      {/* Modals */}
      {showEditModal && (
        <EditProfileModal
          userData={userData}
          onClose={() => setShowEditModal(false)}
          onSave={(updatedData) => {
            // Handle profile update
            console.log('Profile updated:', updatedData);
            setShowEditModal(false);
          }}
        />
      )}

      {showPrivacySettings && (
        <PrivacySettings
          userData={userData}
          onClose={() => setShowPrivacySettings(false)}
          onSave={(privacySettings) => {
            // Handle privacy settings update
            console.log('Privacy settings updated:', privacySettings);
            setShowPrivacySettings(false);
          }}
        />
      )}
    </div>
  );
};

export default UserProfile;