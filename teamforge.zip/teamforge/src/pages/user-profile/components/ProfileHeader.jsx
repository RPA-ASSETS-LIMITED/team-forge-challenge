import React from 'react';
import Icon from 'components/AppIcon';
import Image from 'components/AppImage';

const ProfileHeader = ({ userData, onEdit, onPrivacySettings, onShare }) => {
  const MetricCard = ({ label, value, icon }) => (
    <div className="bg-surface rounded-lg p-4 border border-border">
      <div className="flex items-center space-x-3">
        <div className="w-10 h-10 bg-primary-50 rounded-lg flex items-center justify-center">
          <Icon name={icon} size={20} className="text-primary" />
        </div>
        <div>
          <p className="text-2xl font-bold text-text-primary">{value}</p>
          <p className="text-sm text-secondary">{label}</p>
        </div>
      </div>
    </div>
  );

  const SocialLink = ({ url, icon, platform }) => (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className="flex items-center space-x-2 text-secondary hover:text-primary transition-colors duration-200"
      aria-label={`Visit ${platform} profile`}
    >
      <Icon name={icon} size={18} />
      <span className="text-sm">{platform}</span>
    </a>
  );

  return (
    <div className="bg-surface rounded-xl border border-border shadow-subtle overflow-hidden">
      {/* Cover Image */}
      <div className="h-32 sm:h-48 bg-gradient-to-r from-primary-500 to-primary-700 relative">
        <div className="absolute inset-0 bg-black bg-opacity-20"></div>
      </div>

      <div className="relative px-6 pb-6">
        {/* Avatar */}
        <div className="flex flex-col sm:flex-row sm:items-end sm:space-x-6 -mt-16 sm:-mt-20">
          <div className="relative">
            <div className="w-24 h-24 sm:w-32 sm:h-32 rounded-full border-4 border-surface overflow-hidden bg-surface">
              <Image
                src={userData.avatar}
                alt={userData.name}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute bottom-0 right-0 w-6 h-6 sm:w-8 sm:h-8 bg-accent rounded-full border-2 border-surface flex items-center justify-center">
              <Icon name="Check" size={16} className="text-white" />
            </div>
          </div>

          {/* Desktop Actions */}
          <div className="hidden lg:flex items-center space-x-3 ml-auto mb-4">
            <button
              onClick={onShare}
              className="btn-secondary flex items-center space-x-2"
            >
              <Icon name="Share" size={18} />
              <span>Share</span>
            </button>
            <button
              onClick={onPrivacySettings}
              className="btn-secondary flex items-center space-x-2"
            >
              <Icon name="Shield" size={18} />
              <span>Privacy</span>
            </button>
            <button
              onClick={onEdit}
              className="btn-primary flex items-center space-x-2"
            >
              <Icon name="Edit" size={18} />
              <span>Edit Profile</span>
            </button>
          </div>
        </div>

        {/* Profile Info */}
        <div className="mt-4 lg:mt-0">
          <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between">
            <div className="flex-1">
              <h1 className="text-2xl sm:text-3xl font-bold text-text-primary">
                {userData.name}
              </h1>
              <p className="text-lg text-secondary mt-1">{userData.role}</p>
              
              <div className="flex items-center space-x-4 mt-2 text-sm text-secondary">
                <div className="flex items-center space-x-1">
                  <Icon name="MapPin" size={16} />
                  <span>{userData.location}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Icon name="Calendar" size={16} />
                  <span>Joined {userData.joinDate}</span>
                </div>
              </div>

              {/* Bio */}
              <div className="mt-4">
                <p className="text-text-secondary leading-relaxed">
                  {userData.bio}
                </p>
              </div>

              {/* Social Links */}
              <div className="flex flex-wrap items-center gap-4 mt-4">
                <SocialLink url={userData.github} icon="Github" platform="GitHub" />
                <SocialLink url={userData.linkedin} icon="Linkedin" platform="LinkedIn" />
                <SocialLink url={userData.website} icon="Globe" platform="Website" />
              </div>
            </div>

            {/* Mobile Actions */}
            <div className="flex lg:hidden items-center space-x-2 mt-4 sm:mt-0 sm:ml-4">
              <button
                onClick={onShare}
                className="p-2 rounded-lg border border-border hover:bg-secondary-100 transition-colors duration-200"
                aria-label="Share profile"
              >
                <Icon name="Share" size={18} className="text-secondary-600" />
              </button>
              <button
                onClick={onPrivacySettings}
                className="p-2 rounded-lg border border-border hover:bg-secondary-100 transition-colors duration-200"
                aria-label="Privacy settings"
              >
                <Icon name="Shield" size={18} className="text-secondary-600" />
              </button>
            </div>
          </div>
        </div>

        {/* Metrics */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
          <MetricCard
            label="Projects Completed"
            value={userData.metrics.projectsCompleted}
            icon="CheckCircle"
          />
          <MetricCard
            label="Team Rating"
            value={userData.metrics.teamRating}
            icon="Star"
          />
          <MetricCard
            label="Skills Mastered"
            value={userData.metrics.skillsMastered}
            icon="Award"
          />
          <MetricCard
            label="Contributions"
            value={userData.metrics.totalContributions}
            icon="GitCommit"
          />
        </div>
      </div>
    </div>
  );
};

export default ProfileHeader;