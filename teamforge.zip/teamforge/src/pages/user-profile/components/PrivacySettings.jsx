import React, { useState } from 'react';
import Icon from 'components/AppIcon';

const PrivacySettings = ({ userData, onClose, onSave }) => {
  const [settings, setSettings] = useState({
    profileVisibility: userData.privacy.profileVisibility,
    contactInfo: userData.privacy.contactInfo,
    projectHistory: userData.privacy.projectHistory,
    skillEndorsements: userData.privacy.skillEndorsements,
    showEmail: false,
    showLocation: true,
    allowTeamInvites: true,
    allowMentorRequests: true,
    emailNotifications: true,
    projectUpdates: true,
    teamMessages: true,
    skillEndorsementNotifications: true
  });

  const [isLoading, setIsLoading] = useState(false);

  const visibilityOptions = [
    { value: 'public', label: 'Public', description: 'Visible to everyone on the platform' },
    { value: 'team-members', label: 'Team Members Only', description: 'Only visible to your current and past team members' },
    { value: 'private', label: 'Private', description: 'Only visible to you' }
  ];

  const handleSettingChange = (setting, value) => {
    setSettings(prev => ({
      ...prev,
      [setting]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      onSave(settings);
    } catch (error) {
      console.error('Error saving privacy settings:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const SettingSection = ({ title, description, children }) => (
    <div className="space-y-4">
      <div>
        <h3 className="text-lg font-semibold text-text-primary">{title}</h3>
        {description && (
          <p className="text-sm text-secondary mt-1">{description}</p>
        )}
      </div>
      {children}
    </div>
  );

  const RadioGroup = ({ name, value, options, onChange }) => (
    <div className="space-y-3">
      {options.map((option) => (
        <label key={option.value} className="flex items-start space-x-3 cursor-pointer group">
          <input
            type="radio"
            name={name}
            value={option.value}
            checked={value === option.value}
            onChange={() => onChange(option.value)}
            className="w-4 h-4 text-primary focus:ring-primary-500 focus:ring-2 mt-1"
          />
          <div className="flex-1">
            <div className="font-medium text-text-primary group-hover:text-primary transition-colors duration-200">
              {option.label}
            </div>
            <div className="text-sm text-secondary">
              {option.description}
            </div>
          </div>
        </label>
      ))}
    </div>
  );

  const ToggleSwitch = ({ label, description, checked, onChange }) => (
    <div className="flex items-center justify-between py-3">
      <div className="flex-1">
        <div className="font-medium text-text-primary">{label}</div>
        {description && (
          <div className="text-sm text-secondary mt-1">{description}</div>
        )}
      </div>
      <button
        type="button"
        onClick={() => onChange(!checked)}
        className={`
          relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent 
          transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2
          ${checked ? 'bg-primary' : 'bg-secondary-300'}
        `}
        role="switch"
        aria-checked={checked}
      >
        <span
          className={`
            pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 
            transition duration-200 ease-in-out
            ${checked ? 'translate-x-5' : 'translate-x-0'}
          `}
        />
      </button>
    </div>
  );

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-surface rounded-xl border border-border max-w-2xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-primary-50 rounded-lg flex items-center justify-center">
              <Icon name="Shield" size={20} className="text-primary" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-text-primary">Privacy Settings</h2>
              <p className="text-sm text-secondary">Control who can see your information</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-secondary-100 transition-colors duration-200"
            aria-label="Close modal"
          >
            <Icon name="X" size={20} className="text-secondary-600" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="flex flex-col h-full">
          <div className="flex-1 p-6 overflow-y-auto space-y-8">
            {/* Profile Visibility */}
            <SettingSection
              title="Profile Visibility"
              description="Choose who can view your complete profile"
            >
              <RadioGroup
                name="profileVisibility"
                value={settings.profileVisibility}
                options={visibilityOptions}
                onChange={(value) => handleSettingChange('profileVisibility', value)}
              />
            </SettingSection>

            {/* Contact Information */}
            <SettingSection
              title="Contact Information"
              description="Control visibility of your contact details"
            >
              <div className="space-y-1">
                <ToggleSwitch
                  label="Show Email Address"
                  description="Allow others to see your email address"
                  checked={settings.showEmail}
                  onChange={(value) => handleSettingChange('showEmail', value)}
                />
                <ToggleSwitch
                  label="Show Location"
                  description="Display your location on your profile"
                  checked={settings.showLocation}
                  onChange={(value) => handleSettingChange('showLocation', value)}
                />
              </div>
            </SettingSection>

            {/* Project History */}
            <SettingSection
              title="Project History"
              description="Who can see your past and current projects"
            >
              <RadioGroup
                name="projectHistory"
                value={settings.projectHistory}
                options={visibilityOptions}
                onChange={(value) => handleSettingChange('projectHistory', value)}
              />
            </SettingSection>

            {/* Team Interactions */}
            <SettingSection
              title="Team Interactions"
              description="Control how others can interact with you"
            >
              <div className="space-y-1">
                <ToggleSwitch
                  label="Allow Team Invitations"
                  description="Let others invite you to join their projects"
                  checked={settings.allowTeamInvites}
                  onChange={(value) => handleSettingChange('allowTeamInvites', value)}
                />
                <ToggleSwitch
                  label="Allow Mentor Requests"
                  description="Let others request mentorship from you"
                  checked={settings.allowMentorRequests}
                  onChange={(value) => handleSettingChange('allowMentorRequests', value)}
                />
              </div>
            </SettingSection>

            {/* Skill Endorsements */}
            <SettingSection
              title="Skill Endorsements"
              description="Who can endorse your skills"
            >
              <RadioGroup
                name="skillEndorsements"
                value={settings.skillEndorsements}
                options={visibilityOptions}
                onChange={(value) => handleSettingChange('skillEndorsements', value)}
              />
            </SettingSection>

            {/* Notification Preferences */}
            <SettingSection
              title="Notification Preferences"
              description="Choose what notifications you want to receive"
            >
              <div className="space-y-1">
                <ToggleSwitch
                  label="Email Notifications"
                  description="Receive important updates via email"
                  checked={settings.emailNotifications}
                  onChange={(value) => handleSettingChange('emailNotifications', value)}
                />
                <ToggleSwitch
                  label="Project Updates"
                  description="Get notified about project milestones and changes"
                  checked={settings.projectUpdates}
                  onChange={(value) => handleSettingChange('projectUpdates', value)}
                />
                <ToggleSwitch
                  label="Team Messages"
                  description="Receive notifications for team communications"
                  checked={settings.teamMessages}
                  onChange={(value) => handleSettingChange('teamMessages', value)}
                />
                <ToggleSwitch
                  label="Skill Endorsements"
                  description="Get notified when someone endorses your skills"
                  checked={settings.skillEndorsementNotifications}
                  onChange={(value) => handleSettingChange('skillEndorsementNotifications', value)}
                />
              </div>
            </SettingSection>
          </div>

          {/* Footer */}
          <div className="flex items-center justify-between p-6 border-t border-border">
            <div className="flex items-center space-x-2 text-sm text-secondary">
              <Icon name="Info" size={16} />
              <span>Changes will take effect immediately</span>
            </div>
            <div className="flex items-center space-x-3">
              <button
                type="button"
                onClick={onClose}
                className="btn-secondary"
                disabled={isLoading}
              >
                Cancel
              </button>
              <button
                type="submit"
                className="btn-primary flex items-center space-x-2"
                disabled={isLoading}
              >
                {isLoading && <Icon name="Loader2" size={16} className="animate-spin" />}
                <span>{isLoading ? 'Saving...' : 'Save Settings'}</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default PrivacySettings;