import React, { useState } from 'react';
import Icon from 'components/AppIcon';
import Image from 'components/AppImage';

const EditProfileModal = ({ userData, onClose, onSave }) => {
  const [formData, setFormData] = useState({
    name: userData.name,
    role: userData.role,
    location: userData.location,
    bio: userData.bio,
    email: userData.email,
    github: userData.github,
    linkedin: userData.linkedin,
    website: userData.website,
    avatar: userData.avatar
  });

  const [activeTab, setActiveTab] = useState('basic');
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState({});

  const tabs = [
    { id: 'basic', label: 'Basic Info', icon: 'User' },
    { id: 'social', label: 'Social Links', icon: 'Link' },
    { id: 'avatar', label: 'Profile Photo', icon: 'Camera' }
  ];

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({
        ...prev,
        [field]: null
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    }
    
    if (!formData.role.trim()) {
      newErrors.role = 'Role is required';
    }
    
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }
    
    if (formData.bio.length > 500) {
      newErrors.bio = 'Bio must be less than 500 characters';
    }
    
    // Validate URLs
    const urlFields = ['github', 'linkedin', 'website'];
    urlFields.forEach(field => {
      if (formData[field] && !isValidUrl(formData[field])) {
        newErrors[field] = 'Please enter a valid URL';
      }
    });
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const isValidUrl = (string) => {
    try {
      new URL(string);
      return true;
    } catch (_) {
      return false;
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setIsLoading(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      onSave(formData);
    } catch (error) {
      console.error('Error saving profile:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAvatarChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        handleInputChange('avatar', e.target.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const renderBasicInfo = () => (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-text-primary mb-2">
          Full Name *
        </label>
        <input
          type="text"
          value={formData.name}
          onChange={(e) => handleInputChange('name', e.target.value)}
          className={`input-field ${errors.name ? 'border-error focus:ring-error' : ''}`}
          placeholder="Enter your full name"
        />
        {errors.name && (
          <p className="text-error text-sm mt-1">{errors.name}</p>
        )}
      </div>

      <div>
        <label className="block text-sm font-medium text-text-primary mb-2">
          Professional Role *
        </label>
        <input
          type="text"
          value={formData.role}
          onChange={(e) => handleInputChange('role', e.target.value)}
          className={`input-field ${errors.role ? 'border-error focus:ring-error' : ''}`}
          placeholder="e.g., Full Stack Developer"
        />
        {errors.role && (
          <p className="text-error text-sm mt-1">{errors.role}</p>
        )}
      </div>

      <div>
        <label className="block text-sm font-medium text-text-primary mb-2">
          Location
        </label>
        <input
          type="text"
          value={formData.location}
          onChange={(e) => handleInputChange('location', e.target.value)}
          className="input-field"
          placeholder="City, Country"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-text-primary mb-2">
          Email Address *
        </label>
        <input
          type="email"
          value={formData.email}
          onChange={(e) => handleInputChange('email', e.target.value)}
          className={`input-field ${errors.email ? 'border-error focus:ring-error' : ''}`}
          placeholder="your.email@example.com"
        />
        {errors.email && (
          <p className="text-error text-sm mt-1">{errors.email}</p>
        )}
      </div>

      <div>
        <label className="block text-sm font-medium text-text-primary mb-2">
          Bio
        </label>
        <textarea
          value={formData.bio}
          onChange={(e) => handleInputChange('bio', e.target.value)}
          rows={4}
          className={`input-field resize-none ${errors.bio ? 'border-error focus:ring-error' : ''}`}
          placeholder="Tell us about yourself, your interests, and what drives you..."
        />
        <div className="flex justify-between items-center mt-1">
          {errors.bio && (
            <p className="text-error text-sm">{errors.bio}</p>
          )}
          <p className="text-sm text-secondary ml-auto">
            {formData.bio.length}/500 characters
          </p>
        </div>
      </div>
    </div>
  );

  const renderSocialLinks = () => (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-text-primary mb-2">
          GitHub Profile
        </label>
        <div className="relative">
          <Icon name="Github" size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary" />
          <input
            type="url"
            value={formData.github}
            onChange={(e) => handleInputChange('github', e.target.value)}
            className={`input-field pl-10 ${errors.github ? 'border-error focus:ring-error' : ''}`}
            placeholder="https://github.com/username"
          />
        </div>
        {errors.github && (
          <p className="text-error text-sm mt-1">{errors.github}</p>
        )}
      </div>

      <div>
        <label className="block text-sm font-medium text-text-primary mb-2">
          LinkedIn Profile
        </label>
        <div className="relative">
          <Icon name="Linkedin" size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary" />
          <input
            type="url"
            value={formData.linkedin}
            onChange={(e) => handleInputChange('linkedin', e.target.value)}
            className={`input-field pl-10 ${errors.linkedin ? 'border-error focus:ring-error' : ''}`}
            placeholder="https://linkedin.com/in/username"
          />
        </div>
        {errors.linkedin && (
          <p className="text-error text-sm mt-1">{errors.linkedin}</p>
        )}
      </div>

      <div>
        <label className="block text-sm font-medium text-text-primary mb-2">
          Personal Website
        </label>
        <div className="relative">
          <Icon name="Globe" size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary" />
          <input
            type="url"
            value={formData.website}
            onChange={(e) => handleInputChange('website', e.target.value)}
            className={`input-field pl-10 ${errors.website ? 'border-error focus:ring-error' : ''}`}
            placeholder="https://yourwebsite.com"
          />
        </div>
        {errors.website && (
          <p className="text-error text-sm mt-1">{errors.website}</p>
        )}
      </div>
    </div>
  );

  const renderAvatarUpload = () => (
    <div className="space-y-6">
      <div className="text-center">
        <div className="w-32 h-32 mx-auto rounded-full overflow-hidden border-4 border-border mb-4">
          <Image
            src={formData.avatar}
            alt="Profile preview"
            className="w-full h-full object-cover"
          />
        </div>
        
        <div className="space-y-4">
          <div>
            <input
              type="file"
              id="avatar-upload"
              accept="image/*"
              onChange={handleAvatarChange}
              className="hidden"
            />
            <label
              htmlFor="avatar-upload"
              className="btn-primary cursor-pointer inline-flex items-center space-x-2"
            >
              <Icon name="Upload" size={16} />
              <span>Upload New Photo</span>
            </label>
          </div>
          
          <p className="text-sm text-secondary">
            Recommended: Square image, at least 400x400 pixels
          </p>
        </div>
      </div>
    </div>
  );

  const renderTabContent = () => {
    switch (activeTab) {
      case 'basic':
        return renderBasicInfo();
      case 'social':
        return renderSocialLinks();
      case 'avatar':
        return renderAvatarUpload();
      default:
        return renderBasicInfo();
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-surface rounded-xl border border-border max-w-2xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <h2 className="text-xl font-semibold text-text-primary">Edit Profile</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-secondary-100 transition-colors duration-200"
            aria-label="Close modal"
          >
            <Icon name="X" size={20} className="text-secondary-600" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-border">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`
                flex-1 flex items-center justify-center space-x-2 py-3 px-4 font-medium text-sm
                transition-all duration-200 ease-out
                ${activeTab === tab.id
                  ? 'border-b-2 border-primary text-primary bg-primary-50' :'text-secondary hover:text-text-primary hover:bg-secondary-50'
                }
              `}
            >
              <Icon name={tab.icon} size={16} />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="flex flex-col h-full">
          <div className="flex-1 p-6 overflow-y-auto">
            {renderTabContent()}
          </div>

          {/* Footer */}
          <div className="flex items-center justify-end space-x-3 p-6 border-t border-border">
            <button
              type="button"
              onClick={onClose}
              className="btn-secondary"
              disabled={isLoading}
            >
              Cancel
            </button>
            <button
              type="submit"
              className="btn-primary flex items-center space-x-2"
              disabled={isLoading}
            >
              {isLoading && <Icon name="Loader2" size={16} className="animate-spin" />}
              <span>{isLoading ? 'Saving...' : 'Save Changes'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditProfileModal;