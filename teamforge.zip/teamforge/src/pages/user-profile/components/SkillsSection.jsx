import React, { useState } from 'react';
import Icon from 'components/AppIcon';

const SkillsSection = ({ userData }) => {
  const [selectedCategory, setSelectedCategory] = useState('technical');

  // Mock skills data
  const skillsData = {
    technical: [
      { name: "JavaScript", level: 90, endorsements: 12, category: "Programming Languages" },
      { name: "React", level: 85, endorsements: 10, category: "Frontend Frameworks" },
      { name: "Node.js", level: 80, endorsements: 8, category: "Backend Technologies" },
      { name: "TypeScript", level: 75, endorsements: 6, category: "Programming Languages" },
      { name: "Python", level: 70, endorsements: 5, category: "Programming Languages" },
      { name: "MongoDB", level: 75, endorsements: 7, category: "Databases" },
      { name: "PostgreSQL", level: 65, endorsements: 4, category: "Databases" },
      { name: "AWS", level: 60, endorsements: 3, category: "Cloud Platforms" },
      { name: "Docker", level: 70, endorsements: 5, category: "DevOps" },
      { name: "Git", level: 85, endorsements: 9, category: "Version Control" },
      { name: "REST APIs", level: 80, endorsements: 8, category: "Web Technologies" },
      { name: "GraphQL", level: 65, endorsements: 4, category: "Web Technologies" }
    ],
    soft: [
      { name: "Team Leadership", level: 85, endorsements: 15, category: "Leadership" },
      { name: "Communication", level: 90, endorsements: 18, category: "Interpersonal" },
      { name: "Problem Solving", level: 88, endorsements: 14, category: "Analytical" },
      { name: "Project Management", level: 75, endorsements: 9, category: "Management" },
      { name: "Mentoring", level: 80, endorsements: 11, category: "Leadership" },
      { name: "Agile Methodology", level: 85, endorsements: 10, category: "Process" },
      { name: "Code Review", level: 82, endorsements: 12, category: "Quality Assurance" },
      { name: "Technical Writing", level: 75, endorsements: 7, category: "Communication" }
    ]
  };

  const categories = [
    { id: 'technical', label: 'Technical Skills', icon: 'Code' },
    { id: 'soft', label: 'Soft Skills', icon: 'Users' }
  ];

  const getSkillLevel = (level) => {
    if (level >= 80) return { label: 'Expert', color: 'text-accent-600' };
    if (level >= 60) return { label: 'Proficient', color: 'text-primary' };
    if (level >= 40) return { label: 'Intermediate', color: 'text-warning-600' };
    return { label: 'Beginner', color: 'text-secondary' };
  };

  const groupSkillsByCategory = (skills) => {
    return skills.reduce((acc, skill) => {
      if (!acc[skill.category]) {
        acc[skill.category] = [];
      }
      acc[skill.category].push(skill);
      return acc;
    }, {});
  };

  const SkillCard = ({ skill }) => {
    const skillLevel = getSkillLevel(skill.level);
    
    return (
      <div className="bg-surface rounded-lg border border-border p-4 hover:shadow-subtle transition-all duration-200 ease-out">
        <div className="flex items-center justify-between mb-3">
          <h4 className="font-medium text-text-primary">{skill.name}</h4>
          <span className={`text-sm font-medium ${skillLevel.color}`}>
            {skillLevel.label}
          </span>
        </div>
        
        {/* Progress Bar */}
        <div className="mb-3">
          <div className="flex items-center justify-between text-sm text-secondary mb-1">
            <span>Proficiency</span>
            <span>{skill.level}%</span>
          </div>
          <div className="w-full bg-secondary-200 rounded-full h-2">
            <div
              className="bg-primary h-2 rounded-full transition-all duration-500 ease-out"
              style={{ width: `${skill.level}%` }}
            />
          </div>
        </div>
        
        {/* Endorsements */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-1 text-sm text-secondary">
            <Icon name="ThumbsUp" size={14} />
            <span>{skill.endorsements} endorsements</span>
          </div>
          <button className="text-sm text-primary hover:text-primary-700 transition-colors duration-200">
            Endorse
          </button>
        </div>
      </div>
    );
  };

  const SkillCategorySection = ({ categoryName, skills }) => (
    <div className="mb-8">
      <h3 className="text-lg font-semibold text-text-primary mb-4 flex items-center space-x-2">
        <span>{categoryName}</span>
        <span className="text-sm text-secondary font-normal">({skills.length})</span>
      </h3>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {skills.map((skill, index) => (
          <SkillCard key={index} skill={skill} />
        ))}
      </div>
    </div>
  );

  const currentSkills = skillsData[selectedCategory];
  const groupedSkills = groupSkillsByCategory(currentSkills);

  return (
    <div className="space-y-6">
      {/* Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
        <div>
          <h2 className="text-2xl font-bold text-text-primary">Skills & Expertise</h2>
          <p className="text-secondary mt-1">
            Technical proficiencies and soft skills with peer endorsements
          </p>
        </div>
        
        {/* Add Skill Button */}
        <button className="btn-secondary flex items-center space-x-2">
          <Icon name="Plus" size={16} />
          <span>Add Skill</span>
        </button>
      </div>

      {/* Category Tabs */}
      <div className="flex space-x-1 bg-secondary-100 rounded-lg p-1">
        {categories.map((category) => (
          <button
            key={category.id}
            onClick={() => setSelectedCategory(category.id)}
            className={`
              flex-1 flex items-center justify-center space-x-2 py-2 px-4 rounded-md font-medium text-sm
              transition-all duration-200 ease-out
              ${selectedCategory === category.id
                ? 'bg-surface text-primary shadow-subtle'
                : 'text-secondary hover:text-text-primary'
              }
            `}
          >
            <Icon name={category.icon} size={18} />
            <span>{category.label}</span>
          </button>
        ))}
      </div>

      {/* Skills Overview Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-surface rounded-lg border border-border p-4 text-center">
          <div className="text-2xl font-bold text-primary mb-1">
            {currentSkills.length}
          </div>
          <div className="text-sm text-secondary">
            {selectedCategory === 'technical' ? 'Technical Skills' : 'Soft Skills'}
          </div>
        </div>
        
        <div className="bg-surface rounded-lg border border-border p-4 text-center">
          <div className="text-2xl font-bold text-accent mb-1">
            {currentSkills.filter(skill => skill.level >= 80).length}
          </div>
          <div className="text-sm text-secondary">Expert Level</div>
        </div>
        
        <div className="bg-surface rounded-lg border border-border p-4 text-center">
          <div className="text-2xl font-bold text-warning mb-1">
            {currentSkills.reduce((sum, skill) => sum + skill.endorsements, 0)}
          </div>
          <div className="text-sm text-secondary">Total Endorsements</div>
        </div>
        
        <div className="bg-surface rounded-lg border border-border p-4 text-center">
          <div className="text-2xl font-bold text-secondary-600 mb-1">
            {Math.round(currentSkills.reduce((sum, skill) => sum + skill.level, 0) / currentSkills.length)}%
          </div>
          <div className="text-sm text-secondary">Average Proficiency</div>
        </div>
      </div>

      {/* Skills by Category */}
      <div className="space-y-8">
        {Object.entries(groupedSkills).map(([categoryName, skills]) => (
          <SkillCategorySection
            key={categoryName}
            categoryName={categoryName}
            skills={skills}
          />
        ))}
      </div>

      {/* Skill Assessment CTA */}
      <div className="bg-primary-50 rounded-lg border border-primary-200 p-6 text-center">
        <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
          <Icon name="Target" size={24} className="text-white" />
        </div>
        <h3 className="text-lg font-semibold text-text-primary mb-2">
          Take Skill Assessments
        </h3>
        <p className="text-secondary mb-4">
          Validate your skills with peer assessments and earn verified badges to strengthen your profile.
        </p>
        <button className="btn-primary">
          Start Assessment
        </button>
      </div>
    </div>
  );
};

export default SkillsSection;