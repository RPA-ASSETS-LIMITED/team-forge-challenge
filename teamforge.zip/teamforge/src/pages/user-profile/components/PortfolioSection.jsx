import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from 'components/AppIcon';
import Image from 'components/AppImage';

const PortfolioSection = ({ userData }) => {
  const navigate = useNavigate();
  const [filter, setFilter] = useState('all');

  // Mock portfolio projects
  const portfolioProjects = [
    {
      id: 1,
      title: "EcoTracker - Sustainability App",
      description: "A comprehensive web application that helps users track their carbon footprint and discover eco-friendly alternatives for daily activities.",
      thumbnail: "https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?w=400&h=300&fit=crop",
      technologies: ["React", "Node.js", "MongoDB", "Chart.js"],
      teamSize: 4,
      role: "Frontend Lead",
      status: "completed",
      liveDemo: "https://ecotracker-demo.com",
      repository: "https://github.com/sarahchen/ecotracker",
      completedDate: "2024-01-15",
      achievements: ["Best UI/UX Design", "Most Innovative Solution"],
      userContributions: `Led the frontend development team and designed the user interface. Implemented responsive design patterns and created reusable component library. Integrated data visualization features for carbon footprint tracking.`
    },
    {
      id: 2,
      title: "TaskFlow - Project Management Tool",
      description: "A collaborative project management platform designed for small teams with real-time updates and intuitive task organization.",
      thumbnail: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=400&h=300&fit=crop",
      technologies: ["React", "TypeScript", "Firebase", "Material-UI"],
      teamSize: 5,
      role: "Full Stack Developer",
      status: "completed",
      liveDemo: "https://taskflow-demo.com",
      repository: "https://github.com/sarahchen/taskflow",
      completedDate: "2023-11-20",
      achievements: ["Team Choice Award"],
      userContributions: `Developed both frontend and backend components. Implemented real-time collaboration features using WebSocket connections. Created automated testing suite with 90% code coverage.`
    },
    {
      id: 3,
      title: "FoodieConnect - Recipe Sharing Platform",
      description: "A social platform where food enthusiasts can share recipes, rate dishes, and connect with fellow cooking enthusiasts worldwide.",
      thumbnail: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&h=300&fit=crop",
      technologies: ["Vue.js", "Express.js", "PostgreSQL", "AWS S3"],
      teamSize: 3,
      role: "Backend Developer",
      status: "in-progress",
      repository: "https://github.com/sarahchen/foodieconnect",
      completedDate: null,
      achievements: [],
      userContributions: `Architected the backend API and database schema. Implemented user authentication and authorization systems. Developed image upload and processing pipeline for recipe photos.`
    },
    {
      id: 4,
      title: "MindfulMoments - Meditation App",
      description: "A mobile-first web application providing guided meditation sessions, progress tracking, and mindfulness exercises for daily wellness.",
      thumbnail: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=300&fit=crop",
      technologies: ["React Native", "Redux", "Node.js", "MongoDB"],
      teamSize: 6,
      role: "Mobile Developer",
      status: "completed",
      liveDemo: "https://mindfulmoments-demo.com",
      repository: "https://github.com/sarahchen/mindfulmoments",
      completedDate: "2023-09-10",
      achievements: ["Most User-Friendly App", "Health & Wellness Innovation"],
      userContributions: `Developed cross-platform mobile application using React Native. Implemented offline functionality and local data synchronization. Created smooth animations and intuitive user interactions.`
    }
  ];

  const filterOptions = [
    { value: 'all', label: 'All Projects' },
    { value: 'completed', label: 'Completed' },
    { value: 'in-progress', label: 'In Progress' }
  ];

  const filteredProjects = filter === 'all' 
    ? portfolioProjects 
    : portfolioProjects.filter(project => project.status === filter);

  const ProjectCard = ({ project }) => {
    const [showDetails, setShowDetails] = useState(false);

    return (
      <div className="bg-surface rounded-lg border border-border overflow-hidden hover:shadow-prominent transition-all duration-300 ease-out">
        {/* Project Thumbnail */}
        <div className="relative h-48 overflow-hidden">
          <Image
            src={project.thumbnail}
            alt={project.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute top-3 right-3">
            <span className={`
              px-2 py-1 rounded-full text-xs font-medium
              ${project.status === 'completed' 
                ? 'bg-accent-100 text-accent-600' :'bg-warning-100 text-warning-600'
              }
            `}>
              {project.status === 'completed' ? 'Completed' : 'In Progress'}
            </span>
          </div>
          {project.achievements.length > 0 && (
            <div className="absolute top-3 left-3">
              <div className="w-8 h-8 bg-warning rounded-full flex items-center justify-center">
                <Icon name="Award" size={16} className="text-white" />
              </div>
            </div>
          )}
        </div>

        {/* Project Info */}
        <div className="p-6">
          <div className="flex items-start justify-between mb-3">
            <h3 className="text-lg font-semibold text-text-primary line-clamp-2">
              {project.title}
            </h3>
            <button
              onClick={() => setShowDetails(!showDetails)}
              className="p-1 rounded-lg hover:bg-secondary-100 transition-colors duration-200"
              aria-label="Toggle project details"
            >
              <Icon 
                name={showDetails ? "ChevronUp" : "ChevronDown"} 
                size={20} 
                className="text-secondary-600" 
              />
            </button>
          </div>

          <p className="text-secondary text-sm mb-4 line-clamp-2">
            {project.description}
          </p>

          {/* Technologies */}
          <div className="flex flex-wrap gap-2 mb-4">
            {project.technologies.map((tech, index) => (
              <span
                key={index}
                className="px-2 py-1 bg-primary-50 text-primary-700 text-xs rounded-md font-medium"
              >
                {tech}
              </span>
            ))}
          </div>

          {/* Project Meta */}
          <div className="flex items-center justify-between text-sm text-secondary mb-4">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-1">
                <Icon name="Users" size={16} />
                <span>{project.teamSize} members</span>
              </div>
              <div className="flex items-center space-x-1">
                <Icon name="User" size={16} />
                <span>{project.role}</span>
              </div>
            </div>
            {project.completedDate && (
              <span>{new Date(project.completedDate).toLocaleDateString()}</span>
            )}
          </div>

          {/* Expanded Details */}
          {showDetails && (
            <div className="border-t border-border pt-4 space-y-4 animation-slide-up">
              {/* Achievements */}
              {project.achievements.length > 0 && (
                <div>
                  <h4 className="font-medium text-text-primary mb-2">Achievements</h4>
                  <div className="flex flex-wrap gap-2">
                    {project.achievements.map((achievement, index) => (
                      <span
                        key={index}
                        className="px-2 py-1 bg-warning-50 text-warning-700 text-xs rounded-md font-medium flex items-center space-x-1"
                      >
                        <Icon name="Award" size={12} />
                        <span>{achievement}</span>
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* User Contributions */}
              <div>
                <h4 className="font-medium text-text-primary mb-2">My Contributions</h4>
                <p className="text-sm text-secondary leading-relaxed">
                  {project.userContributions}
                </p>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex space-x-3 mt-4">
            {project.liveDemo && (
              <a
                href={project.liveDemo}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 btn-primary text-center flex items-center justify-center space-x-2"
              >
                <Icon name="ExternalLink" size={16} />
                <span>Live Demo</span>
              </a>
            )}
            <a
              href={project.repository}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 btn-secondary text-center flex items-center justify-center space-x-2"
            >
              <Icon name="Github" size={16} />
              <span>Code</span>
            </a>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
        <div>
          <h2 className="text-2xl font-bold text-text-primary">Portfolio</h2>
          <p className="text-secondary mt-1">
            Showcase of completed and ongoing projects
          </p>
        </div>
        
        <div className="flex items-center space-x-3">
          {/* Filter Dropdown */}
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="input-field text-sm min-w-[140px]"
          >
            {filterOptions.map(option => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
          
          <button
            onClick={() => navigate('/project-portfolio-gallery')}
            className="btn-secondary flex items-center space-x-2"
          >
            <Icon name="Grid" size={16} />
            <span className="hidden sm:inline">Gallery View</span>
          </button>
        </div>
      </div>

      {/* Projects Grid */}
      {filteredProjects.length > 0 ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {filteredProjects.map(project => (
            <ProjectCard key={project.id} project={project} />
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-secondary-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Icon name="Briefcase" size={32} className="text-secondary" />
          </div>
          <h3 className="text-lg font-medium text-text-primary mb-2">
            No projects found
          </h3>
          <p className="text-secondary mb-6">
            {filter === 'all' 
              ? "Start building your portfolio by joining or creating projects."
              : `No ${filter.replace('-', ' ')} projects to display.`
            }
          </p>
          <button
            onClick={() => navigate('/project-discovery')}
            className="btn-primary"
          >
            Discover Projects
          </button>
        </div>
      )}
    </div>
  );
};

export default PortfolioSection;