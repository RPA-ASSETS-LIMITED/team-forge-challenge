import React, { useState } from 'react';
import Icon from 'components/AppIcon';
import Image from 'components/AppImage';

const ExperienceTimeline = ({ userData }) => {
  const [expandedItems, setExpandedItems] = useState(new Set());

  // Mock experience data
  const experienceData = [
    {
      id: 1,
      type: 'project',
      title: "EcoTracker - Sustainability App",
      organization: "GreenTech Initiative",
      role: "Frontend Lead",
      startDate: "2023-12-01",
      endDate: "2024-01-15",
      status: "completed",
      description: `Led a team of 4 developers in creating a comprehensive sustainability tracking application. The project focused on helping users monitor their carbon footprint and discover eco-friendly alternatives.`,
      achievements: [
        "Delivered project 2 weeks ahead of schedule",
        "Achieved 95% user satisfaction rating in testing",
        "Won \'Best UI/UX Design\' award at project showcase",
        "Implemented responsive design supporting 5+ device types"
      ],
      skills: ["React", "TypeScript", "Figma", "Team Leadership"],
      teamMembers: [
        { name: "Alex Johnson", avatar: "https://randomuser.me/api/portraits/men/1.jpg" },
        { name: "Maria Garcia", avatar: "https://randomuser.me/api/portraits/women/2.jpg" },
        { name: "David Kim", avatar: "https://randomuser.me/api/portraits/men/3.jpg" }
      ],
      learningOutcomes: `This project significantly enhanced my leadership skills and deepened my understanding of sustainable technology solutions. I learned to balance technical excellence with environmental impact considerations.`,
      impact: "The application prototype was adopted by 3 local environmental organizations for pilot testing."
    },
    {
      id: 2,
      type: 'project',
      title: "TaskFlow - Project Management Tool",
      organization: "Productivity Solutions Team",
      role: "Full Stack Developer",
      startDate: "2023-09-15",
      endDate: "2023-11-20",
      status: "completed",
      description: `Developed a collaborative project management platform designed for small teams with real-time updates and intuitive task organization features.`,
      achievements: [
        "Implemented real-time collaboration features",
        "Achieved 90% code coverage with automated testing",
        "Reduced task management overhead by 40%",
        "Received \'Team Choice Award\' from peer evaluation"
      ],
      skills: ["React", "Node.js", "Socket.io", "MongoDB", "Jest"],
      teamMembers: [
        { name: "Jennifer Liu", avatar: "https://randomuser.me/api/portraits/women/4.jpg" },
        { name: "Michael Brown", avatar: "https://randomuser.me/api/portraits/men/5.jpg" },
        { name: "Sarah Wilson", avatar: "https://randomuser.me/api/portraits/women/6.jpg" },
        { name: "James Davis", avatar: "https://randomuser.me/api/portraits/men/7.jpg" }
      ],
      learningOutcomes: `Gained extensive experience in full-stack development and real-time web technologies. Improved my ability to architect scalable applications and work effectively in cross-functional teams.`,
      impact: "The tool is now used by 5 teams within the organization for their daily project management needs."
    },
    {
      id: 3,
      type: 'achievement',
      title: "Certified React Developer",
      organization: "React Training Institute",
      role: "Student",
      startDate: "2023-08-01",
      endDate: "2023-08-30",
      status: "completed",
      description: `Completed intensive React certification program covering advanced concepts, performance optimization, and modern development practices.`,
      achievements: [
        "Scored 95% on final certification exam",
        "Completed 5 hands-on projects",
        "Mastered React Hooks and Context API",
        "Learned advanced state management patterns"
      ],
      skills: ["React", "Redux", "React Router", "Testing Library"],
      learningOutcomes: `This certification solidified my React expertise and introduced me to advanced patterns and best practices that I now apply in all my projects.`,
      impact: "The knowledge gained directly contributed to my selection as Frontend Lead for subsequent projects."
    },
    {
      id: 4,
      type: 'project',
      title: "MindfulMoments - Meditation App",
      organization: "Wellness Tech Collective",
      role: "Mobile Developer",
      startDate: "2023-06-01",
      endDate: "2023-09-10",
      status: "completed",
      description: `Created a mobile-first web application providing guided meditation sessions, progress tracking, and mindfulness exercises for daily wellness.`,
      achievements: [
        "Developed cross-platform mobile application",
        "Implemented offline functionality",
        "Won \'Most User-Friendly App\' award",
        "Achieved 4.8/5 user rating in beta testing"
      ],
      skills: ["React Native", "Redux", "AsyncStorage", "Animation"],
      teamMembers: [
        { name: "Emma Thompson", avatar: "https://randomuser.me/api/portraits/women/8.jpg" },
        { name: "Ryan Martinez", avatar: "https://randomuser.me/api/portraits/men/9.jpg" },
        { name: "Lisa Anderson", avatar: "https://randomuser.me/api/portraits/women/10.jpg" },
        { name: "Kevin Lee", avatar: "https://randomuser.me/api/portraits/men/11.jpg" },
        { name: "Sophie Chen", avatar: "https://randomuser.me/api/portraits/women/12.jpg" }
      ],
      learningOutcomes: `Gained valuable experience in mobile development and user experience design. Learned to create intuitive interfaces for wellness applications and implement smooth animations.`,
      impact: "The app prototype received interest from 2 wellness startups for potential licensing."
    },
    {
      id: 5,
      type: 'milestone',
      title: "Joined TeamForge Platform",
      organization: "TeamForge",
      role: "Community Member",
      startDate: "2023-03-15",
      endDate: null,
      status: "ongoing",
      description: `Started my journey on TeamForge platform to gain hands-on experience in collaborative software development and build a professional portfolio.`,
      achievements: [
        "Completed 12 collaborative projects",
        "Mentored 8 junior developers",
        "Maintained 4.8/5 team rating",
        "Built comprehensive project portfolio"
      ],
      skills: ["Collaboration", "Mentoring", "Project Management", "Communication"],
      learningOutcomes: `TeamForge has been instrumental in my professional development, providing opportunities to work with diverse teams and tackle real-world challenges.`,
      impact: "My portfolio built through TeamForge projects helped me secure 3 freelance opportunities and 2 job interviews."
    }
  ];

  const toggleExpanded = (itemId) => {
    const newExpanded = new Set(expandedItems);
    if (newExpanded.has(itemId)) {
      newExpanded.delete(itemId);
    } else {
      newExpanded.add(itemId);
    }
    setExpandedItems(newExpanded);
  };

  const getTypeIcon = (type) => {
    switch (type) {
      case 'project': return 'Briefcase';
      case 'achievement': return 'Award';
      case 'milestone': return 'Flag';
      default: return 'Circle';
    }
  };

  const getTypeColor = (type) => {
    switch (type) {
      case 'project': return 'bg-primary text-white';
      case 'achievement': return 'bg-warning text-white';
      case 'milestone': return 'bg-accent text-white';
      default: return 'bg-secondary text-white';
    }
  };

  const formatDateRange = (startDate, endDate) => {
    const start = new Date(startDate).toLocaleDateString('en-US', { 
      month: 'short', 
      year: 'numeric' 
    });
    
    if (!endDate) {
      return `${start} - Present`;
    }
    
    const end = new Date(endDate).toLocaleDateString('en-US', { 
      month: 'short', 
      year: 'numeric' 
    });
    
    return `${start} - ${end}`;
  };

  const calculateDuration = (startDate, endDate) => {
    const start = new Date(startDate);
    const end = endDate ? new Date(endDate) : new Date();
    const diffTime = Math.abs(end - start);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays < 30) {
      return `${diffDays} days`;
    } else if (diffDays < 365) {
      const months = Math.floor(diffDays / 30);
      return `${months} month${months > 1 ? 's' : ''}`;
    } else {
      const years = Math.floor(diffDays / 365);
      const remainingMonths = Math.floor((diffDays % 365) / 30);
      return `${years} year${years > 1 ? 's' : ''}${remainingMonths > 0 ? ` ${remainingMonths} month${remainingMonths > 1 ? 's' : ''}` : ''}`;
    }
  };

  const TimelineItem = ({ item, isLast }) => {
    const isExpanded = expandedItems.has(item.id);
    
    return (
      <div className="relative">
        {/* Timeline Line */}
        {!isLast && (
          <div className="absolute left-6 top-16 w-0.5 h-full bg-border"></div>
        )}
        
        <div className="flex space-x-4">
          {/* Timeline Icon */}
          <div className={`
            w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 z-10
            ${getTypeColor(item.type)}
          `}>
            <Icon name={getTypeIcon(item.type)} size={20} />
          </div>
          
          {/* Content */}
          <div className="flex-1 pb-8">
            <div className="bg-surface rounded-lg border border-border p-6 hover:shadow-subtle transition-all duration-200 ease-out">
              {/* Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-text-primary mb-1">
                    {item.title}
                  </h3>
                  <div className="flex flex-col sm:flex-row sm:items-center sm:space-x-4 text-sm text-secondary">
                    <span className="font-medium">{item.organization}</span>
                    <span>•</span>
                    <span>{item.role}</span>
                    <span>•</span>
                    <span>{formatDateRange(item.startDate, item.endDate)}</span>
                    <span>•</span>
                    <span>{calculateDuration(item.startDate, item.endDate)}</span>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2 ml-4">
                  <span className={`
                    px-2 py-1 rounded-full text-xs font-medium
                    ${item.status === 'completed' 
                      ? 'bg-accent-100 text-accent-600' :'bg-primary-100 text-primary-600'
                    }
                  `}>
                    {item.status === 'completed' ? 'Completed' : 'Ongoing'}
                  </span>
                  
                  <button
                    onClick={() => toggleExpanded(item.id)}
                    className="p-1 rounded-lg hover:bg-secondary-100 transition-colors duration-200"
                    aria-label="Toggle details"
                  >
                    <Icon 
                      name={isExpanded ? "ChevronUp" : "ChevronDown"} 
                      size={20} 
                      className="text-secondary-600" 
                    />
                  </button>
                </div>
              </div>
              
              {/* Description */}
              <p className="text-secondary mb-4 leading-relaxed">
                {item.description}
              </p>
              
              {/* Skills */}
              <div className="flex flex-wrap gap-2 mb-4">
                {item.skills.map((skill, index) => (
                  <span
                    key={index}
                    className="px-2 py-1 bg-primary-50 text-primary-700 text-xs rounded-md font-medium"
                  >
                    {skill}
                  </span>
                ))}
              </div>
              
              {/* Team Members (if applicable) */}
              {item.teamMembers && item.teamMembers.length > 0 && (
                <div className="flex items-center space-x-2 mb-4">
                  <span className="text-sm text-secondary">Team:</span>
                  <div className="flex -space-x-2">
                    {item.teamMembers.slice(0, 4).map((member, index) => (
                      <div
                        key={index}
                        className="w-8 h-8 rounded-full border-2 border-surface overflow-hidden"
                        title={member.name}
                      >
                        <Image
                          src={member.avatar}
                          alt={member.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    ))}
                    {item.teamMembers.length > 4 && (
                      <div className="w-8 h-8 rounded-full border-2 border-surface bg-secondary-100 flex items-center justify-center">
                        <span className="text-xs text-secondary font-medium">
                          +{item.teamMembers.length - 4}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              )}
              
              {/* Expanded Details */}
              {isExpanded && (
                <div className="border-t border-border pt-4 space-y-4 animation-slide-up">
                  {/* Achievements */}
                  <div>
                    <h4 className="font-medium text-text-primary mb-2 flex items-center space-x-2">
                      <Icon name="Trophy" size={16} className="text-warning" />
                      <span>Key Achievements</span>
                    </h4>
                    <ul className="space-y-1">
                      {item.achievements.map((achievement, index) => (
                        <li key={index} className="flex items-start space-x-2 text-sm text-secondary">
                          <Icon name="Check" size={14} className="text-accent mt-0.5 flex-shrink-0" />
                          <span>{achievement}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  {/* Learning Outcomes */}
                  <div>
                    <h4 className="font-medium text-text-primary mb-2 flex items-center space-x-2">
                      <Icon name="BookOpen" size={16} className="text-primary" />
                      <span>Learning Outcomes</span>
                    </h4>
                    <p className="text-sm text-secondary leading-relaxed">
                      {item.learningOutcomes}
                    </p>
                  </div>
                  
                  {/* Impact */}
                  {item.impact && (
                    <div>
                      <h4 className="font-medium text-text-primary mb-2 flex items-center space-x-2">
                        <Icon name="Target" size={16} className="text-accent" />
                        <span>Impact & Results</span>
                      </h4>
                      <p className="text-sm text-secondary leading-relaxed">
                        {item.impact}
                      </p>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
        <div>
          <h2 className="text-2xl font-bold text-text-primary">Experience Timeline</h2>
          <p className="text-secondary mt-1">
            Chronological journey of projects, achievements, and learning milestones
          </p>
        </div>
        
        <div className="flex items-center space-x-3">
          <button className="btn-secondary flex items-center space-x-2">
            <Icon name="Download" size={16} />
            <span>Export Timeline</span>
          </button>
        </div>
      </div>

      {/* Timeline Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-surface rounded-lg border border-border p-4 text-center">
          <div className="text-2xl font-bold text-primary mb-1">
            {experienceData.filter(item => item.type === 'project').length}
          </div>
          <div className="text-sm text-secondary">Projects</div>
        </div>
        
        <div className="bg-surface rounded-lg border border-border p-4 text-center">
          <div className="text-2xl font-bold text-warning mb-1">
            {experienceData.filter(item => item.type === 'achievement').length}
          </div>
          <div className="text-sm text-secondary">Achievements</div>
        </div>
        
        <div className="bg-surface rounded-lg border border-border p-4 text-center">
          <div className="text-2xl font-bold text-accent mb-1">
            {experienceData.filter(item => item.status === 'completed').length}
          </div>
          <div className="text-sm text-secondary">Completed</div>
        </div>
        
        <div className="bg-surface rounded-lg border border-border p-4 text-center">
          <div className="text-2xl font-bold text-secondary-600 mb-1">
            {Math.round((Date.now() - new Date(experienceData[experienceData.length - 1].startDate)) / (1000 * 60 * 60 * 24 * 30))}
          </div>
          <div className="text-sm text-secondary">Months Active</div>
        </div>
      </div>

      {/* Timeline */}
      <div className="relative">
        {experienceData.map((item, index) => (
          <TimelineItem
            key={item.id}
            item={item}
            isLast={index === experienceData.length - 1}
          />
        ))}
      </div>
    </div>
  );
};

export default ExperienceTimeline;