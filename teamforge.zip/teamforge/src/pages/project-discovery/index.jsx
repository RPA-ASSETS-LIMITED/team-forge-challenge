import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from 'components/AppIcon';
import Image from 'components/AppImage';
import ProjectFilterPanel from 'components/ui/ProjectFilterPanel';

const ProjectDiscovery = () => {
  const navigate = useNavigate();
  const [projects, setProjects] = useState([]);
  const [filteredProjects, setFilteredProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('relevance');
  const [showFilters, setShowFilters] = useState(false);
  const [activeFilters, setActiveFilters] = useState({
    skills: [],
    difficulty: '',
    duration: '',
    teamSize: '',
    status: '',
    category: ''
  });
  const [savedSearches, setSavedSearches] = useState([]);
  const [bookmarkedProjects, setBookmarkedProjects] = useState([]);
  const [refreshing, setRefreshing] = useState(false);

  // Mock project data
  const mockProjects = [
    {
      id: 1,
      title: "E-commerce Platform with React & Node.js",
      description: `Build a full-stack e-commerce platform with modern React frontend and Node.js backend. Features include user authentication, product catalog, shopping cart, payment integration, and admin dashboard. Perfect for learning full-stack development patterns and real-world application architecture.`,
      skills: ["React", "Node.js", "MongoDB", "Express", "Stripe API"],
      difficulty: "intermediate",
      duration: "3-4weeks",
      teamSize: "4-6",
      currentMembers: 3,
      maxMembers: 5,
      status: "recruiting",
      category: "web-app",
      deadline: new Date(Date.now() + 21 * 24 * 60 * 60 * 1000),
      createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
      image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=400&h=250&fit=crop",
      author: {
        name: "Sarah Chen",
        avatar: "https://randomuser.me/api/portraits/women/32.jpg",
        role: "Full Stack Developer"
      },
      tags: ["Popular", "Urgent"],
      interestCount: 24,
      viewCount: 156
    },
    {
      id: 2,
      title: "Mobile Fitness Tracker App",
      description: `Create a comprehensive fitness tracking mobile application using React Native. The app will include workout logging, progress tracking, social features, and integration with health APIs. Great opportunity to learn mobile development and health data management.`,
      skills: ["React Native", "Firebase", "Health APIs", "Redux"],
      difficulty: "beginner",
      duration: "1-2months",
      teamSize: "2-3",
      currentMembers: 1,
      maxMembers: 3,
      status: "recruiting",
      category: "mobile-app",
      deadline: new Date(Date.now() + 45 * 24 * 60 * 60 * 1000),
      createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      image: "https://images.pexels.com/photos/4164418/pexels-photo-4164418.jpeg?w=400&h=250&fit=crop",
      author: {
        name: "Mike Rodriguez",
        avatar: "https://randomuser.me/api/portraits/men/45.jpg",
        role: "Mobile Developer"
      },
      tags: ["Beginner Friendly"],
      interestCount: 18,
      viewCount: 89
    },
    {
      id: 3,
      title: "AI-Powered Task Management System",
      description: `Develop an intelligent task management system that uses machine learning to predict task completion times, suggest optimal scheduling, and provide productivity insights. This project combines frontend development with AI/ML integration.`,
      skills: ["Python", "TensorFlow", "React", "FastAPI", "PostgreSQL"],
      difficulty: "advanced",
      duration: "3-6months",
      teamSize: "7-10",
      currentMembers: 6,
      maxMembers: 8,
      status: "recruiting",
      category: "ai-ml",
      deadline: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000),
      createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
      image: "https://images.pixabay.com/photo/2023/01/26/22/14/ai-generated-7747171_1280.jpg?w=400&h=250&fit=crop",
      author: {
        name: "Dr. Emily Watson",
        avatar: "https://randomuser.me/api/portraits/women/67.jpg",
        role: "AI Research Engineer"
      },
      tags: ["Advanced", "High Interest"],
      interestCount: 42,
      viewCount: 234
    },
    {
      id: 4,
      title: "Open Source Developer Tools",
      description: `Contribute to building developer productivity tools including code formatters, linters, and IDE extensions. This project focuses on creating tools that developers use daily, providing excellent open source contribution experience.`,
      skills: ["TypeScript", "VS Code API", "Node.js", "Jest"],
      difficulty: "intermediate",
      duration: "1-2months",
      teamSize: "4-6",
      currentMembers: 2,
      maxMembers: 5,
      status: "recruiting",
      category: "devtools",
      deadline: new Date(Date.now() + 35 * 24 * 60 * 60 * 1000),
      createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
      image: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=400&h=250&fit=crop",
      author: {
        name: "Alex Thompson",
        avatar: "https://randomuser.me/api/portraits/men/23.jpg",
        role: "DevTools Engineer"
      },
      tags: ["Open Source"],
      interestCount: 31,
      viewCount: 178
    },
    {
      id: 5,
      title: "Real-time Multiplayer Game",
      description: `Build a browser-based multiplayer game using WebSocket technology. Features include real-time gameplay, player matchmaking, leaderboards, and social features. Perfect for learning real-time communication and game development concepts.`,
      skills: ["JavaScript", "Socket.io", "Canvas API", "Node.js"],
      difficulty: "intermediate",
      duration: "6weeks",
      teamSize: "4-6",
      currentMembers: 4,
      maxMembers: 6,
      status: "in-progress",
      category: "game",
      deadline: new Date(Date.now() + 28 * 24 * 60 * 60 * 1000),
      createdAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000),
      image: "https://images.pexels.com/photos/442576/pexels-photo-442576.jpeg?w=400&h=250&fit=crop",
      author: {
        name: "Jordan Kim",
        avatar: "https://randomuser.me/api/portraits/women/28.jpg",
        role: "Game Developer"
      },
      tags: ["In Progress"],
      interestCount: 19,
      viewCount: 145
    },
    {
      id: 6,
      title: "Data Visualization Dashboard",
      description: `Create an interactive data visualization dashboard for analyzing business metrics. The project includes data processing, chart generation, real-time updates, and export capabilities. Great for learning data visualization and analytics.`,
      skills: ["React", "D3.js", "Python", "Pandas", "Chart.js"],
      difficulty: "intermediate",
      duration: "1-2months",
      teamSize: "2-3",
      currentMembers: 1,
      maxMembers: 3,
      status: "recruiting",
      category: "data-science",
      deadline: new Date(Date.now() + 50 * 24 * 60 * 60 * 1000),
      createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      image: "https://images.pixabay.com/photo/2016/11/27/21/42/stock-1863880_1280.jpg?w=400&h=250&fit=crop",
      author: {
        name: "David Park",
        avatar: "https://randomuser.me/api/portraits/men/34.jpg",
        role: "Data Scientist"
      },
      tags: ["New"],
      interestCount: 12,
      viewCount: 67
    }
  ];

  // Initialize data
  useEffect(() => {
    const loadProjects = async () => {
      setLoading(true);
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      setProjects(mockProjects);
      setFilteredProjects(mockProjects);
      setLoading(false);
    };

    loadProjects();
  }, []);

  // Filter and search logic
  useEffect(() => {
    let filtered = [...projects];

    // Apply search query
    if (searchQuery.trim()) {
      filtered = filtered.filter(project =>
        project.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        project.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        project.skills.some(skill => skill.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }

    // Apply filters
    if (activeFilters.skills.length > 0) {
      filtered = filtered.filter(project =>
        activeFilters.skills.some(skill => project.skills.includes(skill))
      );
    }

    if (activeFilters.difficulty) {
      filtered = filtered.filter(project => project.difficulty === activeFilters.difficulty);
    }

    if (activeFilters.duration) {
      filtered = filtered.filter(project => project.duration === activeFilters.duration);
    }

    if (activeFilters.teamSize) {
      filtered = filtered.filter(project => project.teamSize === activeFilters.teamSize);
    }

    if (activeFilters.status) {
      filtered = filtered.filter(project => project.status === activeFilters.status);
    }

    if (activeFilters.category) {
      filtered = filtered.filter(project => project.category === activeFilters.category);
    }

    // Apply sorting
    switch (sortBy) {
      case 'newest':
        filtered.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        break;
      case 'deadline':
        filtered.sort((a, b) => new Date(a.deadline) - new Date(b.deadline));
        break;
      case 'popularity':
        filtered.sort((a, b) => b.interestCount - a.interestCount);
        break;
      case 'team-size':
        filtered.sort((a, b) => a.currentMembers - b.currentMembers);
        break;
      default: // relevance
        break;
    }

    setFilteredProjects(filtered);
  }, [projects, searchQuery, activeFilters, sortBy]);

  const handleRefresh = useCallback(async () => {
    setRefreshing(true);
    // Simulate refresh
    await new Promise(resolve => setTimeout(resolve, 1000));
    setRefreshing(false);
  }, []);

  const handleApplyFilters = (filters) => {
    setActiveFilters(filters);
  };

  const handleBookmark = (projectId) => {
    setBookmarkedProjects(prev =>
      prev.includes(projectId)
        ? prev.filter(id => id !== projectId)
        : [...prev, projectId]
    );
  };

  const handleJoinRequest = (projectId) => {
    // Simulate join request
    console.log('Join request sent for project:', projectId);
    // In real app, this would make an API call
  };

  const getActiveFilterCount = () => {
    let count = 0;
    if (activeFilters.skills.length > 0) count++;
    if (activeFilters.difficulty) count++;
    if (activeFilters.duration) count++;
    if (activeFilters.teamSize) count++;
    if (activeFilters.status) count++;
    if (activeFilters.category) count++;
    return count;
  };

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'beginner': return 'bg-success-100 text-success-600';
      case 'intermediate': return 'bg-warning-100 text-warning-600';
      case 'advanced': return 'bg-error-100 text-error-600';
      default: return 'bg-secondary-100 text-secondary-600';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'recruiting': return 'bg-success-100 text-success-600';
      case 'in-progress': return 'bg-warning-100 text-warning-600';
      case 'completed': return 'bg-secondary-100 text-secondary-600';
      default: return 'bg-secondary-100 text-secondary-600';
    }
  };

  const formatDeadline = (deadline) => {
    const now = new Date();
    const diff = deadline - now;
    const days = Math.ceil(diff / (1000 * 60 * 60 * 24));
    
    if (days < 0) return 'Overdue';
    if (days === 0) return 'Due today';
    if (days === 1) return 'Due tomorrow';
    if (days <= 7) return `${days} days left`;
    return `${Math.ceil(days / 7)} weeks left`;
  };

  const isUrgent = (deadline) => {
    const now = new Date();
    const diff = deadline - now;
    const days = Math.ceil(diff / (1000 * 60 * 60 * 24));
    return days <= 7;
  };

  const ProjectCard = ({ project }) => (
    <div className="card p-6 hover:shadow-lg transition-all duration-200 ease-out">
      <div className="relative mb-4">
        <div className="aspect-video rounded-lg overflow-hidden bg-secondary-100">
          <Image
            src={project.image}
            alt={project.title}
            className="w-full h-full object-cover"
          />
        </div>
        <button
          onClick={() => handleBookmark(project.id)}
          className="absolute top-3 right-3 p-2 bg-surface rounded-full shadow-md hover:bg-secondary-50 transition-colors duration-150"
          aria-label={bookmarkedProjects.includes(project.id) ? 'Remove bookmark' : 'Add bookmark'}
        >
          <Icon
            name={bookmarkedProjects.includes(project.id) ? 'Bookmark' : 'BookmarkPlus'}
            size={16}
            className={bookmarkedProjects.includes(project.id) ? 'text-primary' : 'text-secondary-600'}
          />
        </button>
        {project.tags.length > 0 && (
          <div className="absolute bottom-3 left-3 flex flex-wrap gap-1">
            {project.tags.map((tag, index) => (
              <span
                key={index}
                className={`
                  px-2 py-1 rounded-md text-xs font-medium
                  ${tag === 'Urgent' ? 'bg-error text-white' : ''}
                  ${tag === 'Popular' ? 'bg-primary text-white' : ''}
                  ${tag === 'New' ? 'bg-success text-white' : ''}
                  ${tag === 'Beginner Friendly' ? 'bg-success-100 text-success-600' : ''}
                  ${tag === 'Advanced' ? 'bg-error-100 text-error-600' : ''}
                  ${tag === 'High Interest' ? 'bg-warning-100 text-warning-600' : ''}
                  ${tag === 'Open Source' ? 'bg-secondary-100 text-secondary-600' : ''}
                  ${tag === 'In Progress' ? 'bg-warning text-white' : ''}
                `}
              >
                {tag}
              </span>
            ))}
          </div>
        )}
      </div>

      <div className="space-y-4">
        <div>
          <h3 className="font-heading font-semibold text-lg text-text-primary mb-2 line-clamp-2">
            {project.title}
          </h3>
          <p className="text-text-secondary text-sm line-clamp-3 mb-3">
            {project.description}
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <Image
            src={project.author.avatar}
            alt={project.author.name}
            className="w-8 h-8 rounded-full"
          />
          <div>
            <p className="text-sm font-medium text-text-primary">{project.author.name}</p>
            <p className="text-xs text-text-secondary">{project.author.role}</p>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          {project.skills.slice(0, 3).map((skill, index) => (
            <span
              key={index}
              className="px-2 py-1 bg-primary-50 text-primary-700 text-xs font-medium rounded-md"
            >
              {skill}
            </span>
          ))}
          {project.skills.length > 3 && (
            <span className="px-2 py-1 bg-secondary-100 text-secondary-600 text-xs font-medium rounded-md">
              +{project.skills.length - 3} more
            </span>
          )}
        </div>

        <div className="grid grid-cols-2 gap-4 text-sm">
          <div className="flex items-center space-x-2">
            <Icon name="Users" size={16} className="text-secondary-600" />
            <span className="text-text-secondary">
              {project.currentMembers}/{project.maxMembers} members
            </span>
          </div>
          <div className="flex items-center space-x-2">
            <Icon name="Clock" size={16} className="text-secondary-600" />
            <span className={`text-sm ${isUrgent(project.deadline) ? 'text-error font-medium' : 'text-text-secondary'}`}>
              {formatDeadline(project.deadline)}
            </span>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4 text-xs text-text-secondary">
            <div className="flex items-center space-x-1">
              <Icon name="Eye" size={14} />
              <span>{project.viewCount}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Icon name="Heart" size={14} />
              <span>{project.interestCount}</span>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <span className={`px-2 py-1 rounded-md text-xs font-medium ${getDifficultyColor(project.difficulty)}`}>
              {project.difficulty}
            </span>
            <span className={`px-2 py-1 rounded-md text-xs font-medium ${getStatusColor(project.status)}`}>
              {project.status}
            </span>
          </div>
        </div>

        <div className="flex space-x-3 pt-2">
          <button
            onClick={() => navigate(`/project-details/${project.id}`)}
            className="flex-1 px-4 py-2 border border-border rounded-lg text-secondary-700 hover:bg-secondary-100 transition-all duration-150 ease-out"
          >
            View Details
          </button>
          <button
            onClick={() => handleJoinRequest(project.id)}
            disabled={project.currentMembers >= project.maxMembers}
            className={`
              flex-1 px-4 py-2 rounded-lg font-medium transition-all duration-150 ease-out
              ${project.currentMembers >= project.maxMembers
                ? 'bg-secondary-100 text-secondary-500 cursor-not-allowed' :'btn-primary'
              }
            `}
          >
            {project.currentMembers >= project.maxMembers ? 'Team Full' : 'Request to Join'}
          </button>
        </div>
      </div>
    </div>
  );

  const SkeletonCard = () => (
    <div className="card p-6 animate-pulse">
      <div className="aspect-video bg-secondary-200 rounded-lg mb-4" />
      <div className="space-y-3">
        <div className="h-4 bg-secondary-200 rounded w-3/4" />
        <div className="h-3 bg-secondary-200 rounded w-full" />
        <div className="h-3 bg-secondary-200 rounded w-2/3" />
        <div className="flex space-x-2">
          <div className="h-6 bg-secondary-200 rounded w-16" />
          <div className="h-6 bg-secondary-200 rounded w-20" />
        </div>
        <div className="flex justify-between">
          <div className="h-8 bg-secondary-200 rounded w-24" />
          <div className="h-8 bg-secondary-200 rounded w-32" />
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Search and Sort Controls */}
        <div className="mb-6 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <h1 className="font-heading font-bold text-2xl text-text-primary">
                Discover Projects
              </h1>
              <span className="text-text-secondary">
                {filteredProjects.length} projects found
              </span>
            </div>
            
            <div className="flex items-center space-x-3">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="input-field text-sm min-w-[140px]"
              >
                <option value="relevance">Most Relevant</option>
                <option value="newest">Newest First</option>
                <option value="deadline">Deadline Soon</option>
                <option value="popularity">Most Popular</option>
                <option value="team-size">Team Size</option>
              </select>
              
              <button
                onClick={() => setShowFilters(true)}
                className="relative btn-secondary flex items-center space-x-2"
              >
                <Icon name="Filter" size={16} />
                <span className="hidden sm:inline">Filters</span>
                {getActiveFilterCount() > 0 && (
                  <span className="notification-badge">
                    {getActiveFilterCount()}
                  </span>
                )}
              </button>
            </div>
          </div>

          {/* Active Filter Chips */}
          {getActiveFilterCount() > 0 && (
            <div className="flex flex-wrap gap-2">
              {activeFilters.skills.map((skill, index) => (
                <span
                  key={index}
                  className="inline-flex items-center space-x-1 px-3 py-1 bg-primary-100 text-primary-700 rounded-full text-sm"
                >
                  <span>{skill}</span>
                  <button
                    onClick={() => setActiveFilters(prev => ({
                      ...prev,
                      skills: prev.skills.filter(s => s !== skill)
                    }))}
                    className="hover:bg-primary-200 rounded-full p-0.5"
                  >
                    <Icon name="X" size={12} />
                  </button>
                </span>
              ))}
              
              {activeFilters.difficulty && (
                <span className="inline-flex items-center space-x-1 px-3 py-1 bg-primary-100 text-primary-700 rounded-full text-sm">
                  <span>{activeFilters.difficulty}</span>
                  <button
                    onClick={() => setActiveFilters(prev => ({ ...prev, difficulty: '' }))}
                    className="hover:bg-primary-200 rounded-full p-0.5"
                  >
                    <Icon name="X" size={12} />
                  </button>
                </span>
              )}
              
              {getActiveFilterCount() > 0 && (
                <button
                  onClick={() => setActiveFilters({
                    skills: [],
                    difficulty: '',
                    duration: '',
                    teamSize: '',
                    status: '',
                    category: ''
                  })}
                  className="text-sm text-error hover:text-error-600 font-medium"
                >
                  Clear all filters
                </button>
              )}
            </div>
          )}
        </div>

        {/* Pull to Refresh Indicator */}
        {refreshing && (
          <div className="flex justify-center py-4">
            <div className="flex items-center space-x-2 text-primary">
              <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin" />
              <span className="text-sm">Refreshing projects...</span>
            </div>
          </div>
        )}

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {loading ? (
            Array.from({ length: 6 }).map((_, index) => (
              <SkeletonCard key={index} />
            ))
          ) : filteredProjects.length === 0 ? (
            <div className="col-span-full text-center py-12">
              <div className="w-24 h-24 bg-secondary-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Icon name="Search" size={48} className="text-secondary-600" />
              </div>
              <h3 className="font-heading font-semibold text-xl text-text-primary mb-2">
                No projects found
              </h3>
              <p className="text-text-secondary mb-6 max-w-md mx-auto">
                Try adjusting your search criteria or filters to find more projects that match your interests.
              </p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setActiveFilters({
                    skills: [],
                    difficulty: '',
                    duration: '',
                    teamSize: '',
                    status: '',
                    category: ''
                  });
                }}
                className="btn-primary"
              >
                Clear Search & Filters
              </button>
            </div>
          ) : (
            filteredProjects.map(project => (
              <ProjectCard key={project.id} project={project} />
            ))
          )}
        </div>

        {/* Load More Button */}
        {!loading && filteredProjects.length > 0 && (
          <div className="text-center mt-12">
            <button className="btn-secondary px-8 py-3">
              <Icon name="ChevronDown" size={16} className="mr-2" />
              Load More Projects
            </button>
          </div>
        )}
      </div>

      {/* Filter Panel */}
      <ProjectFilterPanel
        isOpen={showFilters}
        onClose={() => setShowFilters(false)}
        onApplyFilters={handleApplyFilters}
      />
    </div>
  );
};

export default ProjectDiscovery;