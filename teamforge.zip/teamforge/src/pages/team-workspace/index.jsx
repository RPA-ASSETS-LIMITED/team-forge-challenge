import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from 'components/AppIcon';
import Image from 'components/AppImage';
import TaskBoard from './components/TaskBoard';
import Timeline from './components/Timeline';
import FileManager from './components/FileManager';
import TeamDiscussion from './components/TeamDiscussion';
import ActivityFeed from './components/ActivityFeed';
import TeamMemberList from './components/TeamMemberList';

const TeamWorkspace = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('tasks');
  const [isActivityFeedOpen, setIsActivityFeedOpen] = useState(false);
  const [onlineMembers, setOnlineMembers] = useState([]);

  // Mock project data
  const projectData = {
    id: 'proj-001',
    name: 'EcoTracker Mobile App',
    description: 'A mobile application to help users track their carbon footprint and adopt sustainable practices',
    status: 'in-progress',
    progress: 68,
    startDate: '2024-01-15',
    endDate: '2024-04-15',
    priority: 'high'
  };

  // Mock team members data
  const teamMembers = [
    {
      id: 'user-001',
      name: 'Sarah Chen',
      role: 'Project Lead',
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face',
      isOnline: true,
      lastSeen: new Date(),
      skills: ['React', 'Node.js', 'Project Management']
    },
    {
      id: 'user-002',
      name: 'Marcus Rodriguez',
      role: 'Frontend Developer',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
      isOnline: true,
      lastSeen: new Date(Date.now() - 300000),
      skills: ['React Native', 'JavaScript', 'UI/UX']
    },
    {
      id: 'user-003',
      name: 'Priya Patel',
      role: 'Backend Developer',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face',
      isOnline: false,
      lastSeen: new Date(Date.now() - 1800000),
      skills: ['Python', 'Django', 'PostgreSQL']
    },
    {
      id: 'user-004',
      name: 'Alex Kim',
      role: 'UI/UX Designer',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face',
      isOnline: true,
      lastSeen: new Date(Date.now() - 120000),
      skills: ['Figma', 'Adobe XD', 'Prototyping']
    },
    {
      id: 'user-005',
      name: 'Emma Thompson',
      role: 'QA Tester',
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&h=150&fit=crop&crop=face',
      isOnline: false,
      lastSeen: new Date(Date.now() - 3600000),
      skills: ['Testing', 'Automation', 'Bug Tracking']
    }
  ];

  // Mock recent activity data
  const recentActivity = [
    {
      id: 'activity-001',
      type: 'task_completed',
      user: teamMembers[1],
      action: 'completed task',
      target: 'User Authentication Flow',
      timestamp: new Date(Date.now() - 900000),
      icon: 'CheckCircle',
      color: 'text-success'
    },
    {
      id: 'activity-002',
      type: 'file_uploaded',
      user: teamMembers[3],
      action: 'uploaded file',
      target: 'Mobile Wireframes v2.fig',
      timestamp: new Date(Date.now() - 1800000),
      icon: 'Upload',
      color: 'text-primary'
    },
    {
      id: 'activity-003',
      type: 'comment_added',
      user: teamMembers[0],
      action: 'commented on',
      target: 'API Integration Task',
      timestamp: new Date(Date.now() - 2700000),
      icon: 'MessageCircle',
      color: 'text-secondary'
    },
    {
      id: 'activity-004',
      type: 'task_assigned',
      user: teamMembers[0],
      action: 'assigned task to',
      target: 'Marcus Rodriguez',
      timestamp: new Date(Date.now() - 3600000),
      icon: 'UserPlus',
      color: 'text-accent'
    }
  ];

  // Simulate online status updates
  useEffect(() => {
    const updateOnlineStatus = () => {
      const online = teamMembers.filter(member => member.isOnline);
      setOnlineMembers(online);
    };

    updateOnlineStatus();
    const interval = setInterval(updateOnlineStatus, 30000);
    return () => clearInterval(interval);
  }, []);

  const tabs = [
    { id: 'tasks', label: 'Tasks', icon: 'Kanban', count: 12 },
    { id: 'timeline', label: 'Timeline', icon: 'Calendar', count: 0 },
    { id: 'files', label: 'Files', icon: 'Folder', count: 8 },
    { id: 'discussion', label: 'Discussion', icon: 'MessageSquare', count: 3 }
  ];

  const formatLastSeen = (timestamp) => {
    const now = new Date();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);

    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    return 'Yesterday';
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'tasks':
        return <TaskBoard projectId={projectData.id} teamMembers={teamMembers} />;
      case 'timeline':
        return <Timeline projectData={projectData} teamMembers={teamMembers} />;
      case 'files':
        return <FileManager projectId={projectData.id} teamMembers={teamMembers} />;
      case 'discussion':
        return <TeamDiscussion projectId={projectData.id} teamMembers={teamMembers} />;
      default:
        return <TaskBoard projectId={projectData.id} teamMembers={teamMembers} />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Project Header */}
      <div className="bg-surface border-b border-border">
        <div className="px-4 py-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <button
                onClick={() => navigate('/dashboard-home')}
                className="p-2 rounded-lg hover:bg-secondary-100 transition-colors duration-150"
                aria-label="Back to dashboard"
              >
                <Icon name="ArrowLeft" size={20} className="text-secondary-600" />
              </button>
              <div>
                <h1 className="font-heading font-semibold text-xl text-text-primary">
                  {projectData.name}
                </h1>
                <p className="text-sm text-text-secondary mt-1">
                  {projectData.description}
                </p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              {/* Team Member Avatars */}
              <div className="flex -space-x-2">
                {teamMembers.slice(0, 4).map((member) => (
                  <div key={member.id} className="relative">
                    <Image
                      src={member.avatar}
                      alt={member.name}
                      className="w-8 h-8 rounded-full border-2 border-surface"
                    />
                    {member.isOnline && (
                      <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-success rounded-full border-2 border-surface" />
                    )}
                  </div>
                ))}
                {teamMembers.length > 4 && (
                  <div className="w-8 h-8 rounded-full bg-secondary-200 border-2 border-surface flex items-center justify-center">
                    <span className="text-xs font-medium text-secondary-700">
                      +{teamMembers.length - 4}
                    </span>
                  </div>
                )}
              </div>

              <button
                onClick={() => setIsActivityFeedOpen(!isActivityFeedOpen)}
                className="p-2 rounded-lg hover:bg-secondary-100 transition-colors duration-150 relative"
                aria-label="Toggle activity feed"
              >
                <Icon name="Activity" size={20} className="text-secondary-600" />
                <div className="absolute -top-1 -right-1 w-2 h-2 bg-primary rounded-full" />
              </button>
            </div>
          </div>

          {/* Project Progress */}
          <div className="flex items-center space-x-4">
            <div className="flex-1">
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm font-medium text-text-secondary">Progress</span>
                <span className="text-sm font-semibold text-text-primary">{projectData.progress}%</span>
              </div>
              <div className="w-full bg-secondary-200 rounded-full h-2">
                <div 
                  className="bg-primary h-2 rounded-full transition-all duration-300 ease-out"
                  style={{ width: `${projectData.progress}%` }}
                />
              </div>
            </div>
            <div className="flex items-center space-x-4 text-sm text-text-secondary">
              <div className="flex items-center space-x-1">
                <Icon name="Users" size={16} />
                <span>{teamMembers.length} members</span>
              </div>
              <div className="flex items-center space-x-1">
                <Icon name="Clock" size={16} />
                <span>Due Apr 15</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="flex">
        {/* Main Content */}
        <div className="flex-1">
          {/* Tab Navigation */}
          <div className="bg-surface border-b border-border">
            <div className="px-4">
              <nav className="flex space-x-8" role="tablist">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`
                      flex items-center space-x-2 py-4 border-b-2 transition-all duration-150 ease-in-out
                      ${activeTab === tab.id
                        ? 'border-primary text-primary font-medium' :'border-transparent text-text-secondary hover:text-text-primary hover:border-secondary-300'
                      }
                    `}
                    role="tab"
                    aria-selected={activeTab === tab.id}
                    aria-controls={`${tab.id}-panel`}
                  >
                    <Icon name={tab.icon} size={18} />
                    <span>{tab.label}</span>
                    {tab.count > 0 && (
                      <span className="bg-secondary-200 text-secondary-700 text-xs px-2 py-0.5 rounded-full">
                        {tab.count}
                      </span>
                    )}
                  </button>
                ))}
              </nav>
            </div>
          </div>

          {/* Tab Content */}
          <div className="p-4">
            <div
              id={`${activeTab}-panel`}
              role="tabpanel"
              aria-labelledby={`${activeTab}-tab`}
              className="animation-fade-in"
            >
              {renderTabContent()}
            </div>
          </div>
        </div>

        {/* Activity Feed Sidebar - Desktop */}
        <div className={`
          hidden lg:block w-80 border-l border-border bg-surface transition-all duration-300 ease-in-out
          ${isActivityFeedOpen ? 'translate-x-0' : 'translate-x-full'}
        `}>
          <div className="p-4 border-b border-border">
            <div className="flex items-center justify-between">
              <h3 className="font-heading font-medium text-text-primary">Team Activity</h3>
              <button
                onClick={() => setIsActivityFeedOpen(false)}
                className="p-1 rounded hover:bg-secondary-100 transition-colors duration-150"
                aria-label="Close activity feed"
              >
                <Icon name="X" size={16} className="text-secondary-600" />
              </button>
            </div>
          </div>
          
          <div className="h-[calc(100vh-200px)] overflow-y-auto">
            <TeamMemberList members={teamMembers} />
            <ActivityFeed activities={recentActivity} />
          </div>
        </div>
      </div>

      {/* Mobile Activity Feed Modal */}
      {isActivityFeedOpen && (
        <div className="lg:hidden fixed inset-0 z-50 bg-black bg-opacity-50" onClick={() => setIsActivityFeedOpen(false)}>
          <div 
            className="absolute right-0 top-0 h-full w-80 bg-surface shadow-prominent animation-slide-up"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-4 border-b border-border">
              <div className="flex items-center justify-between">
                <h3 className="font-heading font-medium text-text-primary">Team Activity</h3>
                <button
                  onClick={() => setIsActivityFeedOpen(false)}
                  className="p-1 rounded hover:bg-secondary-100 transition-colors duration-150"
                  aria-label="Close activity feed"
                >
                  <Icon name="X" size={16} className="text-secondary-600" />
                </button>
              </div>
            </div>
            
            <div className="h-[calc(100vh-80px)] overflow-y-auto">
              <TeamMemberList members={teamMembers} />
              <ActivityFeed activities={recentActivity} />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TeamWorkspace;