import React, { useState } from 'react';
import Icon from 'components/AppIcon';
import Image from 'components/AppImage';

const Timeline = ({ projectData, teamMembers }) => {
  const [viewMode, setViewMode] = useState('month'); // week, month, quarter

  // Mock timeline data
  const milestones = [
    {
      id: 'milestone-001',
      title: 'Project Kickoff',
      description: 'Initial team meeting and project planning session',
      date: '2024-01-15',
      status: 'completed',
      assignee: teamMembers[0],
      tasks: ['Team formation', 'Requirements gathering', 'Technology stack selection']
    },
    {
      id: 'milestone-002',
      title: 'Design Phase',
      description: 'Complete UI/UX design and user flow documentation',
      date: '2024-02-01',
      status: 'completed',
      assignee: teamMembers[3],
      tasks: ['User research', 'Wireframes', 'High-fidelity mockups', 'Design system']
    },
    {
      id: 'milestone-003',
      title: 'Backend Development',
      description: 'API development and database implementation',
      date: '2024-02-15',
      status: 'in-progress',
      assignee: teamMembers[2],
      tasks: ['Database schema', 'Authentication API', 'Core business logic', 'API documentation']
    },
    {
      id: 'milestone-004',
      title: 'Frontend Development',
      description: 'Mobile app development and integration',
      date: '2024-03-01',
      status: 'upcoming',
      assignee: teamMembers[1],
      tasks: ['Component development', 'API integration', 'State management', 'Responsive design']
    },
    {
      id: 'milestone-005',
      title: 'Testing & QA',
      description: 'Comprehensive testing and bug fixes',
      date: '2024-03-15',
      status: 'upcoming',
      assignee: teamMembers[4],
      tasks: ['Unit testing', 'Integration testing', 'User acceptance testing', 'Performance testing']
    },
    {
      id: 'milestone-006',
      title: 'Deployment & Launch',
      description: 'Production deployment and go-live',
      date: '2024-04-01',
      status: 'upcoming',
      assignee: teamMembers[0],
      tasks: ['Production setup', 'Deployment pipeline', 'Monitoring setup', 'Launch preparation']
    }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed': return 'bg-success text-white';
      case 'in-progress': return 'bg-primary text-white';
      case 'upcoming': return 'bg-secondary-300 text-secondary-700';
      case 'overdue': return 'bg-error text-white';
      default: return 'bg-secondary-300 text-secondary-700';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed': return 'CheckCircle';
      case 'in-progress': return 'Clock';
      case 'upcoming': return 'Circle';
      case 'overdue': return 'AlertCircle';
      default: return 'Circle';
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const getDaysUntil = (dateString) => {
    const date = new Date(dateString);
    const today = new Date();
    const diffTime = date - today;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays < 0) return `${Math.abs(diffDays)} days overdue`;
    if (diffDays === 0) return 'Due today';
    if (diffDays === 1) return 'Due tomorrow';
    return `${diffDays} days remaining`;
  };

  const getProgressPercentage = () => {
    const completed = milestones.filter(m => m.status === 'completed').length;
    return Math.round((completed / milestones.length) * 100);
  };

  const MilestoneCard = ({ milestone, index }) => (
    <div className="flex items-start space-x-4 mb-8">
      {/* Timeline Line */}
      <div className="flex flex-col items-center">
        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${getStatusColor(milestone.status)}`}>
          <Icon name={getStatusIcon(milestone.status)} size={20} />
        </div>
        {index < milestones.length - 1 && (
          <div className="w-0.5 h-16 bg-secondary-200 mt-2" />
        )}
      </div>

      {/* Milestone Content */}
      <div className="flex-1 card p-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1">
            <h3 className="font-heading font-semibold text-text-primary mb-1">
              {milestone.title}
            </h3>
            <p className="text-text-secondary text-sm mb-2">
              {milestone.description}
            </p>
            <div className="flex items-center space-x-4 text-sm text-text-secondary">
              <div className="flex items-center space-x-1">
                <Icon name="Calendar" size={14} />
                <span>{formatDate(milestone.date)}</span>
              </div>
              <div className="flex items-center space-x-1">
                <Icon name="User" size={14} />
                <span>{milestone.assignee.name}</span>
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-2 ml-4">
            <Image
              src={milestone.assignee.avatar}
              alt={milestone.assignee.name}
              className="w-8 h-8 rounded-full"
            />
            <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(milestone.status)}`}>
              {milestone.status.replace('-', ' ')}
            </span>
          </div>
        </div>

        {/* Tasks List */}
        <div className="mb-3">
          <h4 className="text-sm font-medium text-text-primary mb-2">Tasks:</h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {milestone.tasks.map((task, taskIndex) => (
              <div key={taskIndex} className="flex items-center space-x-2 text-sm text-text-secondary">
                <Icon 
                  name={milestone.status === 'completed' ? 'CheckCircle' : 'Circle'} 
                  size={14} 
                  className={milestone.status === 'completed' ? 'text-success' : 'text-secondary-400'}
                />
                <span className={milestone.status === 'completed' ? 'line-through' : ''}>
                  {task}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Days Until */}
        {milestone.status !== 'completed' && (
          <div className="flex items-center justify-between pt-3 border-t border-border">
            <span className={`text-sm font-medium ${
              getDaysUntil(milestone.date).includes('overdue') ? 'text-error' :
              getDaysUntil(milestone.date).includes('today') ? 'text-warning' :
              'text-text-secondary'
            }`}>
              {getDaysUntil(milestone.date)}
            </span>
            <div className="flex items-center space-x-2">
              <button className="p-1 rounded hover:bg-secondary-100 transition-colors duration-150">
                <Icon name="Edit" size={14} className="text-secondary-600" />
              </button>
              <button className="p-1 rounded hover:bg-secondary-100 transition-colors duration-150">
                <Icon name="MoreHorizontal" size={14} className="text-secondary-600" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="h-full">
      {/* Timeline Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="font-heading font-semibold text-xl text-text-primary mb-2">
            Project Timeline
          </h2>
          <div className="flex items-center space-x-4 text-sm text-text-secondary">
            <div className="flex items-center space-x-1">
              <Icon name="Target" size={16} />
              <span>{milestones.length} milestones</span>
            </div>
            <div className="flex items-center space-x-1">
              <Icon name="TrendingUp" size={16} />
              <span>{getProgressPercentage()}% complete</span>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <div className="flex bg-secondary-100 rounded-lg p-1">
            {['week', 'month', 'quarter'].map((mode) => (
              <button
                key={mode}
                onClick={() => setViewMode(mode)}
                className={`px-3 py-1 rounded-md text-sm font-medium transition-all duration-150 ease-in-out ${
                  viewMode === mode
                    ? 'bg-surface text-text-primary shadow-sm'
                    : 'text-text-secondary hover:text-text-primary'
                }`}
              >
                {mode.charAt(0).toUpperCase() + mode.slice(1)}
              </button>
            ))}
          </div>
          <button className="btn-primary">
            <Icon name="Plus" size={16} className="mr-2" />
            Add Milestone
          </button>
        </div>
      </div>

      {/* Progress Overview */}
      <div className="card p-4 mb-6">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-medium text-text-primary">Overall Progress</h3>
          <span className="text-sm font-semibold text-text-primary">{getProgressPercentage()}%</span>
        </div>
        <div className="w-full bg-secondary-200 rounded-full h-3 mb-3">
          <div 
            className="bg-primary h-3 rounded-full transition-all duration-500 ease-out"
            style={{ width: `${getProgressPercentage()}%` }}
          />
        </div>
        <div className="flex items-center justify-between text-sm text-text-secondary">
          <span>Started {formatDate(projectData.startDate)}</span>
          <span>Due {formatDate(projectData.endDate)}</span>
        </div>
      </div>

      {/* Timeline */}
      <div className="space-y-0">
        {milestones.map((milestone, index) => (
          <MilestoneCard key={milestone.id} milestone={milestone} index={index} />
        ))}
      </div>

      {/* Add Milestone Button - Mobile */}
      <div className="lg:hidden mt-6">
        <button className="btn-primary w-full">
          <Icon name="Plus" size={16} className="mr-2" />
          Add New Milestone
        </button>
      </div>
    </div>
  );
};

export default Timeline;