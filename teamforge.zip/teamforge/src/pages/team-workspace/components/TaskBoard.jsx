import React, { useState } from 'react';
import Icon from 'components/AppIcon';
import Image from 'components/AppImage';

const TaskBoard = ({ projectId, teamMembers }) => {
  const [draggedTask, setDraggedTask] = useState(null);

  // Mock tasks data
  const [tasks, setTasks] = useState([
    {
      id: 'task-001',
      title: 'User Authentication System',
      description: 'Implement login, registration, and password reset functionality',
      status: 'todo',
      priority: 'high',
      assignee: teamMembers[1],
      dueDate: '2024-02-15',
      tags: ['Backend', 'Security'],
      comments: 3,
      attachments: 1
    },
    {
      id: 'task-002',
      title: 'Mobile App Wireframes',
      description: 'Create wireframes for all main screens of the mobile application',
      status: 'in-progress',
      priority: 'medium',
      assignee: teamMembers[3],
      dueDate: '2024-02-10',
      tags: ['Design', 'UI/UX'],
      comments: 7,
      attachments: 5
    },
    {
      id: 'task-003',
      title: 'API Documentation',
      description: 'Document all API endpoints with examples and response formats',
      status: 'in-progress',
      priority: 'medium',
      assignee: teamMembers[2],
      dueDate: '2024-02-12',
      tags: ['Documentation', 'API'],
      comments: 2,
      attachments: 0
    },
    {
      id: 'task-004',
      title: 'Database Schema Design',
      description: 'Design and implement the database schema for user data and carbon tracking',
      status: 'review',
      priority: 'high',
      assignee: teamMembers[2],
      dueDate: '2024-02-08',
      tags: ['Database', 'Backend'],
      comments: 5,
      attachments: 2
    },
    {
      id: 'task-005',
      title: 'Logo and Branding',
      description: 'Create app logo and establish brand guidelines',
      status: 'done',
      priority: 'low',
      assignee: teamMembers[3],
      dueDate: '2024-02-05',
      tags: ['Design', 'Branding'],
      comments: 4,
      attachments: 8
    },
    {
      id: 'task-006',
      title: 'Carbon Footprint Calculator',
      description: 'Implement the core algorithm for calculating carbon footprint',
      status: 'todo',
      priority: 'high',
      assignee: teamMembers[1],
      dueDate: '2024-02-20',
      tags: ['Frontend', 'Algorithm'],
      comments: 1,
      attachments: 0
    }
  ]);

  const columns = [
    { id: 'todo', title: 'To Do', color: 'bg-secondary-100', count: tasks.filter(t => t.status === 'todo').length },
    { id: 'in-progress', title: 'In Progress', color: 'bg-primary-50', count: tasks.filter(t => t.status === 'in-progress').length },
    { id: 'review', title: 'Review', color: 'bg-warning-50', count: tasks.filter(t => t.status === 'review').length },
    { id: 'done', title: 'Done', color: 'bg-success-50', count: tasks.filter(t => t.status === 'done').length }
  ];

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return 'bg-error text-white';
      case 'medium': return 'bg-warning text-white';
      case 'low': return 'bg-success text-white';
      default: return 'bg-secondary text-white';
    }
  };

  const formatDueDate = (dateString) => {
    const date = new Date(dateString);
    const today = new Date();
    const diffTime = date - today;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays < 0) return 'Overdue';
    if (diffDays === 0) return 'Due today';
    if (diffDays === 1) return 'Due tomorrow';
    return `Due in ${diffDays} days`;
  };

  const handleDragStart = (e, task) => {
    setDraggedTask(task);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = (e, newStatus) => {
    e.preventDefault();
    if (draggedTask && draggedTask.status !== newStatus) {
      setTasks(prevTasks =>
        prevTasks.map(task =>
          task.id === draggedTask.id
            ? { ...task, status: newStatus }
            : task
        )
      );
    }
    setDraggedTask(null);
  };

  const TaskCard = ({ task }) => (
    <div
      draggable
      onDragStart={(e) => handleDragStart(e, task)}
      className="card p-4 mb-3 cursor-move hover:shadow-prominent transition-all duration-200 ease-out"
    >
      <div className="flex items-start justify-between mb-3">
        <h4 className="font-medium text-text-primary text-sm leading-tight flex-1 mr-2">
          {task.title}
        </h4>
        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getPriorityColor(task.priority)}`}>
          {task.priority}
        </span>
      </div>

      <p className="text-text-secondary text-sm mb-3 line-clamp-2">
        {task.description}
      </p>

      <div className="flex flex-wrap gap-1 mb-3">
        {task.tags.map((tag, index) => (
          <span
            key={index}
            className="px-2 py-1 bg-secondary-100 text-secondary-700 text-xs rounded-md"
          >
            {tag}
          </span>
        ))}
      </div>

      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Image
            src={task.assignee.avatar}
            alt={task.assignee.name}
            className="w-6 h-6 rounded-full"
          />
          <span className="text-xs text-text-secondary">{task.assignee.name}</span>
        </div>

        <div className="flex items-center space-x-2 text-xs text-text-secondary">
          {task.comments > 0 && (
            <div className="flex items-center space-x-1">
              <Icon name="MessageCircle" size={12} />
              <span>{task.comments}</span>
            </div>
          )}
          {task.attachments > 0 && (
            <div className="flex items-center space-x-1">
              <Icon name="Paperclip" size={12} />
              <span>{task.attachments}</span>
            </div>
          )}
        </div>
      </div>

      <div className="mt-2 pt-2 border-t border-border">
        <div className="flex items-center justify-between">
          <span className={`text-xs ${
            formatDueDate(task.dueDate).includes('Overdue') ? 'text-error font-medium' :
            formatDueDate(task.dueDate).includes('today') ? 'text-warning font-medium' :
            'text-text-secondary'
          }`}>
            {formatDueDate(task.dueDate)}
          </span>
          <div className="flex items-center space-x-1">
            <button className="p-1 rounded hover:bg-secondary-100 transition-colors duration-150">
              <Icon name="Edit" size={12} className="text-secondary-600" />
            </button>
            <button className="p-1 rounded hover:bg-secondary-100 transition-colors duration-150">
              <Icon name="MoreHorizontal" size={12} className="text-secondary-600" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="h-full">
      {/* Mobile View - Horizontal Scroll */}
      <div className="lg:hidden">
        <div className="flex space-x-4 overflow-x-auto pb-4">
          {columns.map((column) => (
            <div
              key={column.id}
              className="flex-shrink-0 w-72"
              onDragOver={handleDragOver}
              onDrop={(e) => handleDrop(e, column.id)}
            >
              <div className={`${column.color} rounded-lg p-3 mb-4`}>
                <div className="flex items-center justify-between">
                  <h3 className="font-medium text-text-primary">{column.title}</h3>
                  <span className="bg-surface text-text-secondary text-sm px-2 py-1 rounded-full">
                    {column.count}
                  </span>
                </div>
              </div>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {tasks
                  .filter(task => task.status === column.id)
                  .map(task => (
                    <TaskCard key={task.id} task={task} />
                  ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Desktop View - Full Kanban Board */}
      <div className="hidden lg:block">
        <div className="grid grid-cols-4 gap-6 h-full">
          {columns.map((column) => (
            <div
              key={column.id}
              className="flex flex-col"
              onDragOver={handleDragOver}
              onDrop={(e) => handleDrop(e, column.id)}
            >
              <div className={`${column.color} rounded-lg p-4 mb-4`}>
                <div className="flex items-center justify-between">
                  <h3 className="font-medium text-text-primary">{column.title}</h3>
                  <span className="bg-surface text-text-secondary text-sm px-2 py-1 rounded-full">
                    {column.count}
                  </span>
                </div>
              </div>
              <div className="flex-1 space-y-3 overflow-y-auto max-h-[calc(100vh-300px)]">
                {tasks
                  .filter(task => task.status === column.id)
                  .map(task => (
                    <TaskCard key={task.id} task={task} />
                  ))}
              </div>
              <button className="mt-4 p-3 border-2 border-dashed border-secondary-300 rounded-lg text-secondary-600 hover:border-primary hover:text-primary transition-all duration-150 ease-in-out">
                <div className="flex items-center justify-center space-x-2">
                  <Icon name="Plus" size={16} />
                  <span className="text-sm font-medium">Add Task</span>
                </div>
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TaskBoard;