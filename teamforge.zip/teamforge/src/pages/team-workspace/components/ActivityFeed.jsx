import React from 'react';
import Icon from 'components/AppIcon';
import Image from 'components/AppImage';

const ActivityFeed = ({ activities }) => {
  const formatTimestamp = (timestamp) => {
    const now = new Date();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    if (days === 1) return 'Yesterday';
    return timestamp.toLocaleDateString();
  };

  const getActivityIcon = (type) => {
    switch (type) {
      case 'task_completed': return 'CheckCircle';
      case 'file_uploaded': return 'Upload';
      case 'comment_added': return 'MessageCircle';
      case 'task_assigned': return 'UserPlus';
      case 'milestone_reached': return 'Target';
      case 'code_committed': return 'GitCommit';
      default: return 'Activity';
    }
  };

  const getActivityColor = (type) => {
    switch (type) {
      case 'task_completed': return 'text-success';
      case 'file_uploaded': return 'text-primary';
      case 'comment_added': return 'text-secondary';
      case 'task_assigned': return 'text-accent';
      case 'milestone_reached': return 'text-warning';
      case 'code_committed': return 'text-purple-600';
      default: return 'text-secondary';
    }
  };

  return (
    <div className="p-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-heading font-medium text-text-primary">Recent Activity</h3>
        <button className="text-sm text-primary hover:text-primary-700 transition-colors duration-150">
          View All
        </button>
      </div>

      <div className="space-y-4">
        {activities.map((activity) => (
          <div key={activity.id} className="flex items-start space-x-3">
            <div className="flex-shrink-0">
              <Image
                src={activity.user.avatar}
                alt={activity.user.name}
                className="w-8 h-8 rounded-full"
              />
            </div>
            
            <div className="flex-1 min-w-0">
              <div className="flex items-center space-x-2 mb-1">
                <Icon 
                  name={getActivityIcon(activity.type)} 
                  size={14} 
                  className={getActivityColor(activity.type)}
                />
                <p className="text-sm text-text-primary">
                  <span className="font-medium">{activity.user.name}</span>
                  {' '}{activity.action}{' '}
                  <span className="font-medium">{activity.target}</span>
                </p>
              </div>
              <p className="text-xs text-text-secondary">
                {formatTimestamp(activity.timestamp)}
              </p>
            </div>
          </div>
        ))}
      </div>

      {activities.length === 0 && (
        <div className="text-center py-8">
          <div className="w-12 h-12 bg-secondary-100 rounded-full flex items-center justify-center mx-auto mb-3">
            <Icon name="Activity" size={24} className="text-secondary-600" />
          </div>
          <p className="text-sm text-text-secondary">No recent activity</p>
        </div>
      )}
    </div>
  );
};

export default ActivityFeed;