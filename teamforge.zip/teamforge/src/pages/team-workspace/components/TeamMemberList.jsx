import React from 'react';
import Icon from 'components/AppIcon';
import Image from 'components/AppImage';

const TeamMemberList = ({ members }) => {
  const formatLastSeen = (timestamp) => {
    const now = new Date();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);

    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    return 'Yesterday';
  };

  const onlineMembers = members.filter(member => member.isOnline);
  const offlineMembers = members.filter(member => !member.isOnline);

  const MemberItem = ({ member }) => (
    <div className="flex items-center space-x-3 p-2 rounded-lg hover:bg-secondary-50 transition-colors duration-150 cursor-pointer">
      <div className="relative">
        <Image
          src={member.avatar}
          alt={member.name}
          className="w-10 h-10 rounded-full"
        />
        <div className={`
          absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-surface
          ${member.isOnline ? 'bg-success' : 'bg-secondary-400'}
        `} />
      </div>
      
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between">
          <h4 className="font-medium text-text-primary text-sm truncate">
            {member.name}
          </h4>
          {!member.isOnline && (
            <span className="text-xs text-text-secondary">
              {formatLastSeen(member.lastSeen)}
            </span>
          )}
        </div>
        <p className="text-text-secondary text-xs truncate">
          {member.role}
        </p>
        {member.isOnline && (
          <div className="flex items-center space-x-1 mt-1">
            <div className="w-2 h-2 bg-success rounded-full" />
            <span className="text-xs text-success font-medium">Online</span>
          </div>
        )}
      </div>

      <button className="p-1 rounded hover:bg-secondary-100 transition-colors duration-150">
        <Icon name="MoreHorizontal" size={16} className="text-secondary-600" />
      </button>
    </div>
  );

  return (
    <div className="p-4 border-b border-border">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-heading font-medium text-text-primary">Team Members</h3>
        <span className="text-sm text-text-secondary">
          {onlineMembers.length}/{members.length} online
        </span>
      </div>

      <div className="space-y-1">
        {/* Online Members */}
        {onlineMembers.length > 0 && (
          <>
            <div className="flex items-center space-x-2 mb-2">
              <div className="w-2 h-2 bg-success rounded-full" />
              <span className="text-xs font-medium text-success uppercase tracking-wide">
                Online ({onlineMembers.length})
              </span>
            </div>
            {onlineMembers.map((member) => (
              <MemberItem key={member.id} member={member} />
            ))}
          </>
        )}

        {/* Offline Members */}
        {offlineMembers.length > 0 && (
          <>
            <div className="flex items-center space-x-2 mb-2 mt-4">
              <div className="w-2 h-2 bg-secondary-400 rounded-full" />
              <span className="text-xs font-medium text-secondary-600 uppercase tracking-wide">
                Offline ({offlineMembers.length})
              </span>
            </div>
            {offlineMembers.map((member) => (
              <MemberItem key={member.id} member={member} />
            ))}
          </>
        )}
      </div>

      {members.length === 0 && (
        <div className="text-center py-6">
          <div className="w-12 h-12 bg-secondary-100 rounded-full flex items-center justify-center mx-auto mb-3">
            <Icon name="Users" size={24} className="text-secondary-600" />
          </div>
          <p className="text-sm text-text-secondary">No team members</p>
        </div>
      )}
    </div>
  );
};

export default TeamMemberList;