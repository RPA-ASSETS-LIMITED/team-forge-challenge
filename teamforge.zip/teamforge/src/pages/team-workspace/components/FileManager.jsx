import React, { useState } from 'react';
import Icon from 'components/AppIcon';
import Image from 'components/AppImage';

const FileManager = ({ projectId, teamMembers }) => {
  const [viewMode, setViewMode] = useState('grid'); // grid, list
  const [selectedFolder, setSelectedFolder] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Mock files and folders data
  const folders = [
    { id: 'all', name: 'All Files', icon: 'Folder', count: 24 },
    { id: 'designs', name: 'Designs', icon: 'Palette', count: 8 },
    { id: 'documents', name: 'Documents', icon: 'FileText', count: 6 },
    { id: 'code', name: 'Code', icon: 'Code', count: 5 },
    { id: 'assets', name: 'Assets', icon: 'Image', count: 5 }
  ];

  const files = [
    {
      id: 'file-001',
      name: 'EcoTracker_Wireframes_v2.fig',
      type: 'figma',
      size: '2.4 MB',
      folder: 'designs',
      uploadedBy: teamMembers[3],
      uploadedAt: '2024-02-08T10:30:00Z',
      lastModified: '2024-02-08T14:20:00Z',
      thumbnail: 'https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=200&h=150&fit=crop',
      isShared: true,
      comments: 5,
      versions: 3
    },
    {
      id: 'file-002',
      name: 'API_Documentation.pdf',
      type: 'pdf',
      size: '1.8 MB',
      folder: 'documents',
      uploadedBy: teamMembers[2],
      uploadedAt: '2024-02-07T16:45:00Z',
      lastModified: '2024-02-07T16:45:00Z',
      thumbnail: null,
      isShared: true,
      comments: 2,
      versions: 1
    },
    {
      id: 'file-003',
      name: 'carbon_calculator.js',
      type: 'javascript',
      size: '45 KB',
      folder: 'code',
      uploadedBy: teamMembers[1],
      uploadedAt: '2024-02-06T09:15:00Z',
      lastModified: '2024-02-08T11:30:00Z',
      thumbnail: null,
      isShared: false,
      comments: 8,
      versions: 5
    },
    {
      id: 'file-004',
      name: 'App_Logo_Final.svg',
      type: 'svg',
      size: '12 KB',
      folder: 'assets',
      uploadedBy: teamMembers[3],
      uploadedAt: '2024-02-05T14:20:00Z',
      lastModified: '2024-02-05T14:20:00Z',
      thumbnail: 'https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=200&h=150&fit=crop',
      isShared: true,
      comments: 3,
      versions: 2
    },
    {
      id: 'file-005',
      name: 'Database_Schema.sql',
      type: 'sql',
      size: '8.2 KB',
      folder: 'code',
      uploadedBy: teamMembers[2],
      uploadedAt: '2024-02-04T13:10:00Z',
      lastModified: '2024-02-06T10:45:00Z',
      thumbnail: null,
      isShared: true,
      comments: 4,
      versions: 3
    },
    {
      id: 'file-006',
      name: 'User_Research_Report.docx',
      type: 'word',
      size: '3.1 MB',
      folder: 'documents',
      uploadedBy: teamMembers[0],
      uploadedAt: '2024-02-03T11:30:00Z',
      lastModified: '2024-02-03T11:30:00Z',
      thumbnail: null,
      isShared: true,
      comments: 7,
      versions: 1
    }
  ];

  const getFileIcon = (type) => {
    switch (type) {
      case 'figma': return 'Figma';
      case 'pdf': return 'FileText';
      case 'javascript': return 'Code';
      case 'svg': return 'Image';
      case 'sql': return 'Database';
      case 'word': return 'FileText';
      default: return 'File';
    }
  };

  const getFileColor = (type) => {
    switch (type) {
      case 'figma': return 'text-purple-600';
      case 'pdf': return 'text-red-600';
      case 'javascript': return 'text-yellow-600';
      case 'svg': return 'text-green-600';
      case 'sql': return 'text-blue-600';
      case 'word': return 'text-blue-600';
      default: return 'text-secondary-600';
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const filteredFiles = files.filter(file => {
    const matchesFolder = selectedFolder === 'all' || file.folder === selectedFolder;
    const matchesSearch = file.name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFolder && matchesSearch;
  });

  const FileCard = ({ file }) => (
    <div className="card p-4 hover:shadow-prominent transition-all duration-200 ease-out cursor-pointer group">
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center space-x-3">
          {file.thumbnail ? (
            <div className="w-10 h-10 rounded-lg overflow-hidden bg-secondary-100">
              <Image
                src={file.thumbnail}
                alt={file.name}
                className="w-full h-full object-cover"
              />
            </div>
          ) : (
            <div className="w-10 h-10 rounded-lg bg-secondary-100 flex items-center justify-center">
              <Icon name={getFileIcon(file.type)} size={20} className={getFileColor(file.type)} />
            </div>
          )}
          <div className="flex-1 min-w-0">
            <h4 className="font-medium text-text-primary text-sm truncate">
              {file.name}
            </h4>
            <p className="text-text-secondary text-xs">
              {file.size} • {formatDate(file.lastModified)}
            </p>
          </div>
        </div>
        <button className="opacity-0 group-hover:opacity-100 p-1 rounded hover:bg-secondary-100 transition-all duration-150">
          <Icon name="MoreHorizontal" size={16} className="text-secondary-600" />
        </button>
      </div>

      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Image
            src={file.uploadedBy.avatar}
            alt={file.uploadedBy.name}
            className="w-5 h-5 rounded-full"
          />
          <span className="text-xs text-text-secondary">{file.uploadedBy.name}</span>
        </div>

        <div className="flex items-center space-x-3 text-xs text-text-secondary">
          {file.comments > 0 && (
            <div className="flex items-center space-x-1">
              <Icon name="MessageCircle" size={12} />
              <span>{file.comments}</span>
            </div>
          )}
          {file.versions > 1 && (
            <div className="flex items-center space-x-1">
              <Icon name="GitBranch" size={12} />
              <span>v{file.versions}</span>
            </div>
          )}
          {file.isShared && (
            <Icon name="Share2" size={12} className="text-primary" />
          )}
        </div>
      </div>
    </div>
  );

  const FileListItem = ({ file }) => (
    <div className="flex items-center space-x-4 p-3 hover:bg-secondary-50 rounded-lg transition-colors duration-150 cursor-pointer group">
      <div className="flex items-center space-x-3 flex-1 min-w-0">
        {file.thumbnail ? (
          <div className="w-8 h-8 rounded overflow-hidden bg-secondary-100 flex-shrink-0">
            <Image
              src={file.thumbnail}
              alt={file.name}
              className="w-full h-full object-cover"
            />
          </div>
        ) : (
          <div className="w-8 h-8 rounded bg-secondary-100 flex items-center justify-center flex-shrink-0">
            <Icon name={getFileIcon(file.type)} size={16} className={getFileColor(file.type)} />
          </div>
        )}
        <div className="flex-1 min-w-0">
          <h4 className="font-medium text-text-primary text-sm truncate">
            {file.name}
          </h4>
          <p className="text-text-secondary text-xs">
            Modified {formatDate(file.lastModified)}
          </p>
        </div>
      </div>

      <div className="flex items-center space-x-4 text-sm text-text-secondary">
        <div className="flex items-center space-x-2">
          <Image
            src={file.uploadedBy.avatar}
            alt={file.uploadedBy.name}
            className="w-5 h-5 rounded-full"
          />
          <span className="hidden sm:inline">{file.uploadedBy.name}</span>
        </div>
        <span className="hidden md:inline">{file.size}</span>
        <div className="flex items-center space-x-2">
          {file.comments > 0 && (
            <div className="flex items-center space-x-1">
              <Icon name="MessageCircle" size={12} />
              <span>{file.comments}</span>
            </div>
          )}
          {file.isShared && (
            <Icon name="Share2" size={12} className="text-primary" />
          )}
        </div>
      </div>

      <button className="opacity-0 group-hover:opacity-100 p-1 rounded hover:bg-secondary-100 transition-all duration-150">
        <Icon name="MoreHorizontal" size={16} className="text-secondary-600" />
      </button>
    </div>
  );

  return (
    <div className="h-full">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="font-heading font-semibold text-xl text-text-primary mb-2">
            Project Files
          </h2>
          <p className="text-text-secondary text-sm">
            {filteredFiles.length} files • {folders.find(f => f.id === selectedFolder)?.name}
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <div className="relative">
            <Icon name="Search" size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-600" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search files..."
              className="pl-9 pr-4 py-2 bg-secondary-100 border-0 rounded-lg focus:bg-surface focus:ring-2 focus:ring-primary-500 transition-all duration-200 ease-out text-sm"
            />
          </div>

          <div className="flex bg-secondary-100 rounded-lg p-1">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 rounded transition-all duration-150 ease-in-out ${
                viewMode === 'grid' ?'bg-surface text-text-primary shadow-sm' :'text-text-secondary hover:text-text-primary'
              }`}
              aria-label="Grid view"
            >
              <Icon name="Grid" size={16} />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 rounded transition-all duration-150 ease-in-out ${
                viewMode === 'list' ?'bg-surface text-text-primary shadow-sm' :'text-text-secondary hover:text-text-primary'
              }`}
              aria-label="List view"
            >
              <Icon name="List" size={16} />
            </button>
          </div>

          <button className="btn-primary">
            <Icon name="Upload" size={16} className="mr-2" />
            Upload
          </button>
        </div>
      </div>

      <div className="flex gap-6">
        {/* Sidebar - Folders */}
        <div className="hidden lg:block w-64 flex-shrink-0">
          <div className="card p-4">
            <h3 className="font-medium text-text-primary mb-3">Folders</h3>
            <nav className="space-y-1">
              {folders.map((folder) => (
                <button
                  key={folder.id}
                  onClick={() => setSelectedFolder(folder.id)}
                  className={`w-full flex items-center justify-between p-2 rounded-lg transition-all duration-150 ease-in-out ${
                    selectedFolder === folder.id
                      ? 'bg-primary-50 text-primary-700 border border-primary-200' :'text-text-secondary hover:text-text-primary hover:bg-secondary-100'
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <Icon name={folder.icon} size={16} />
                    <span className="text-sm font-medium">{folder.name}</span>
                  </div>
                  <span className="text-xs bg-secondary-200 text-secondary-700 px-2 py-0.5 rounded-full">
                    {folder.count}
                  </span>
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Mobile Folder Selector */}
        <div className="lg:hidden mb-4">
          <select
            value={selectedFolder}
            onChange={(e) => setSelectedFolder(e.target.value)}
            className="w-full p-2 bg-secondary-100 border-0 rounded-lg focus:bg-surface focus:ring-2 focus:ring-primary-500 transition-all duration-200 ease-out"
          >
            {folders.map((folder) => (
              <option key={folder.id} value={folder.id}>
                {folder.name} ({folder.count})
              </option>
            ))}
          </select>
        </div>

        {/* Files Content */}
        <div className="flex-1">
          {filteredFiles.length === 0 ? (
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-secondary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Icon name="FolderOpen" size={32} className="text-secondary-600" />
              </div>
              <h3 className="font-medium text-text-primary mb-2">No files found</h3>
              <p className="text-text-secondary text-sm mb-4">
                {searchQuery ? 'Try adjusting your search terms' : 'Upload your first file to get started'}
              </p>
              <button className="btn-primary">
                <Icon name="Upload" size={16} className="mr-2" />
                Upload File
              </button>
            </div>
          ) : (
            <>
              {viewMode === 'grid' ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredFiles.map((file) => (
                    <FileCard key={file.id} file={file} />
                  ))}
                </div>
              ) : (
                <div className="card">
                  <div className="divide-y divide-border">
                    {filteredFiles.map((file) => (
                      <FileListItem key={file.id} file={file} />
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default FileManager;