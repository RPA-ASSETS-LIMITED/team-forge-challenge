import React, { useState, useRef, useEffect } from 'react';
import Icon from 'components/AppIcon';
import Image from 'components/AppImage';

const TeamDiscussion = ({ projectId, teamMembers }) => {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [typingUsers, setTypingUsers] = useState([]);
  const [selectedThread, setSelectedThread] = useState(null);
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);

  // Mock messages data
  const mockMessages = [
    {
      id: 'msg-001',
      content: 'Hey team! I\'ve just uploaded the latest wireframes. Please take a look and let me know your thoughts.',
      sender: teamMembers[3],
      timestamp: new Date(Date.now() - 3600000),
      type: 'text',
      reactions: [
        { emoji: '👍', users: [teamMembers[0], teamMembers[1]], count: 2 },
        { emoji: '🎉', users: [teamMembers[2]], count: 1 }
      ],
      replies: [
        {
          id: 'reply-001',
          content: 'Looks great! I especially like the new navigation flow.',
          sender: teamMembers[0],
          timestamp: new Date(Date.now() - 3300000)
        }
      ]
    },
    {
      id: 'msg-002',
      content: 'I\'ve completed the user authentication API. The endpoints are documented and ready for integration.',
      sender: teamMembers[2],
      timestamp: new Date(Date.now() - 2700000),
      type: 'text',
      reactions: [
        { emoji: '🚀', users: [teamMembers[0], teamMembers[1], teamMembers[3]], count: 3 }
      ],
      replies: []
    },
    {
      id: 'msg-003',
      content: 'Quick question about the carbon calculation algorithm - should we include transportation data from the start or add it in phase 2?',
      sender: teamMembers[1],
      timestamp: new Date(Date.now() - 1800000),
      type: 'text',
      mentions: [teamMembers[0], teamMembers[2]],
      reactions: [],
      replies: [
        {
          id: 'reply-002',
          content: 'Let\'s include basic transportation for MVP. We can expand later.',
          sender: teamMembers[0],
          timestamp: new Date(Date.now() - 1500000)
        },
        {
          id: 'reply-003',
          content: 'Agreed. I can help with the transportation data structure.',
          sender: teamMembers[2],
          timestamp: new Date(Date.now() - 1200000)
        }
      ]
    },
    {
      id: 'msg-004',
      content: '',
      sender: teamMembers[4],
      timestamp: new Date(Date.now() - 900000),
      type: 'file',
      attachment: {
        name: 'Test_Results_Sprint1.pdf',
        size: '2.1 MB',
        type: 'pdf'
      },
      reactions: [
        { emoji: '📊', users: [teamMembers[0]], count: 1 }
      ],
      replies: []
    },
    {
      id: 'msg-005',
      content: 'Great work everyone! We\'re making excellent progress. The demo is looking fantastic.',
      sender: teamMembers[0],
      timestamp: new Date(Date.now() - 300000),
      type: 'text',
      reactions: [
        { emoji: '🎉', users: [teamMembers[1], teamMembers[2], teamMembers[3], teamMembers[4]], count: 4 }
      ],
      replies: []
    }
  ];

  useEffect(() => {
    setMessages(mockMessages);
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = (e) => {
    e.preventDefault();
    if (!newMessage.trim()) return;

    const message = {
      id: `msg-${Date.now()}`,
      content: newMessage,
      sender: teamMembers[0], // Current user
      timestamp: new Date(),
      type: 'text',
      reactions: [],
      replies: []
    };

    setMessages(prev => [...prev, message]);
    setNewMessage('');
    setIsTyping(false);
  };

  const handleInputChange = (e) => {
    setNewMessage(e.target.value);
    setIsTyping(e.target.value.length > 0);
  };

  const handleReaction = (messageId, emoji) => {
    setMessages(prev =>
      prev.map(msg => {
        if (msg.id === messageId) {
          const existingReaction = msg.reactions.find(r => r.emoji === emoji);
          if (existingReaction) {
            // Toggle reaction
            const userIndex = existingReaction.users.findIndex(u => u.id === teamMembers[0].id);
            if (userIndex > -1) {
              existingReaction.users.splice(userIndex, 1);
              existingReaction.count--;
            } else {
              existingReaction.users.push(teamMembers[0]);
              existingReaction.count++;
            }
            return { ...msg, reactions: msg.reactions.filter(r => r.count > 0) };
          } else {
            // Add new reaction
            return {
              ...msg,
              reactions: [...msg.reactions, { emoji, users: [teamMembers[0]], count: 1 }]
            };
          }
        }
        return msg;
      })
    );
  };

  const formatTimestamp = (timestamp) => {
    const now = new Date();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    if (days === 1) return 'Yesterday';
    return timestamp.toLocaleDateString();
  };

  const MessageBubble = ({ message, isOwn }) => (
    <div className={`flex ${isOwn ? 'justify-end' : 'justify-start'} mb-4`}>
      <div className={`flex ${isOwn ? 'flex-row-reverse' : 'flex-row'} items-start space-x-2 max-w-xs sm:max-w-md lg:max-w-lg`}>
        {!isOwn && (
          <Image
            src={message.sender.avatar}
            alt={message.sender.name}
            className="w-8 h-8 rounded-full flex-shrink-0"
          />
        )}
        
        <div className={`${isOwn ? 'mr-2' : 'ml-2'}`}>
          {!isOwn && (
            <div className="flex items-center space-x-2 mb-1">
              <span className="text-sm font-medium text-text-primary">{message.sender.name}</span>
              <span className="text-xs text-text-secondary">{formatTimestamp(message.timestamp)}</span>
            </div>
          )}
          
          <div className={`
            rounded-2xl px-4 py-2 ${
              isOwn 
                ? 'bg-primary text-white' :'bg-secondary-100 text-text-primary'
            }
          `}>
            {message.type === 'text' ? (
              <p className="text-sm leading-relaxed">{message.content}</p>
            ) : message.type === 'file' ? (
              <div className="flex items-center space-x-3 p-2">
                <div className="w-10 h-10 bg-white bg-opacity-20 rounded-lg flex items-center justify-center">
                  <Icon name="FileText" size={20} className={isOwn ? 'text-white' : 'text-primary'} />
                </div>
                <div>
                  <p className="text-sm font-medium">{message.attachment.name}</p>
                  <p className="text-xs opacity-75">{message.attachment.size}</p>
                </div>
              </div>
            ) : null}
          </div>

          {/* Reactions */}
          {message.reactions.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-2">
              {message.reactions.map((reaction, index) => (
                <button
                  key={index}
                  onClick={() => handleReaction(message.id, reaction.emoji)}
                  className={`
                    flex items-center space-x-1 px-2 py-1 rounded-full text-xs transition-all duration-150 ease-in-out
                    ${reaction.users.some(u => u.id === teamMembers[0].id)
                      ? 'bg-primary-100 text-primary-700 border border-primary-200' :'bg-secondary-100 text-text-secondary hover:bg-secondary-200'
                    }
                  `}
                >
                  <span>{reaction.emoji}</span>
                  <span>{reaction.count}</span>
                </button>
              ))}
            </div>
          )}

          {/* Replies */}
          {message.replies.length > 0 && (
            <div className="mt-3 space-y-2">
              {message.replies.map((reply) => (
                <div key={reply.id} className="flex items-start space-x-2">
                  <Image
                    src={reply.sender.avatar}
                    alt={reply.sender.name}
                    className="w-6 h-6 rounded-full flex-shrink-0"
                  />
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-1">
                      <span className="text-xs font-medium text-text-primary">{reply.sender.name}</span>
                      <span className="text-xs text-text-secondary">{formatTimestamp(reply.timestamp)}</span>
                    </div>
                    <div className="bg-surface rounded-lg px-3 py-2 border border-border">
                      <p className="text-sm text-text-primary">{reply.content}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {isOwn && (
            <div className="text-right mt-1">
              <span className="text-xs text-text-secondary">{formatTimestamp(message.timestamp)}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  return (
    <div className="h-full flex flex-col">
      {/* Discussion Header */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="font-heading font-semibold text-xl text-text-primary mb-1">
            Team Discussion
          </h2>
          <p className="text-text-secondary text-sm">
            {messages.length} messages • {teamMembers.filter(m => m.isOnline).length} online
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button className="p-2 rounded-lg hover:bg-secondary-100 transition-colors duration-150">
            <Icon name="Search" size={18} className="text-secondary-600" />
          </button>
          <button className="p-2 rounded-lg hover:bg-secondary-100 transition-colors duration-150">
            <Icon name="Settings" size={18} className="text-secondary-600" />
          </button>
        </div>
      </div>

      {/* Messages Container */}
      <div className="flex-1 bg-surface rounded-lg border border-border flex flex-col">
        <div className="flex-1 overflow-y-auto p-4 space-y-1">
          {messages.map((message) => (
            <MessageBubble
              key={message.id}
              message={message}
              isOwn={message.sender.id === teamMembers[0].id}
            />
          ))}
          
          {/* Typing Indicator */}
          {typingUsers.length > 0 && (
            <div className="flex items-center space-x-2 text-text-secondary text-sm">
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-secondary-400 rounded-full animate-bounce" />
                <div className="w-2 h-2 bg-secondary-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                <div className="w-2 h-2 bg-secondary-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
              </div>
              <span>{typingUsers.join(', ')} {typingUsers.length === 1 ? 'is' : 'are'} typing...</span>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>

        {/* Message Input */}
        <div className="border-t border-border p-4">
          <form onSubmit={handleSendMessage} className="flex items-end space-x-3">
            <div className="flex-1">
              <div className="flex items-center space-x-2 mb-2">
                <button
                  type="button"
                  className="p-2 rounded-lg hover:bg-secondary-100 transition-colors duration-150"
                  aria-label="Attach file"
                >
                  <Icon name="Paperclip" size={16} className="text-secondary-600" />
                </button>
                <button
                  type="button"
                  className="p-2 rounded-lg hover:bg-secondary-100 transition-colors duration-150"
                  aria-label="Add emoji"
                >
                  <Icon name="Smile" size={16} className="text-secondary-600" />
                </button>
              </div>
              <textarea
                ref={inputRef}
                value={newMessage}
                onChange={handleInputChange}
                placeholder="Type your message..."
                className="w-full p-3 border border-border rounded-lg resize-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-all duration-200 ease-out"
                rows={3}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage(e);
                  }
                }}
              />
            </div>
            <button
              type="submit"
              disabled={!newMessage.trim()}
              className={`
                p-3 rounded-lg transition-all duration-150 ease-in-out
                ${newMessage.trim()
                  ? 'bg-primary text-white hover:bg-primary-700 transform hover:scale-105'
                  : 'bg-secondary-200 text-secondary-500 cursor-not-allowed'
                }
              `}
            >
              <Icon name="Send" size={18} />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default TeamDiscussion;