/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        // Primary Colors
        'primary': '#2563EB', // Trust-building blue (blue-600)
        'primary-50': '#EFF6FF', // Light blue tint (blue-50)
        'primary-100': '#DBEAFE', // Lighter blue (blue-100)
        'primary-500': '#3B82F6', // Medium blue (blue-500)
        'primary-700': '#1D4ED8', // Darker blue (blue-700)
        'primary-900': '#1E3A8A', // Darkest blue (blue-900)
        
        // Secondary Colors
        'secondary': '#64748B', // Neutral slate (slate-500)
        'secondary-100': '#F1F5F9', // Light slate (slate-100)
        'secondary-200': '#E2E8F0', // Lighter slate (slate-200)
        'secondary-300': '#CBD5E1', // Light-medium slate (slate-300)
        'secondary-600': '#475569', // Medium-dark slate (slate-600)
        'secondary-700': '#334155', // Dark slate (slate-700)
        
        // Accent Colors
        'accent': '#10B981', // Success-oriented green (emerald-500)
        'accent-50': '#ECFDF5', // Light green tint (emerald-50)
        'accent-100': '#D1FAE5', // Light green (emerald-100)
        'accent-600': '#059669', // Medium-dark green (emerald-600)
        
        // Background Colors
        'background': '#FAFBFC', // Soft off-white (custom)
        'surface': '#FFFFFF', // Pure white (white)
        
        // Text Colors
        'text-primary': '#1E293B', // High-contrast dark gray (slate-800)
        'text-secondary': '#64748B', // Medium gray (slate-500)
        
        // Status Colors
        'success': '#059669', // Deeper green (emerald-600)
        'success-50': '#ECFDF5', // Light success tint (emerald-50)
        'success-100': '#D1FAE5', // Light success (emerald-100)
        
        'warning': '#D97706', // Amber warning (amber-600)
        'warning-50': '#FFFBEB', // Light warning tint (amber-50)
        'warning-100': '#FEF3C7', // Light warning (amber-100)
        
        'error': '#DC2626', // Clear red (red-600)
        'error-50': '#FEF2F2', // Light error tint (red-50)
        'error-100': '#FEE2E2', // Light error (red-100)
        
        // Border Colors
        'border': '#E2E8F0', // Minimal border (slate-200)
        'border-light': '#F1F5F9', // Lighter border (slate-100)
      },
      fontFamily: {
        'heading': ['Inter', 'sans-serif'], // Modern geometric sans-serif
        'body': ['Inter', 'sans-serif'], // Consistent with headings
        'caption': ['Inter', 'sans-serif'], // Maintains visual consistency
        'data': ['JetBrains Mono', 'monospace'], // Monospace for code
      },
      fontSize: {
        'nav': ['14px', { lineHeight: '20px', fontWeight: '500' }], // Navigation labels
        'header-action': ['16px', { lineHeight: '24px', fontWeight: '400' }], // Header actions
      },
      spacing: {
        'nav-height': '80px', // Bottom navigation height including safe areas
        'header-simple': '64px', // Simple header height
        'header-complex': '120px', // Complex header height
        'safe-inset': '16px', // Mobile safe area insets
        'content-margin': '24px', // Content margins
      },
      boxShadow: {
        'subtle': '0 1px 3px rgba(0, 0, 0, 0.1)', // Subtle depth
        'prominent': '0 4px 12px rgba(0, 0, 0, 0.15)', // Prominent elements
      },
      borderRadius: {
        'interactive': '6px', // Interactive elements
        'container': '12px', // Prominent cards and containers
      },
      transitionDuration: {
        '150': '150ms', // Hover effects
        '200': '200ms', // State changes
      },
      transitionTimingFunction: {
        'ease-out': 'cubic-bezier(0, 0, 0.2, 1)', // State changes
        'ease-in-out': 'cubic-bezier(0.4, 0, 0.2, 1)', // Hover effects
      },
      zIndex: {
        'bottom-nav': '1000', // Bottom tab navigation
        'header': '999', // Contextual header
        'filter-panel': '1001', // Project filter panel overlay
        'notification': '1002', // Notification badge system
        'modal': '2000', // Modal overlays
      },
      minHeight: {
        'touch-target': '48px', // Minimum touch target on mobile
        'touch-target-desktop': '56px', // Touch target on desktop
      },
      screens: {
        'tablet': '768px', // Tablet breakpoint
        'desktop': '1024px', // Desktop breakpoint
      },
    },
  },
  plugins: [
    require('@tailwindcss/forms'),
    require('@tailwindcss/typography'),
  ],
}